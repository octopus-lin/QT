#include "setwindow.h"
#include "ui_setwindow.h"
#include <QPainter>
#include <QPaintEvent>
#include <QDesktopServices>
#include <QPropertyAnimation>
#include <QScreen>
#include <QMessageBox> // 添加消息框支持
#include <QHostAddress>

setwindow::setwindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::setwindow)
{
    ui->setupUi(this);
    // 1. 删除标题栏
    setWindowFlags(Qt::FramelessWindowHint);
    // 2. 设置窗口背景透明
    setAttribute(Qt::WA_TranslucentBackground);

    ui->centralwidget->setStyleSheet(
                "QWidget#centralwidget {"
                "  background-image: url(:/img/img/ip-fuwu.png);"
                "  background-position: center;"
                "  background-repeat: no-repeat;"
                "  border-radius: 10px;"          // 圆角
                "  border: 1px solid rgba(0,0,0,75);"
                "}"
                );

    // 创建滑动开关
    ui->switchWidget->setStyleSheet(
                "QWidget#switchWidget {"
                "  background-color: #e0e0e0;"  // 灰色滑槽
                "  border-radius: 8px;"
                "}"
                );

    ui->switchButton->setStyleSheet(
                "QPushButton#switchButton {"
                "  background-color: white;"  // 白色按钮
                "  border-radius: 8px;"
                "}"
                );

    // 初始化动画
    slideAnimation = new QPropertyAnimation(ui->switchButton, "geometry");
    slideAnimation->setDuration(150);  // 200毫秒动画

    // 连接按钮点击事件
    connect(ui->switchButton, &QPushButton::clicked, this, &setwindow::toggleSwitch);

    // 初始隐藏所有服务器配置元素
    ui->dizhi->hide();
    ui->duankou->hide();
    ui->input_ip->hide();
    ui->input_prot->hide();
    ui->beijing->hide();

    // 加载服务器配置
    loadServerSettings();
}

setwindow::~setwindow()
{
    delete ui;
}

// 保存服务器配置
void setwindow::saveServerSettings()
{
    QSettings settings("MyCompany", "MyApp");

    QString ip = ui->input_ip->text().trimmed();
    QString portStr = ui->input_prot->text().trimmed();

    // 验证IP地址格式
    if (!ip.isEmpty()) {
        QHostAddress address;
        if (!address.setAddress(ip)) {
            QMessageBox::warning(this, "无效的IP地址", "请输入有效的IP地址格式");
            return;
        }
    }

    // 验证端口号
    bool portValid = false;
    int port = portStr.toInt(&portValid);
    if (!portStr.isEmpty() && (!portValid || port < 1 || port > 65535)) {
        QMessageBox::warning(this, "无效的端口号", "端口号必须是1-65535之间的整数");
        return;
    }

    // 保存配置
    settings.setValue("Server/IP", ip);
    settings.setValue("Server/Port", portStr);
    settings.setValue("Server/UseCustom", switchState);

    QMessageBox::information(this, "保存成功", "服务器配置已保存");
}

// 加载服务器配置
void setwindow::loadServerSettings()
{
    QSettings settings("MyCompany", "MyApp");

    QString ip = settings.value("Server/IP", "").toString();
    QString port = settings.value("Server/Port", "").toString();
    bool useCustom = settings.value("Server/UseCustom", false).toBool();

    ui->input_ip->setText(ip);
    ui->input_prot->setText(port);

    // 如果之前使用过自定义配置，恢复开关状态
    if (useCustom) {
        switchState = true;
        toggleSwitch(); // 触发UI更新
    }
}

// 鼠标事件处理
void setwindow::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        m_dragPosition = event->globalPos() - frameGeometry().topLeft();
        event->accept();
    }
}

void setwindow::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton) {
        move(event->globalPos() - m_dragPosition);
        event->accept();
    }
}

void setwindow::on_exit_clicked()
{
    close();
}

void setwindow::on_fanhui_clicked()
{
    // 获取当前窗口位置
    QPoint currentPos = this->pos();
    emit showMainWindow(currentPos);  // 发射信号
    close();                // 关闭当前窗口
}

void setwindow::toggleSwitch()
{
    switchState = !switchState;  // 切换状态

    // 设置动画
    QRect startRect = ui->switchButton->geometry();
    QRect endRect;

    if (switchState) {
        // 移动到右边（开启状态）
        endRect = QRect(ui->switchWidget->width() - ui->switchButton->width() - 2,
                        2,
                        ui->switchButton->width(),
                        ui->switchButton->height());

        // 更新滑槽颜色为绿色
        ui->switchWidget->setStyleSheet(
                    "QWidget#switchWidget {"
                    "  background-color: rgb(6,183,91);"  // 绿色滑槽
                    "  border-radius: 10px;"
                    "}"
                    );

        ui->dizhi->show();
        ui->duankou->show();
        ui->input_ip->show();
        ui->input_prot->show();
        ui->beijing->show();
    } else {
        // 移动到左边（关闭状态）
        endRect = QRect(2, 2,
                        ui->switchButton->width(),
                        ui->switchButton->height());

        // 更新滑槽颜色为灰色
        ui->switchWidget->setStyleSheet(
                    "QWidget#switchWidget {"
                    "  background-color: #e0e0e0;"  // 灰色滑槽
                    "  border-radius: 10px;"
                    "}"
                    );
        ui->dizhi->hide();
        ui->duankou->hide();
        ui->input_ip->hide();
        ui->input_prot->hide();
        ui->beijing->hide();
    }

    // 设置动画
    slideAnimation->setStartValue(startRect);
    slideAnimation->setEndValue(endRect);
    slideAnimation->start();
}

void setwindow::on_pying_clicked()
{
    // 保存服务器配置
    saveServerSettings();

    // 获取当前窗口位置
    QPoint currentPos = this->pos();
    emit showMainWindow(currentPos);  // 发射信号
    hide();                // 关闭当前窗口
}
