#include "gerengxx.h"
#include "ui_gerengxx.h"

gerengxx::gerengxx(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::gerengxx)
{
    ui->setupUi(this);
    // 1. 删除标题栏
    setWindowFlags(Qt::FramelessWindowHint);
    // 2. 设置窗口背景透明
    setAttribute(Qt::WA_TranslucentBackground);

    // 3. 添加背景图片样式表
    ui->centralwidget->setStyleSheet(
                "  QWidget#centralwidget {"
                "  background-image: url(:/img/img/gerengxx.png);"
                "  background-position: center;"
                "  background-repeat: no-repeat;"
                "  border-radius: 10px;"          // 圆角
                "  border: 1px solid rgba(0,0,0,75);" // 边框效果
                "}"
                );

}

gerengxx::~gerengxx()
{
    delete ui;
}


void gerengxx::setUserInfo(const QString& username, const QString& nickname, const QPixmap& avatar)
{
    // 设置头像
    ui->touxiang->setPixmap(avatar.scaled(ui->touxiang->size(),
                                       Qt::KeepAspectRatio,
                                       Qt::SmoothTransformation));

    // 设置昵称
    ui->names->setText(nickname);
    ui->nicheng->setText(nickname);

    // 设置账号
    ui->ID->setText(username);

}
