#include "home.h"
#include "ui_home.h"
#include <QScreen>
#include <QDebug>
#include <QKeyEvent> // 确保包含QKeyEvent头文件
#include <QApplication> // 添加此头文件
#include <QDesktopWidget> // 添加此头文件
#include <QPainter>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QPushButton>
#include <QMessageBox>
#include "mainwindow.h"
#include "shezhi.h"
#include "networkmanager.h"
#include <QDateTime>
#include <QCryptographicHash>
#include <QScrollBar>
#include <QAction>
#include <QMenu>
#include <QThread> // 添加QThread头文件
#include <QFileDialog> // 用于文件选择对话框
#include <QDesktopServices> // 用于打开文件
#include <QUrl> // 用于URL处理
#include <QDir> // 用于目录操作
#include <QTextDocument> // 用于文本块和文本片段处理
#include <QTextCursor> // 用于文本光标处理
#include <QTextBlock> // 用于文本块处理
#include <QTextFragment> // 用于文本片段处理
#include <QTextImageFormat> // 用于文本图片格式处理

home::home(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::home),
    friendwindow(nullptr),
    szwindow(nullptr),
    spwindow(nullptr),
    m_serverFriendAdded(false),
    m_chatDatabase()
{
    ui->setupUi(this);
    // 初始清除聊天框和验证列表
    ui->prints->clear();
    // 1. 删除标题栏
    setWindowFlags(Qt::FramelessWindowHint);
    // 2. 设置窗口背景透明
    setAttribute(Qt::WA_TranslucentBackground);

    // 3. 添加背景图片样式表
    ui->homeWidget->setStyleSheet(
                "  QWidget#homeWidget {"
                "  background-image: url(:/img/img/home.png);"
                "  background-position: center;"
                "  background-repeat: no-repeat;"
                "  border-radius: 10px;"          // 圆角
                "  border: 1px solid rgba(0,0,0,75);" // 边框效果
                "}"
                );

    ui->prints->setStyleSheet(
                // 保留现有样式
                "QListWidget {"
                "  background-color: rgb(243, 243, 243);"
                "  border: none;"
                "  font-size: 18px;"
                "  font-family: \"Microsoft YaHei\";"
                "}"

                // +++ 新增：禁用项的悬停和选中效果 +++
                "QListWidget::item {"
                "  background-color: transparent;"
                "  border: none;"
                "}"
                "QListWidget::item:hover {"
                "  background-color: transparent;"  // 悬停时透明
                "}"
                "QListWidget::item:selected {"
                "  background-color: transparent;" // 选中时透明
                "}"
                "QListWidget::item:selected:active {"
                "  background-color: transparent;" // 激活选中时透明
                "}"
                // +++ 结束新增 +++
                );


    ui->list_friend->setStyleSheet(
                "QListWidget {"
                "  background-color: white;"
                "  border: none;"
                "  outline: none;" // 移除选中时的虚线框
                "}"
                "QListWidget::item {"
                "  border-bottom: 1px solid #e0e0e0;" // 项之间的分隔线
                "}"
                "QScrollBar:vertical {"
                "  width: 8px;"
                "  background: transparent;"
                "}"
                );

    ui->more->setToolTip("更多");// 为more按钮设置鼠标悬停提示
    ui->more->setToolTipDuration(1000);//延迟1000毫秒显示

    ui->phone->setToolTip("手机");// 为more按钮设置鼠标悬停提示
    ui->phone->setToolTipDuration(1000);//延迟1000毫秒显示

    ui->xiaochengxu->setToolTip("小程序");// 为more按钮设置鼠标悬停提示
    ui->xiaochengxu->setToolTipDuration(1000);//延迟1000毫秒显示

    ui->souyiso->setToolTip("搜一搜");// 为more按钮设置鼠标悬停提示
    ui->souyiso->setToolTipDuration(1000);//延迟1000毫秒显示

    ui->shipinhao->setToolTip("视频号");// 为more按钮设置鼠标悬停提示
    ui->shipinhao->setToolTipDuration(1000);//延迟1000毫秒显示

    ui->friend_quan->setToolTip("朋友圈");// 为more按钮设置鼠标悬停提示
    ui->friend_quan->setToolTipDuration(1000);//延迟1000毫秒显示

    ui->shoucang->setToolTip("收藏");// 为more按钮设置鼠标悬停提示
    ui->shoucang->setToolTipDuration(1000);//延迟1000毫秒显示

    ui->tongxun->setToolTip("通讯录");// 为more按钮设置鼠标悬停提示
    ui->tongxun->setToolTipDuration(1000);//延迟1000毫秒显示

    ui->wxlt->setToolTip("微信");// 为more按钮设置鼠标悬停提示
    ui->wxlt->setToolTipDuration(1000);//延迟1000毫秒显示

    ui->prints->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn); // 永久显示滚动条
    // 初始隐藏发送按钮
    ui->send->hide();

    ui->xiaoxi->hide();
    ui->txl->hide();
    ui->list_yz->hide();
    ui->widget->hide();


    // 初始隐藏所有菜单
    hideAllMenus();

    // 连接输入框文本变化信号
    connect(ui->inputs, &QTextEdit::textChanged, this, &home::on_inputs_textChanged);
    // 连接发送按钮点击信号
    connect(ui->send, &QPushButton::clicked, this, &home::on_send_clicked);

    // 为所有需要处理点击的控件安装事件过滤器
    this->installEventFilter(this);
    ui->inputs->installEventFilter(this);
    ui->prints->installEventFilter(this);       // 添加聊天区域
    ui->list_friend->installEventFilter(this);  // 添加好友列表区域
    ui->homeWidget->installEventFilter(this);   // 添加主背景区域

    // 添加全屏按钮连接
    connect(ui->fangda, &QPushButton::clicked, this, &home::on_fangda_clicked);

    // 连接头像上传成功信号
    NetworkManager* netManager = NetworkManager::instance();
    connect(netManager, &NetworkManager::avatarDataReceived,
            this, &home::handleAvatarDataReceived);  // 直接连接槽函数

    connect(netManager, &NetworkManager::avatarDataReceived,
            this, [this](const QString& username, const QByteArray& data) {
        if (mywindow) {
            mywindow->handleAvatarDataReceived(username, data);
        }
    });

    // 连接文件按钮点击信号 - 使用Qt自动连接机制

    // 确保myhome的头像更新信号连接到home
    if (!mywindow) {
        mywindow = new myhome(this);
    }
    connect(mywindow, &myhome::avatarChangedForLabel,
            this, &home::updateTouxiangLabel);

    connect(netManager, &NetworkManager::avatarDataReceived,
            this, &home::handleAvatarDataReceived); // 直接连接到槽函数
    // 连接好友列表更新信号
    connect(netManager, &NetworkManager::friendListUpdated,
            this, [](const QStringList& friends) {
        // 这里可以更新UI中的好友列表显示
        qDebug() << "好友列表已更新:" << friends;
    });


    connect(netManager, &NetworkManager::requesterNicknameReceived,
            this, &home::handleRequesterNickname);

    connect(NetworkManager::instance(), &NetworkManager::friendRequestReceived,
            this, &home::handleFriendRequest);
    connect(netManager, &NetworkManager::friendListUpdated,
            this, &home::updateFriendList);
    
    // 处理所有未处理的好友请求
    QStringList pendingRequests = NetworkManager::instance()->getPendingFriendRequests();
    for (const QString& sender : pendingRequests) {
        qDebug() << "HOME: 处理未处理的好友请求 from" << sender;
        handleFriendRequest(sender);
    }

    m_friendListDelegate = new FriendListDelegate(this);
    ui->list_friend->setItemDelegate(m_friendListDelegate);

    // 启用鼠标跟踪以支持悬停效果
    ui->list_friend->setMouseTracking(true);
    addServerAsFriend();

    // 初始化表情相关功能
    // 常用表情列表（使用Unicode表情字符）
    m_commonEmojis = QStringList() << "😊" << "😢" << "😂" << "😉" << "😋" << "😮" << "😯" << "😄" << "😛" << "😜" << "😘" << "😀" << "😎" << "😏" << "😒" << "😔" << "😢" << "😤" << "😠" << "😣" << "😞" << "😓" << "😥" << "😨" << "😱" << "😳" << "😵" << "😡" << "😷" << "😴" << "😈" << "👿" << "👽" << "👾" << "🤖" << "💩";
    
    // 初始化表情选择窗口
    initEmojiWindow();
    
    // 连接表情按钮点击信号
    connect(ui->emo, &QPushButton::clicked, this, &home::on_emo_clicked);

    connect(ui->list_friend, &QListWidget::itemClicked, this, [this](QListWidgetItem *item) {
        QString fullPeer = item->data(Qt::UserRole).toString();
        // +++ 提取昵称 +++
        QString nickname = getNicknameFromUsername(fullPeer);

        // 使用基础用户名进行逻辑判断
        QString peer = getBaseUsername(fullPeer);

        if (peer == "SERVER") {
            onServerFriendClicked();
        } else {
            qDebug()<<"昵称："<<nickname;
            // 保存当前聊天记录
            saveCurrentChat();
            m_currentActivePeer = peer;
            loadChatHistory(peer);
            ui->username->setText(nickname); // 使用昵称设置用户名标签

            // 重置未读计数
            item->setData(Qt::UserRole + 2, 0);
            updateUnreadBadge(item, 0);

            // 更新界面
            ui->list_friend->show();
            ui->widget->hide();
            ui->xiaoxi->hide();
            ui->txl->hide();
            ui->list_yz->hide();
        }
    });

    connect(NetworkManager::instance(), &NetworkManager::privateMessageReceived,
            this, &home::onPrivateMessageReceived);

    // 添加聊天区域滚动事件监控
    ui->prints->viewport()->installEventFilter(this);

    connect(NetworkManager::instance(), &NetworkManager::avatarDataReceived,
            this, &home::handleFriendAvatarDataReceived);

    connect(this, &home::showFriendInfo, this, &home::handleFriendInfoRequest);
    // 新增右键菜单初始化
    m_contextMenu = new QMenu(this);
    m_deleteAction = new QAction("删除好友", this);
    m_deleteAction->setObjectName("deleteAction");
    m_contextMenu->addAction(m_deleteAction);

    // 设置好友列表支持右键菜单
    ui->list_friend->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->list_friend, &QListWidget::customContextMenuRequested,
            this, &home::showFriendContextMenu);
    connect(m_deleteAction, &QAction::triggered,
            this, &home::onDeleteFriendAction);

    // 设置删除按钮样式为红色
    m_contextMenu->setStyleSheet(
        "QMenu {"
        "   background-color: white;"
        "   border: 1px solid #e0e0e0;"
        "   border-radius: 4px;"
        "   padding: 5px;"
        "}"
        "QMenu::item {"
        "   padding: 5px 20px 5px 10px;"
        "}"
        "QMenu::item:selected {"
        "   background-color: #f5f5f5;"
        "}"
        "QMenu::item#deleteAction {"
        "   color: red;"  // 通过 objectName 设置特定样式
        "}"
    );

    // 新增删除响应连接，始终使用QueuedConnection确保线程安全
    connect(NetworkManager::instance(), &NetworkManager::friendDeleted,
            this, [this](const QString& friendName) {
                QMessageBox::information(this, "操作成功",
                                     QString("已成功删除好友 %1").arg(friendName));
            }, Qt::QueuedConnection);
    
    // 连接错误信号
    connect(NetworkManager::instance(), &NetworkManager::errorOccurred,
            this, [this](const QString& errorMsg) {
                QMessageBox::warning(this, "错误", errorMsg);
            }, Qt::QueuedConnection);
}

home::~home()
{
    // 在析构函数中断开与NetworkManager的所有连接，防止访问已删除的对象
    NetworkManager::instance()->disconnect(this);
    delete ui;
}

// 实现右键菜单显示
void home::showFriendContextMenu(const QPoint &pos)
{
    QListWidgetItem *item = ui->list_friend->itemAt(pos);
    if (item) {
        QString fullFriend = item->data(Qt::UserRole).toString();
        QString friendName = getBaseUsername(fullFriend);

        // 排除服务器项
        if (friendName == "SERVER") return;

        m_contextMenuFriend = friendName;
        m_contextMenu->exec(ui->list_friend->viewport()->mapToGlobal(pos));
    }
}

// 实现删除好友操作
void home::onDeleteFriendAction()
{
    if (m_contextMenuFriend.isEmpty()) {
        qDebug() << "onDeleteFriendAction: m_contextMenuFriend is empty";
        return;
    }

    // 确认对话框
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "删除好友",
                                  QString("确定要删除好友 <b>%1</b> 吗？此操作不可撤销！")
                                  .arg(m_contextMenuFriend),
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        qDebug() << "开始删除好友:" << m_contextMenuFriend;
        
        // 发送删除请求到服务器
        NetworkManager::instance()->sendTcpMessage(
                    QString("DELETE_FRIEND:%1").arg(m_contextMenuFriend));
        
        // 删除后立即请求最新的好友列表，确保数据同步
        NetworkManager::instance()->sendTcpMessage("REQUEST_FRIEND_LIST");

        // 立即从本地移除
        bool removed = false;
        qDebug() << "开始在好友列表中查找匹配项:" << m_contextMenuFriend;
        qDebug() << "好友列表总数:" << ui->list_friend->count();
        
        // 使用复制的列表进行遍历，避免并发修改问题
        QList<QListWidgetItem*> friendItems;
        for (int i = 0; i < ui->list_friend->count(); ++i) {
            friendItems.append(ui->list_friend->item(i));
        }
        
        for (int i = 0; i < friendItems.size(); ++i) {
            QListWidgetItem* item = friendItems[i];
            if (!item) {
                qDebug() << "onDeleteFriendAction: 找到空的list item at index" << i;
                continue;
            }
            
            QString userRoleData = item->data(Qt::UserRole).toString();
            if (userRoleData.isEmpty()) {
                qDebug() << "onDeleteFriendAction: 空的UserRole数据 at index" << i;
                continue;
            }
            
            QString fullPeer = userRoleData;
            QString peer = getBaseUsername(fullPeer);
            
            qDebug() << "第" << i << "项: 完整数据=" << fullPeer << ", 提取后的用户名=" << peer << ", 目标用户名=" << m_contextMenuFriend;
            qDebug() << "比较结果:" << (peer == m_contextMenuFriend);

            if (peer == m_contextMenuFriend || fullPeer == m_contextMenuFriend) {
                qDebug() << "找到匹配的好友项，准备移除";
                // 从原始列表中移除项
                int originalIndex = ui->list_friend->row(item);
                if (originalIndex != -1) {
                    QListWidgetItem* removedItem = ui->list_friend->takeItem(originalIndex);
                    if (removedItem) {
                        // 获取widget并删除它（如果有的话）
                        QWidget* widget = ui->list_friend->itemWidget(removedItem);
                        if (widget) {
                            delete widget;
                        }
                        // 删除item
                        delete removedItem;
                        removed = true;
                        qDebug() << "成功移除好友项";
                        break;
                    } else {
                        qDebug() << "onDeleteFriendAction: takeItem返回空指针";
                    }
                } else {
                    qDebug() << "onDeleteFriendAction: 找不到项在原始列表中的索引";
                }
                break;
            }
        }
        
        if (!removed) {
            qDebug() << "onDeleteFriendAction: 没有找到匹配的好友项";
        } else {
            qDebug() << "onDeleteFriendAction: 成功移除好友项";
        }

        // 如果删除的是当前聊天对象
        if (m_currentActivePeer == m_contextMenuFriend) {
            qDebug() << "删除的是当前聊天对象，清理聊天界面";
            ui->prints->clear();
            ui->username->setText("");
            m_currentActivePeer.clear();
        }
        
        // 删除与该好友相关的聊天记录
        qDebug() << "开始删除与" << m_contextMenuFriend << "的聊天记录";
        if (m_chatDatabase.deleteMessagesWithPeer(m_contextMenuFriend)) {
            qDebug() << "成功删除与" << m_contextMenuFriend << "的聊天记录";
        } else {
            qDebug() << "删除与" << m_contextMenuFriend << "的聊天记录失败";
        }
        
        // 清理与该好友相关的本地数据结构
        qDebug() << "开始清理与" << m_contextMenuFriend << "相关的本地数据";
        
        // 清理最近消息记录
        QMutableHashIterator<QString, QDateTime> recentIt(m_recentMessages);
        while (recentIt.hasNext()) {
            recentIt.next();
            QString fingerprint = recentIt.key();
            // 检查指纹中是否包含该好友的用户名（简单匹配）
            if (fingerprint.contains(m_contextMenuFriend)) {
                recentIt.remove();
            }
        }
        
        // 清理消息哈希记录
        QMutableSetIterator<QString> hashIt(m_receivedMessageHashes);
        while (hashIt.hasNext()) {
            QString hash = hashIt.next();
            // 检查哈希中是否包含该好友的用户名（简单匹配）
            if (hash.contains(m_contextMenuFriend)) {
                hashIt.remove();
            }
        }
        
        qDebug() << "完成清理与" << m_contextMenuFriend << "相关的本地数据";
        
        // 将删除的好友添加到已删除集合中
        m_deletedFriends.insert(m_contextMenuFriend);
        qDebug() << "已将好友" << m_contextMenuFriend << "添加到已删除集合";
        
        // 立即更新界面（刷新好友列表）
        update();
        ui->list_friend->update();
    }

    m_contextMenuFriend.clear();
    qDebug() << "onDeleteFriendAction: 完成";
}

// 更新好友列表中的头像
void home::updateFriendAvatar(const QString& username, const QPixmap& avatar)
{
    for (int i = 0; i < ui->list_friend->count(); ++i) {
        QListWidgetItem* item = ui->list_friend->item(i);
        QString itemUsername = getBaseUsername(item->data(Qt::UserRole).toString());

        if (itemUsername == username) {
            if (QWidget* widget = ui->list_friend->itemWidget(item)) {
                if (QLabel* avatarLabel = widget->findChild<QLabel*>()) {
                    QPixmap scaled = avatar.scaled(43, 43, Qt::KeepAspectRatio, Qt::SmoothTransformation);
                    avatarLabel->setPixmap(createRoundedPixmap(scaled, 5));
                }
            }
            break;
        }
    }
}

// 处理收到的头像数据
void home::handleFriendAvatarDataReceived(const QString& username, const QByteArray& data)
{
    if (username == m_username) return; // 自己的头像单独处理

    // 保存到数据库
    m_chatDatabase.saveAvatar(username, data);

    // 加载为QPixmap
    QPixmap avatar;
    avatar.loadFromData(data);

    if (!avatar.isNull()) {
        // 更新缓存
        m_avatarCache[username] = avatar;

        // 更新UI中的好友头像（在好友列表中）
        updateFriendAvatar(username, avatar);

        // +++ 新增：更新聊天界面中的头像 +++
        if (!m_currentActivePeer.isEmpty() &&
                getBaseUsername(m_currentActivePeer) == username) {
            // 重新加载当前聊天记录
            loadChatHistory(m_currentActivePeer);
        }
    }
}
QString home::getNicknameFromUsername(const QString& username) const
{
    if (username.contains('|')) {
        QStringList parts = username.split('|');
        if (parts.size() >= 2) {
            return parts[1]; // 返回昵称部分
        }
    }
    return username; // 没有昵称时返回原始字符串
}


QPixmap home::loadAvatar(const QString& path, const QSize& size, int radius)
{
    static QPixmap cachedAvatar; // 静态变量缓存默认头像

    if (cachedAvatar.isNull()) {
        cachedAvatar.load(":/img/img/wxtx.png");
        if (cachedAvatar.isNull()) {
            // 创建纯色头像作为最终后备
            cachedAvatar = QPixmap(46, 46);
            cachedAvatar.fill(QColor("#95EC69"));
        }
    }

    QPixmap avatar(path);
    if (avatar.isNull()) {
        avatar = cachedAvatar;
    }

    return createRoundedPixmap(avatar.scaled(size, Qt::KeepAspectRatio, Qt::SmoothTransformation), radius);
}


void home::onPrivateMessageReceived(const QString& sender, const QString& message)
{
    if (message.startsWith("OFFLINE_MSG:")) {
        int firstColon = message.indexOf(':');
        int secondColon = message.indexOf(':', firstColon + 1);
        int thirdColon = message.indexOf(':', secondColon + 1);

        if (firstColon == -1 || secondColon == -1) {
            qWarning() << "离线消息格式无效:" << message;
            return;
        }

        QString realSender;
        QString realMessage;
        QString timestampStr;

        if (thirdColon != -1) {
            // 新格式: OFFLINE_MSG:sender:timestamp:message
            realSender = message.mid(firstColon+1, secondColon-firstColon-1);
            timestampStr = message.mid(secondColon+1, thirdColon-secondColon-1);
            realMessage = message.mid(thirdColon+1);
            // 重新构建离线消息格式，保留时间戳
            QString offlineMessage = "OFFLINE_MSG:" + realSender + ":" + timestampStr + ":" + realMessage;
            processIncomingMessage(realSender, offlineMessage, true);
        } else {
            // 旧格式: OFFLINE_MSG:sender:message
            realSender = message.mid(firstColon+1, secondColon-firstColon-1);
            realMessage = message.mid(secondColon+1);
            // 重新构建离线消息格式
            QString offlineMessage = "OFFLINE_MSG:" + realSender + ":" + realMessage;
            processIncomingMessage(realSender, offlineMessage, true);
        }
        return;
    }

    // 普通消息处理
    processIncomingMessage(sender, message, false);
}

// 新增函数：统一处理接收到的消息
void home::processIncomingMessage(const QString& sender, const QString& message, bool isOffline)
{
    // 清理发送者字符串
    QString cleanSender = sender;
    if (cleanSender.contains(':')) {
        cleanSender = cleanSender.split(':').first();
    }
    // 生成消息指纹 - 为离线消息添加特殊标记
    QString fingerprintBase = isOffline ? "OFFLINE_" : "ONLINE_";
    QString messageFingerprint = fingerprintBase + generateMessageFingerprint(cleanSender, message);

    QString cleanMessage = message;
    qint64 messageTimestamp = QDateTime::currentMSecsSinceEpoch(); // 默认使用当前时间戳

    if (isOffline && message.startsWith("OFFLINE_MSG:")) {
        // 移除离线标记，保存原始消息
        int firstColon = message.indexOf(':');
        int secondColon = message.indexOf(':', firstColon + 1);
        int thirdColon = message.indexOf(':', secondColon + 1);
        
        if (secondColon != -1) {
            if (thirdColon != -1) {
                // 格式: OFFLINE_MSG:sender:timestamp:message
                QString timestampStr = message.mid(secondColon + 1, thirdColon - secondColon - 1);
                bool ok;
                qint64 ts = timestampStr.toLongLong(&ok);
                if (ok) {
                    messageTimestamp = ts;
                }
                cleanMessage = message.mid(thirdColon + 1);
            } else {
                // 旧格式: OFFLINE_MSG:sender:message
                cleanMessage = message.mid(secondColon + 1);
            }
        }
    } else if (message.startsWith("PRIVATE_MSG:")) {
        // 处理普通消息中的时间戳
        int firstColon = message.indexOf(':');
        int secondColon = message.indexOf(':', firstColon + 1);
        int thirdColon = message.indexOf(':', secondColon + 1);
        if (firstColon != -1 && secondColon != -1 && thirdColon != -1) {
            // 格式: PRIVATE_MSG:peerId:timestamp:message
            QString timestampStr = message.mid(secondColon + 1, thirdColon - secondColon - 1);
            bool ok;
            qint64 ts = timestampStr.toLongLong(&ok);
            if (ok) {
                messageTimestamp = ts;
            }
            cleanMessage = message.mid(thirdColon + 1);
        }
    }


    // 检查是否重复消息（只检查最近秒内的消息）
    const int duplicateCheckWindowSecs = 1;
    QDateTime currentTime = QDateTime::currentDateTime();

    // 清理过期的消息记录
    QMutableHashIterator<QString, QDateTime> it(m_recentMessages);
    while (it.hasNext()) {
        it.next();
        if (it.value().secsTo(currentTime) > duplicateCheckWindowSecs) {
            it.remove();
        }
    }

    // 检查是否短时间内重复消息
    if (m_recentMessages.contains(messageFingerprint)) {
        qDebug() << "检测到可能的重复消息，来自:" << cleanSender << "内容:" << message;
        return;
    }

    // 记录新消息
    m_recentMessages.insert(messageFingerprint, currentTime);

    // 保存消息到数据库（离线消息也需要保存，使用清理后的消息）
    saveMessageToDatabase(cleanSender, m_username, cleanMessage, messageTimestamp);

    // 显示消息（如果是当前聊天对象，使用清理后的消息）
    QString currentPeerBase = getBaseUsername(m_currentActivePeer);
    QString senderBase = getBaseUsername(cleanSender);

    if (currentPeerBase == senderBase) {
        displayMessageBubble(cleanSender, cleanMessage, messageTimestamp);
    } else {
        // 更新未读计数
        for (int i = 0; i < ui->list_friend->count(); ++i) {
            QListWidgetItem* item = ui->list_friend->item(i);
            QString peer = getBaseUsername(item->data(Qt::UserRole).toString());

            if (peer == senderBase) {
                int unreadCount = item->data(Qt::UserRole + 2).toInt();
                item->setData(Qt::UserRole + 2, unreadCount + 1);
                updateUnreadBadge(item, unreadCount + 1);

                // 添加系统通知
                if (isOffline) {
                    showSystemNotification(senderBase, "您有新的离线消息");
                }
                break;
            }
        }
    }
}

// 生成消息指纹（结合发送者、内容和时间戳）
QString home::generateMessageFingerprint(const QString& sender, const QString& content)
{
    // 移除时间戳部分，只使用发送者和内容生成指纹
    QString combined = sender + "|" + content;
    QByteArray hash = QCryptographicHash::hash(combined.toUtf8(), QCryptographicHash::Sha256);
    return QString(hash.toHex());
}

void home::updateUnreadBadge(QListWidgetItem* item, int count)
{
    QWidget* widget = ui->list_friend->itemWidget(item);
    if (!widget) return;

    QLabel* badge = widget->findChild<QLabel*>("unreadBadge");
    if (!badge) {
        badge = new QLabel(widget);
        badge->setObjectName("unreadBadge");
        badge->setStyleSheet(
                    "QLabel {"
                    "  background-color: red;"
                    "  color: white;"
                    "  border-radius: 10px;"
                    "  min-width: 20px;"
                    "  min-height: 20px;"
                    "  padding: 2px;"
                    "  font-size: 10px;"
                    "}"
                    );
        badge->setAlignment(Qt::AlignCenter);

        QHBoxLayout* layout = qobject_cast<QHBoxLayout*>(widget->layout());
        if (layout) {
            layout->addWidget(badge);
        }
    }

    if (count > 0) {
        badge->setText(QString::number(count));
        badge->show();
    } else {
        badge->hide();
    }
}

void home::loadChatHistory(const QString& peer)
{
    QString basePeer = getBaseUsername(peer);
    m_currentActivePeer = basePeer;
    ui->prints->clear();

    // 初始化或重置聊天状态
    if (!m_chatHistoryState.contains(basePeer)) {
        m_chatHistoryState[basePeer] = ChatHistoryState();
    }

    // +++ 确保加载最新头像 +++
    if (!m_avatarCache.contains(basePeer)) {
        QPixmap avatar = m_chatDatabase.getAvatarPixmap(basePeer);
        if (!avatar.isNull()) {
            m_avatarCache[basePeer] = avatar;
        }
    }

    // 加载初始消息（最近20条）
    loadInitialMessages(basePeer);
}

void home::showSystemNotification(const QString& sender, const QString& message)
{
    // 在实际应用中，这里可以实现系统通知
    qDebug() << "系统通知:" << sender << ":" << message;

    // 示例：在状态栏显示通知
    Q_UNUSED(sender);
    Q_UNUSED(message);
    // 实际实现可以根据需要添加
}

// 加载初始消息
void home::loadInitialMessages(const QString& peer)
{
    auto& state = m_chatHistoryState[peer];
    if (state.isLoading) return;

    state.isLoading = true;
    state.hasMore = true;

    // 加载最近的20条消息
    QList<QPair<QString, QPair<QString, qint64>>> messages = m_chatDatabase.loadMessagesPaged(peer, 20, 0);
    state.loadedCount = messages.size();

    // 显示消息
    for (const auto& msg : messages) {
            // 加载历史消息时，使用数据库中保存的时间戳
            displayMessageBubble(msg.first, msg.second.first, msg.second.second);
        }

    state.isLoading = false;

    // 滚动到底部显示最新消息
    ui->prints->scrollToBottom();
}



// 加载更多历史消息
// 修改loadMoreMessages函数
void home::loadMoreMessages(const QString& peer)
{
    auto& state = m_chatHistoryState[peer];
    if (state.isLoading || !state.hasMore) {
        return;
    }

    state.isLoading = true;

    // 添加加载提示
    QListWidgetItem* loadingItem = new QListWidgetItem("加载中...");
    ui->prints->insertItem(0, loadingItem);

    // 记录当前滚动位置
    int scrollPos = ui->prints->verticalScrollBar()->value();
    int firstItemHeight = 0;

    // 加载下一页（20条）
    QList<QPair<QString, QPair<QString, qint64>>> messages = m_chatDatabase.loadMessagesPaged(peer, 20, state.loadedCount);

    if (!messages.isEmpty()) {
        // 在顶部插入消息
        for (const auto& msg : messages) {
            QWidget* messageWidget = createMessageWidgetForBubble(msg.first, msg.second.first);
            QListWidgetItem* item = new QListWidgetItem();
            QSize size = messageWidget->sizeHint();
            item->setSizeHint(size);
            // 保存时间戳到列表项数据中
            item->setData(Qt::UserRole + 10, msg.second.second);

            if (firstItemHeight == 0) {
                firstItemHeight = size.height();
            }

            ui->prints->insertItem(0, item);  // 在顶部插入
            ui->prints->setItemWidget(item, messageWidget);
        }

        // 更新已加载数量
        state.loadedCount += messages.size();

        // 检查是否还有更多消息
        state.hasMore = (messages.size() == 20);

        // 恢复滚动位置（保持用户查看的上下文）
        ui->prints->verticalScrollBar()->setValue(scrollPos + firstItemHeight * messages.size());
    } else {
        state.hasMore = false;
    }

    // 移除加载提示
    delete ui->prints->takeItem(0);
    state.isLoading = false;
}


void home::saveCurrentChat()
{
    if (m_currentActivePeer.isEmpty()) return;
}




// 添加新的消息气泡创建函数
QWidget* home::createSelfMessageBubble(const QString& message)
{
    // 创建消息控件容器
    QWidget* messageWidget = new QWidget();
    QHBoxLayout* mainLayout = new QHBoxLayout(messageWidget);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(0);

    // 左侧占位空间
    mainLayout->addStretch(1);

    // 右侧内容区域
    QWidget* rightColumn = new QWidget();
    QVBoxLayout* rightLayout = new QVBoxLayout(rightColumn);
    rightLayout->setContentsMargins(0, 0, 0, 0);
    rightLayout->setSpacing(0);

    // 创建消息气泡（绿色背景）
    QWidget* bubbleWidget = createMessageBubble(message, true);
    
    // 创建尖角（指向右边）
    TriangleLabel* triangleLabel = new TriangleLabel();
    triangleLabel->setFixedSize(6, 10);
    triangleLabel->setProperty("pointLeft", false);  // 设置方向为右边
    triangleLabel->setProperty("color", QColor(149, 236, 105)); // 设置绿色

    // 创建头像
    QLabel* avatarLabel = new QLabel();
    avatarLabel->setFixedSize(40, 40);
    QPixmap selfAvatar;
    if (m_currentAvatar.isNull()) {
        selfAvatar = loadAvatar(":/img/img/wxtx.png", QSize(40, 40), 6);
    } else {
        selfAvatar = createRoundedPixmap(m_currentAvatar.scaled(
                                             QSize(40, 40), Qt::KeepAspectRatio, Qt::SmoothTransformation), 6);
    }
    avatarLabel->setPixmap(selfAvatar);

    // 创建消息容器
    QWidget* messageContainer = new QWidget();
    int containerWidth = bubbleWidget->width() + triangleLabel->width() + avatarLabel->width() + 5;
    int containerHeight = qMax(bubbleWidget->height(), avatarLabel->height());
    messageContainer->setFixedSize(containerWidth, containerHeight);

    // 定位组件
    bubbleWidget->setParent(messageContainer);
    bubbleWidget->move(0, 0);

    int triangleX = bubbleWidget->width();
    int triangleY = (avatarLabel->height() - triangleLabel->height()) / 2;
    triangleLabel->setParent(messageContainer);
    triangleLabel->move(triangleX, triangleY);

    int avatarX = triangleX + triangleLabel->width() + 5;
    avatarLabel->setParent(messageContainer);
    avatarLabel->move(avatarX, 0);

    // 添加到右侧列
    rightLayout->addWidget(messageContainer, 0, Qt::AlignTop | Qt::AlignRight);

    // 添加到主布局
    mainLayout->addWidget(rightColumn, 0, Qt::AlignTop | Qt::AlignRight);

    return messageWidget;
}

QWidget* home::createPeerMessageBubble(const QString& message, const QString& sender)
{

    // +++ 使用缓存的头像 +++
    QString baseSender = getBaseUsername(sender);
    QPixmap peerAvatar;

    // 从缓存获取头像
    if (m_avatarCache.contains(baseSender)) {
        peerAvatar = m_avatarCache[baseSender];
    } else {
        // 从数据库加载头像
        peerAvatar = m_chatDatabase.getAvatarPixmap(baseSender);
        m_avatarCache[baseSender] = peerAvatar;
    }

    // 如果缓存中没有且数据库加载失败，使用默认头像
    if (peerAvatar.isNull()) {
        peerAvatar = QPixmap(":/img/img/default_avatar.png");
    }

    // 创建消息控件容器
    QWidget* messageWidget = new QWidget();
    QHBoxLayout* mainLayout = new QHBoxLayout(messageWidget);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(0);

    // 左侧内容区域
    QWidget* leftColumn = new QWidget();
    QVBoxLayout* leftLayout = new QVBoxLayout(leftColumn);
    leftLayout->setContentsMargins(0, 0, 0, 0);
    leftLayout->setSpacing(0);

    /// 创建头像 - 使用缓存的头像
    ClickableLabel* avatarLabel = new ClickableLabel();
    avatarLabel->setFixedSize(40, 40);
    // +++ 使用缓存的头像 +++
    QPixmap scaledAvatar = peerAvatar.scaled(40, 40, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    avatarLabel->setPixmap(createRoundedPixmap(scaledAvatar, 6));

    // 创建尖角（指向左边）
    TriangleLabel* triangleLabel = new TriangleLabel();
    triangleLabel->setFixedSize(6, 10);
    triangleLabel->setProperty("pointLeft", true);  // 设置方向为左边
    triangleLabel->setProperty("color", QColor(254, 254, 254)); // 设置白色

    // 创建消息气泡（白色背景）
    QWidget* bubbleWidget = createMessageBubble(message, false);

    // 创建消息容器
    QWidget* messageContainer = new QWidget();
    int containerWidth = bubbleWidget->width() + triangleLabel->width() + avatarLabel->width() + 5;
    int containerHeight = qMax(bubbleWidget->height(), avatarLabel->height());
    messageContainer->setFixedSize(containerWidth, containerHeight);

    // 定位组件
    avatarLabel->setParent(messageContainer);
    avatarLabel->move(0, 0);

    int triangleX = avatarLabel->width() + 5;
    int triangleY = (avatarLabel->height() - triangleLabel->height()) / 2;
    triangleLabel->setParent(messageContainer);
    triangleLabel->move(triangleX, triangleY);

    int bubbleX = triangleX + triangleLabel->width();
    bubbleWidget->setParent(messageContainer);
    bubbleWidget->move(bubbleX, 0);

    // 添加到左侧列
    leftLayout->addWidget(messageContainer, 0, Qt::AlignTop | Qt::AlignLeft);

    // 添加到主布局
    mainLayout->addWidget(leftColumn, 0, Qt::AlignTop | Qt::AlignLeft);
    mainLayout->addStretch(1); // 右侧占位空间
    // 添加鼠标点击事件
    avatarLabel->setCursor(Qt::PointingHandCursor);
    connect(avatarLabel, &ClickableLabel::clicked, [this, sender]() {
        QString baseSender = getBaseUsername(sender);
        emit showFriendInfo(baseSender);
    });

    return messageWidget;
}

// 处理好友信息请求
void home::handleFriendInfoRequest(const QString& username)
{
    // 如果窗口已存在，则激活并置顶
    if (m_friendInfoWindow) {
        m_friendInfoWindow->activateWindow();
        m_friendInfoWindow->raise();
        return;
    }

    // 创建新窗口
    m_friendInfoWindow = new gerengxx(this);
    connect(m_friendInfoWindow, &gerengxx::destroyed,
            this, &home::onFriendInfoWindowClosed);

    // 设置模态并添加半透明背景
    m_friendInfoWindow->setWindowModality(Qt::ApplicationModal);
    m_friendInfoWindow->setAttribute(Qt::WA_DeleteOnClose);

    // 设置好友信息
    QString nickname = m_friendNicknameMap.value(username, username);
    QPixmap avatar = m_avatarCache.value(username);

    if (avatar.isNull()) {
        avatar = QPixmap(":/img/img/default_avatar.png");
    }

    // 设置信息到窗口
    m_friendInfoWindow->setUserInfo(username, nickname, avatar);

    m_friendInfoWindow->move(400, 100);
    m_friendInfoWindow->show();
}

// 信息窗口关闭处理
void home::onFriendInfoWindowClosed()
{
    m_friendInfoWindow = nullptr;
}

// 统一的显示消息函数
void home::displayMessageBubble(const QString& sender, const QString& message, qint64 timestamp)
{
    // 处理离线消息显示
    QString displayMessage = message;
    QString cleanSender = sender;
    if (cleanSender.contains(':')) {
        cleanSender = cleanSender.split(':').first();
    }
    if (m_currentAvatar.isNull()) {
        qDebug() << "没有找到对应头像";
        m_currentAvatar = QPixmap(":/img/img/wxtx.png");
    }

    QWidget* messageWidget = nullptr;

    if (sender == m_username) {
        messageWidget = createSelfMessageBubble(displayMessage);
    } else {
        // 修复：直接使用原始消息创建气泡
        messageWidget = createPeerMessageBubble(displayMessage, sender);
    }

    // 创建列表项
    QListWidgetItem* item = new QListWidgetItem();
    // 确保消息之间有一致的垂直间距
    QSize itemSize = messageWidget->sizeHint();
    // 设置固定的垂直间距（12像素）
    item->setSizeHint(QSize(itemSize.width(), itemSize.height() + 12)); // 12像素为垂直间距
    
    // 使用传入的时间戳，确保消息顺序正确
    qint64 messageTimestamp = timestamp;
    
    // 保存时间戳到列表项数据中
    item->setData(Qt::UserRole + 10, messageTimestamp);
    
    // 根据时间戳找到正确的插入位置
    int insertIndex = ui->prints->count();
    for (int i = 0; i < ui->prints->count(); ++i) {
        QListWidgetItem* existingItem = ui->prints->item(i);
        qint64 existingTimestamp = existingItem->data(Qt::UserRole + 10).toLongLong();
        if (existingTimestamp > messageTimestamp) {
            insertIndex = i;
            break;
        }
    }
    
    // 插入到正确位置
    ui->prints->insertItem(insertIndex, item);
    ui->prints->setItemWidget(item, messageWidget);
    
    // 如果是最新消息，滚动到底部
    if (insertIndex == ui->prints->count() - 1) {
        ui->prints->scrollToBottom();
    }
}


void home::saveMessageToDatabase(const QString& sender, const QString& receiver, const QString& message, qint64 timestamp)
{
    if (m_username.isEmpty()) return;
    QString cleanSender = sender;
    if (cleanSender.contains(':')) {
        cleanSender = cleanSender.split(':').first();
    }

    bool success = m_chatDatabase.saveMessage(cleanSender, receiver, message, timestamp);
    qDebug() << "保存消息到数据库:" << (success ? "成功" : "失败")
             << "| 发送者:" << cleanSender << "接收者:" << receiver
             << "时间戳:" << timestamp;
}

QString home::getNickname(const QString& username) const
{
    // 如果是当前用户，返回自己的昵称
    if (username == m_username) {
        return m_nickname;
    }
    // 默认返回用户名
    return username;
}



void home::displayMessageInChat(const QString& sender, const QString& message)
{
    // 使用当前时间作为时间戳
    displayMessageBubble(sender, message, QDateTime::currentMSecsSinceEpoch());
}

QWidget* home::createMessageBubble(const QString& message, bool isSelf)
{
    QWidget* container = new QWidget();
    QVBoxLayout* layout = new QVBoxLayout(container);
    layout->setContentsMargins(10, 10, 10, 10);
    layout->setSpacing(0);
    
    QString backgroundColor = isSelf ? "#95EC69" : "#FFFFFF";
    QString textColor = isSelf ? "#000000" : "#333333";
    
    container->setStyleSheet(
        "QWidget { background-color: " + backgroundColor + "; "
        "color: " + textColor + "; "
        "border-radius: 10px; "
        "max-width: 500px; "
        "}"
    );
    
    // 检查是否为图片消息
    if (message.startsWith("[IMAGE:") && message.endsWith("]")) {
        // 提取图片路径
        QString imagePath = message.mid(7, message.length() - 8);
        
        QLabel* imageLabel = new QLabel(container);
        imageLabel->setAlignment(Qt::AlignCenter);
        
        QPixmap pixmap(imagePath);
        if (!pixmap.isNull()) {
            // 缩放图片以适应气泡
            QPixmap scaledPixmap = pixmap.scaled(
                        450, 450, // 最大尺寸
                        Qt::KeepAspectRatio, 
                        Qt::SmoothTransformation);
            imageLabel->setPixmap(scaledPixmap);
        } else {
            imageLabel->setText("图片加载失败");
        }
        
        // 设置属性，用于在eventFilter中识别图片消息
        imageLabel->setProperty("isImageMessage", true);
        imageLabel->setProperty("originalImagePath", imagePath);
        
        // 安装事件过滤器
        imageLabel->installEventFilter(this);
        
        layout->addWidget(imageLabel);
        imageLabel->setWordWrap(true);
        imageLabel->setStyleSheet("border: none; padding: 0;");
        // 设置鼠标指针为手型
        imageLabel->setCursor(Qt::PointingHandCursor);
    } else {
        // 普通文本消息
        QLabel* textLabel = new QLabel(container);
        textLabel->setText(message);
        textLabel->setWordWrap(true);
        textLabel->setStyleSheet("border: none; padding: 0;");
        layout->addWidget(textLabel);
    }
    
    container->setLayout(layout);
    container->setFixedSize(container->sizeHint());
    return container;
}

QWidget* home::createAvatarWidget(bool isSelf)
{
    QLabel* avatar = new QLabel();
    avatar->setFixedSize(40, 40);

    QPixmap avatarPix;
    if (isSelf) {
        avatarPix = m_currentAvatar;
    } else {
        // 获取对方头像（简化实现）
        avatarPix = QPixmap(":/img/img/default_avatar.png");
    }

    avatar->setPixmap(createRoundedPixmap(avatarPix, 8));
    return avatar;
}




void home::onServerFriendClicked()
{
    // 设置当前聊天对象为服务器
    m_currentActivePeer = "SERVER";

    // 更新聊天窗口标题
    ui->username->setText("微信团队");

    // 清空聊天记录显示区域
    ui->prints->clear();

    // 显示聊天界面
    ui->list_friend->show();
    ui->widget->hide();
    ui->xiaoxi->hide();
    ui->txl->hide();
    ui->list_yz->hide();

    // 添加欢迎消息
    QWidget* messageWidget = new QWidget();
    QHBoxLayout* mainLayout = new QHBoxLayout(messageWidget);
    mainLayout->setContentsMargins(0, 0, 0, 12);
    mainLayout->setSpacing(0);

    QLabel* welcomeLabel = new QLabel("欢迎回来！");
    welcomeLabel->setStyleSheet("color: #666; font-size: 14px;");
    welcomeLabel->setAlignment(Qt::AlignCenter);

    mainLayout->addWidget(welcomeLabel);

    QListWidgetItem* item = new QListWidgetItem();
    item->setSizeHint(QSize(0, 40));
    ui->prints->addItem(item);
    ui->prints->setItemWidget(item, messageWidget);
}


// 添加服务器作为固定好友
void home::addServerAsFriend()
{
    if (m_serverFriendAdded) return;

    // 创建服务器好友项（使用与普通好友相同的创建方式）
    QListWidgetItem* serverItem = new QListWidgetItem();
    serverItem->setSizeHint(QSize(0, 70));
    serverItem->setData(Qt::UserRole, "SERVER");

    // 创建自定义widget
    QWidget* widget = new QWidget();
    widget->setProperty("delegateManaged", true); // 添加关键属性

    QHBoxLayout* layout = new QHBoxLayout(widget);
    layout->setContentsMargins(20, 5, 15, 5);
    layout->setSpacing(15);

    // 服务器头像
    QLabel* avatarLabel = new QLabel(widget);
    avatarLabel->setFixedSize(43, 43);
    QPixmap serverAvatar = loadAvatar(":/img/img/server_icon.png", QSize(43, 43), 5);
    avatarLabel->setPixmap(serverAvatar);
    layout->addWidget(avatarLabel);

    // 服务器名称标签
    QLabel* nameLabel = new QLabel("微信团队", widget);
    nameLabel->setStyleSheet("font-family: 'Microsoft YaHei'; font-size: 18px; color: #333;");
    nameLabel->setAlignment(Qt::AlignVCenter | Qt::AlignLeft);
    layout->addWidget(nameLabel, 1);

    // 关键修改：使用与普通好友相同的存储方式
    serverItem->setData(Qt::UserRole + 1, QVariant::fromValue(static_cast<QObject*>(widget)));

    // 添加到列表顶部
    ui->list_friend->insertItem(0, serverItem);
    ui->list_friend->setItemWidget(serverItem, widget); // 保持设置widget

    m_serverFriendAdded = true;
}

void FriendListDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option,
                               const QModelIndex &index) const
{
    Q_UNUSED(index); // 告诉编译器忽略未使用的参数
    painter->save();

    // 绘制背景
    if (option.state & QStyle::State_Selected) {
        painter->fillRect(option.rect, QColor(230, 230, 230)); // 选中状态
    } else if (option.state & QStyle::State_MouseOver) {
        painter->fillRect(option.rect, QColor(245, 245, 245)); // 悬停状态
    } else {
        painter->fillRect(option.rect, Qt::white); // 默认状态
    }

    // 获取自定义widget
    QWidget *widget = qobject_cast<QWidget*>(option.styleObject);
    if (!widget) {
        painter->restore();
        return;
    }

    // 绘制自定义内容
    if (QWidget *itemWidget = qobject_cast<QWidget*>(
                widget->property("itemWidget").value<QObject*>()))
    {
        itemWidget->render(painter, option.rect.topLeft(),
                           QRegion(), QWidget::DrawChildren);
    }

    painter->restore();
}

QSize FriendListDelegate::sizeHint(const QStyleOptionViewItem &option,
                                   const QModelIndex &index) const
{
    Q_UNUSED(option)
    Q_UNUSED(index)
    return QSize(200, 85); // 固定项大小
}

void home::updateFriendList(const QStringList& friends)
{
    qDebug() << "收到服务器返回的好友列表:" << friends;
    
    // 1. 处理好友列表：去重、过滤空字符串、SERVER和已删除好友
    QStringList uniqueFriends;
    QSet<QString> seenFriends;
    
    for (const QString& friendStr : friends) {
        if (friendStr.isEmpty() || friendStr == "SERVER") {
            continue;
        }
        
        // 提取基础用户名进行去重和过滤
        QString baseFriend = getBaseUsername(friendStr);
        
        // 检查是否已删除好友
        if (m_deletedFriends.contains(baseFriend)) {
            qDebug() << "过滤掉已删除好友:" << baseFriend;
            continue;
        }
        
        // 去重处理
        if (!seenFriends.contains(baseFriend)) {
            seenFriends.insert(baseFriend);
            uniqueFriends.append(friendStr);
        }
    }
    
    qDebug() << "去重后的好友列表:" << uniqueFriends;

    // 2. 清空好友列表（保留服务器好友）
    for (int i = ui->list_friend->count() - 1; i >= 0; --i) {
        QListWidgetItem* item = ui->list_friend->item(i);
        if (item && item->data(Qt::UserRole).toString() != "SERVER") {
            QListWidgetItem* removedItem = ui->list_friend->takeItem(i);
            if (removedItem) {
                // 清理关联的widget
                QWidget* widget = ui->list_friend->itemWidget(removedItem);
                if (widget) {
                    delete widget;
                }
                delete removedItem;
            }
        }
    }

    // 3. 确保服务器好友存在
    if (!m_serverFriendAdded) {
        addServerAsFriend();
    }

    // 4. 遍历处理后的好友列表，为每个好友创建列表项
    for (const QString& username : uniqueFriends) {
        if (username == "SERVER") continue;

        QListWidgetItem* item = new QListWidgetItem();
        // 存储完整的username（包含昵称）
        item->setData(Qt::UserRole, username);

        // +++ 新增：提取昵称 +++
        QString nickname = getNicknameFromUsername(username);
        // +++ 结束新增 +++

        // 创建列表项并设置大小
        item->setSizeHint(QSize(0, 70));

        // 创建自定义widget用于显示好友信息
        QWidget* widget = new QWidget();
        widget->setProperty("delegateManaged", true);

        // 设置水平布局
        QHBoxLayout* layout = new QHBoxLayout(widget);
        layout->setContentsMargins(20, 5, 15, 5);
        layout->setSpacing(15);

        // 头像
        QLabel* avatarLabel = new QLabel(widget);
        avatarLabel->setFixedSize(43, 43);
        QPixmap friendAvatar = loadAvatar(":/img/img/wxtx.png", QSize(43, 43), 5);
        avatarLabel->setPixmap(friendAvatar);

        layout->addWidget(avatarLabel);

        // 用户名标签 - 调整样式和对齐方式
        QLabel* nameLabel = new QLabel(nickname, widget); // 只显示昵称
        nameLabel->setStyleSheet("font-family: 'Microsoft YaHei'; font-size: 18px; color: #333;");
        nameLabel->setAlignment(Qt::AlignVCenter | Qt::AlignLeft); // 垂直居中对齐
        layout->addWidget(nameLabel, 1); // 占满剩余空间

        // 将项添加到列表并设置自定义widget
        ui->list_friend->addItem(item);
        ui->list_friend->setItemWidget(item, widget);
        // 更新好友昵称映射
        for (const QString& fullFriend : friends) {
            QString baseUsername = getBaseUsername(fullFriend);
            QString nickname = getNicknameFromUsername(fullFriend);
            m_friendNicknameMap[baseUsername] = nickname;
        }
    }
    requestFriendAvatars(friends);
}

void home::requestFriendAvatars(const QStringList& friends)
{
    foreach (const QString& fullFriend, friends) {
        QString username = getBaseUsername(fullFriend);
        if (username.isEmpty() || username == "SERVER") continue;

        // 检查本地是否有缓存
        QPixmap cachedAvatar = m_chatDatabase.getAvatarPixmap(username);
        if (!cachedAvatar.isNull()) {
            m_avatarCache[username] = cachedAvatar;
            updateFriendAvatar(username, cachedAvatar);
        } else {
            // 请求服务器头像
            NetworkManager::instance()->sendTcpMessage("REQUEST_AVATAR:" + username);
        }
    }
}

void home::handleRequesterNickname(const QString& sender, const QString& nickname)
{
    qDebug() << "更新好友验证列表 - 发送者:" << sender << "昵称:" << nickname;

    // 检查是否有该发送者的请求项
    if (m_friendRequests.contains(sender)) {

        qDebug() << "m_friendRequests 包含发送者:" << sender;
        QListWidgetItem* item = m_friendRequests[sender];
        QWidget* widget = ui->list_yz->itemWidget(item);

        if (widget) {
            QLabel* textLabel = widget->findChild<QLabel*>();
            if (textLabel) {
                qDebug() << "找到文本标签，更新文本";
                textLabel->setText(QString("<b>%1 (%2)</b> 请求添加你为好友")
                                   .arg(nickname).arg(sender));
                return;
            }
        }
    }

    // 没有找到请求项，暂存昵称
    qDebug() << "暂存昵称，等待好友请求到来";
    m_pendingNicknames[sender] = nickname;
}

void home::handleFriendRequest(const QString& sender)
{
    qDebug() << "HOME: 处理好友请求从" << sender;
    if (sender == m_username) {
        qDebug() << "HOME: 忽略自己发送的请求";
        return;
    }

    // 检查UI列表中是否已存在该请求
    bool requestExists = false;
    for (int i = 0; i < ui->list_yz->count(); ++i) {
        QListWidgetItem* item = ui->list_yz->item(i);
        if (item->data(Qt::UserRole).toString() == sender) {
            requestExists = true;
            break;
        }
    }
    
    if (requestExists) {
        qDebug() << "HOME: UI列表中已存在该好友请求，忽略";
        return;
    }

    // 显示验证列表
    qDebug() << "HOME: 显示验证列表";
    ui->list_yz->show();
    
    // 清除可能存在的旧映射
    if (m_friendRequests.contains(sender)) {
        m_friendRequests.remove(sender);
        qDebug() << "HOME: 已清除旧的好友请求映射";
    }
    
    qDebug() << "HOME: 调用addFriendRequestToList添加请求";
    addFriendRequestToList(sender);

    // 检查是否有暂存的昵称
    if (m_pendingNicknames.contains(sender)) {
        QString nickname = m_pendingNicknames.take(sender);
        handleRequesterNickname(sender, nickname);
    }
}

void home::addFriendRequestToList(const QString& sender)
{
    // 检查是否已存在该请求
    for (int i = 0; i < ui->list_yz->count(); ++i) {
        QListWidgetItem* item = ui->list_yz->item(i);
        if (item->data(Qt::UserRole).toString() == sender) {
            return; // 请求已存在
        }
    }
    if (m_friendRequests.contains(sender)) {
        qDebug() << "已存在该好友请求，忽略";
        return;
    }

    QListWidgetItem* item = new QListWidgetItem();
    m_friendRequests[sender] = item;

    // 将sender存储在item的UserRole中
    item->setData(Qt::UserRole, sender);

    item->setSizeHint(QSize(0, 80)); // 保持高度不变

    // 创建自定义的请求项
    QWidget* requestWidget = new QWidget();
    QHBoxLayout* mainLayout = new QHBoxLayout(requestWidget);
    mainLayout->setContentsMargins(10, 10, 10, 10);
    mainLayout->setSpacing(15);

    // 头像标签 - 保持原有样式
    QLabel* avatarLabel = new QLabel();
    avatarLabel->setFixedSize(43, 43);
    QPixmap requestAvatar = loadAvatar(":/img/img/wxtx.png", QSize(43, 43), 5);
    avatarLabel->setPixmap(requestAvatar);

    // 文本标签 - 修改为超过6个字换行显示
    QLabel* textLabel = new QLabel();
    textLabel->setTextFormat(Qt::RichText);
    textLabel->setWordWrap(true);
    textLabel->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);

    // 处理超过6个字的文本换行
    QString displayText;
    if (sender.length() > 6) {
        displayText = QString("<b>%1</b><br>请求添加你为好友").arg(sender);
    } else {
        displayText = QString("<b>%1</b> 请求添加你为好友").arg(sender);
    }

    textLabel->setText(displayText);
    textLabel->setStyleSheet("font-size: 14px; color: #333;");

    // 按钮容器 - 保持垂直布局
    QWidget* buttonContainer = new QWidget();
    QVBoxLayout* buttonLayout = new QVBoxLayout(buttonContainer);
    buttonLayout->setContentsMargins(0, 0, 0, 0);
    buttonLayout->setSpacing(5); // 按钮之间的间距
    buttonLayout->setAlignment(Qt::AlignTop); // 按钮居上排列

    // 接受按钮 - 修改为无边框样式
    QPushButton* acceptBtn = new QPushButton("接受");
    acceptBtn->setFixedSize(60, 28); // 调整按钮大小
    acceptBtn->setStyleSheet(
                "QPushButton {"
                "  background-color: #07C160;"
                "  color: white;"
                "  border-radius: 4px;"
                "  font-weight: bold;"
                "  border: none;"
                "}"
                "QPushButton:hover {"
                "  background-color: #06AD56;"
                "}"
                "QPushButton:pressed {"
                "  background-color: #059C4D;"
                "}"
                );

    // 拒绝按钮 - 修改为无边框样式
    QPushButton* rejectBtn = new QPushButton("拒绝");
    rejectBtn->setFixedSize(60, 28); // 调整按钮大小
    rejectBtn->setStyleSheet(
                "QPushButton {"
                "  background-color: #F0F0F0;"
                "  color: #666;"
                "  border-radius: 4px;"
                "  border: none;"
                "}"
                "QPushButton:hover {"
                "  background-color: #E5E5E5;"
                "}"
                "QPushButton:pressed {"
                "  background-color: #D9D9D9;"
                "}"
                );

    // 连接按钮信号 - 保持原有逻辑
    connect(acceptBtn, &QPushButton::clicked, [this, sender]() {
        NetworkManager::instance()->sendTcpMessage(QString("CONFIRM_FRIEND:%1:accept").arg(sender));
        removeFriendRequest(sender);
    });

    connect(rejectBtn, &QPushButton::clicked, [this, sender]() {
        NetworkManager::instance()->sendTcpMessage(QString("CONFIRM_FRIEND:%1:reject").arg(sender));
        removeFriendRequest(sender);
    });

    // 组装按钮容器 - 使用垂直布局
    buttonLayout->addWidget(acceptBtn);
    buttonLayout->addWidget(rejectBtn);

    // 组装主布局 - 调整对齐方式使整体居中
    mainLayout->addWidget(avatarLabel, 0, Qt::AlignVCenter);
    mainLayout->addWidget(textLabel, 1, Qt::AlignVCenter); // 文本标签占据剩余空间并居中
    mainLayout->addWidget(buttonContainer, 0, Qt::AlignVCenter | Qt::AlignRight); // 按钮容器靠右对齐并居中

    // 设置整个项的样式 - 修改为无边框
    requestWidget->setStyleSheet(
                "QWidget {"
                "  background-color: white;"
                "  border-radius: 8px;"
                "  border: none;"
                "}"
                );

    // 添加分隔线
    QFrame* separator = new QFrame();
    separator->setFrameShape(QFrame::HLine);
    separator->setFrameShadow(QFrame::Sunken);
    separator->setStyleSheet("color: #E0E0E0;");

    QVBoxLayout* containerLayout = new QVBoxLayout();
    containerLayout->addWidget(requestWidget);
    containerLayout->addWidget(separator);
    containerLayout->setSpacing(0);
    containerLayout->setContentsMargins(0, 0, 0, 0);

    QWidget* container = new QWidget();
    container->setLayout(containerLayout);

    // 添加请求项到列表
    ui->list_yz->addItem(item);
    ui->list_yz->setItemWidget(item, container);
    m_friendRequests[sender] = item;

    connect(acceptBtn, &QPushButton::clicked, this, &home::handleFriendRequestAccepted);
    connect(rejectBtn, &QPushButton::clicked, this, &home::handleFriendRequestRejected);
}


void home::handleFriendRequestAccepted()
{
    handleFriendRequestAction(true);
    NetworkManager::instance()->sendTcpMessage("REQUEST_FRIEND_LIST");
}

void home::handleFriendRequestRejected()
{
    handleFriendRequestAction(false);
}

void home::handleFriendRequestAction(bool accepted)
{
    // 获取发送信号的按钮
    QPushButton* button = qobject_cast<QPushButton*>(sender());
    if (!button) return;

    // 获取按钮所在的容器
    QWidget* buttonContainer = button->parentWidget();
    if (!buttonContainer) return;

    // 获取整个请求项
    QWidget* requestWidget = buttonContainer->parentWidget();
    if (!requestWidget) return;

    // 在列表中找到对应的item
    for (int i = 0; i < ui->list_yz->count(); ++i) {
        QListWidgetItem* item = ui->list_yz->item(i);
        if (ui->list_yz->itemWidget(item) == requestWidget) {
            QString sender = item->data(Qt::UserRole).toString();

            // 发送确认消息到服务器
            QString action = accepted ? "accept" : "reject";
            NetworkManager::instance()->sendTcpMessage(
                        QString("CONFIRM_FRIEND:%1:%2").arg(sender).arg(action));

            // 从列表中移除
            delete ui->list_yz->takeItem(i);
            m_friendRequests.remove(sender);
            return;
        }
    }
}

void home::removeFriendRequest(const QString& sender)
{
    if (m_friendRequests.contains(sender)) {
        QListWidgetItem* item = m_friendRequests[sender];

        // 从列表中移除
        for (int i = 0; i < ui->list_yz->count(); ++i) {
            if (ui->list_yz->item(i) == item) {
                delete ui->list_yz->takeItem(i);
                break;
            }
        }

        // 从映射中移除
        m_friendRequests.remove(sender);
    }

    for (int i = 0; i < ui->list_yz->count(); ++i) {
        QListWidgetItem* item = ui->list_yz->item(i);
        QWidget* widget = ui->list_yz->itemWidget(item);
        if (widget) {
            // 查找文本标签
            QLabel* textLabel = widget->findChild<QLabel*>();
            if (textLabel) {
                QString labelText = textLabel->text();
                // 检查标签文本是否包含发送者用户名
                if (labelText.contains(sender) )
                {
                    delete ui->list_yz->takeItem(i);
                    return; // 找到并删除后立即返回
                }
            }
        }
    }
}




// 新增槽函数处理头像数据
void home::handleAvatarDataReceived(const QString& username, const QByteArray& data)
{

    qDebug() << "收到头像数据 - 用户名:" << username << "数据大小:" << data.size();
    if (username != m_username)
        return;

    m_avatarData = data; // 保存头像数据

    // 更新home界面的头像
    QPixmap pixmap;
    if (pixmap.loadFromData(m_avatarData)) {
        updateTouxiangLabel(pixmap);
    }

    // 如果myhome窗口已创建，更新其头像
    if (mywindow) {
        mywindow->handleAvatarDataReceived(username, data);
    }
}

void home::setUsername(const QString& username) {
    // 保存当前账号的好友请求状态
    if (!m_username.isEmpty()) {
        m_accountFriendRequests[m_username] = m_friendRequests;
        qDebug() << "HOME: 保存当前账号的好友请求状态";
    }

    // 清除当前界面显示
    ui->list_yz->clear();
    m_friendRequests.clear();

    // 设置新用户名
    m_username = username;
    qDebug() << "HOME: 切换到新账号" << username;

    // 恢复新账号的好友请求状态（如果存在）
    if (m_accountFriendRequests.contains(username)) {
        const auto& savedRequests = m_accountFriendRequests[username];
        for (auto it = savedRequests.constBegin(); it != savedRequests.constEnd(); ++it) {
            qDebug() << "HOME: 恢复账号" << username << "的好友请求 from" << it.key();
            addFriendRequestToList(it.key());
        }
    }
    
    // 同时处理NetworkManager中的所有未处理好友请求
    QStringList pendingRequests = NetworkManager::instance()->getPendingFriendRequests();
    for (const QString& sender : pendingRequests) {
        qDebug() << "HOME: 从NetworkManager获取未处理好友请求 from" << sender;
        handleFriendRequest(sender);
    }

    ui->prints->clear();

    // 初始化数据库
    m_chatDatabase.initDatabase(username);
    if (mywindow) {
        mywindow->setUsername(username);
    }
    if (szwindow) {
        szwindow->setUsername(username);
    }
}

void home::setNickname(const QString& nickname)
{
    m_nickname = nickname;
    if (mywindow) {
        mywindow->setNickname(nickname);
    }
}

void home::showEvent(QShowEvent *event)
{
    QWidget::showEvent(event);

    // 创建myhome窗口（如果不存在）
    if (!mywindow) {
        mywindow = new myhome(this);
        connect(mywindow, &myhome::avatarChanged,
                this, &home::updateMyButtonAvatar);

        connect(mywindow, &myhome::avatarChangedForLabel,
                this, &home::updateTouxiangLabel);


        // 如果已有用户名，设置到myhome
        if (!m_username.isEmpty()) {
            mywindow->setUsername(m_username);
        }
        if (!m_nickname.isEmpty()) {
            mywindow->setNickname(m_nickname);
        }
        // 新增：如果有缓存的头像数据，设置给myhome
        if (!m_avatarData.isEmpty()) {
            mywindow->handleAvatarDataReceived(m_username, m_avatarData);
        }
    }
    if (!m_username.isEmpty()) {
        QString command = "REQUEST_AVATAR:" + m_username;
        NetworkManager::instance()->sendTcpMessage(command);
    }
}

void home::handleBackToMainWindow()
{

    // 关闭所有子窗口
    if (mywindow) {
        mywindow->close();
        mywindow = nullptr;
        qDebug()<<"关闭mywindow窗口";
    }

    if (friendwindow) {
        friendwindow->close();
        friendwindow = nullptr;
        qDebug()<<"关闭friendwindow窗口";
    }

    if (szwindow) {
        szwindow->close();
        szwindow = nullptr;
        qDebug()<<"关闭szwindow窗口";
    }

    // 查找并显示MainWindow
    QWidgetList topLevelWidgets = QApplication::topLevelWidgets();
    for (QWidget *widget : topLevelWidgets) {
        if (MainWindow *mainWindow = qobject_cast<MainWindow*>(widget)) {
            mainWindow->show();
            mainWindow->raise();
            mainWindow->activateWindow();
            qDebug()<<"显示MainWindow窗口";
            break;
        }
    }
    emit requestResetToQrLogin();
    // 关闭当前home窗口
    this->close();
}

QPixmap home::createRoundedPixmap(const QPixmap& source, int radius)
{
    if (source.isNull()) {
        return QPixmap();
    }

    QPixmap result(source.size());
    result.fill(Qt::transparent);

    QPainter painter(&result);
    painter.setRenderHints(QPainter::Antialiasing | QPainter::SmoothPixmapTransform);

    // 创建圆角路径
    QPainterPath path;
    path.addRoundedRect(0, 0, source.width(), source.height(), radius, radius);
    painter.setClipPath(path);

    // 绘制原始图像
    painter.drawPixmap(0, 0, source);

    return result;
}

void home::updateTouxiangLabel(const QPixmap& newAvatar)
{
    QSize labelSize = ui->touxiang->size();
    QPixmap avatarToUse = newAvatar;

    if (avatarToUse.isNull()) {
        avatarToUse = loadAvatar(":/img/img/wxtx.png", labelSize, 4);
    } else {
        avatarToUse = createRoundedPixmap(newAvatar.scaled(
                                              labelSize, Qt::KeepAspectRatio, Qt::SmoothTransformation), 4);
    }

    ui->touxiang->setPixmap(avatarToUse);
    m_currentAvatar = newAvatar;
    emit avatarChanged(newAvatar);
}

void home::updateMyButtonAvatar(const QPixmap& newAvatar)
{
    // 设置按钮图标
    QIcon buttonIcon(newAvatar);
    ui->mybut->setIcon(buttonIcon);
    ui->mybut->setIconSize(ui->mybut->size());
}

// 创建消息部件的辅助函数
QWidget* home::createMessageWidgetForBubble(const QString& sender, const QString& message)
{
    // 这里复用你原有的 createSelfMessageBubble/createPeerMessageBubble 逻辑
    if (sender == m_username) {
        return createSelfMessageBubble(message);
    } else {
        return createPeerMessageBubble(message, sender);
    }
}

// 隐藏所有菜单的辅助函数实现
void home::hideAllMenus()
{
    ui->listView->hide();
    ui->k1->hide();
    ui->k2->hide();
    ui->k3->hide();
    ui->listView_2->hide();
    ui->b1->hide();
    ui->b2->hide();
    ui->b3->hide();
    ui->b4->hide();
    ui->b5->hide();
    ui->b6->hide();
}

// 事件过滤器处理
bool home::eventFilter(QObject *obj, QEvent *event)
{
    // 点击信息窗口外部时关闭
    if (m_friendInfoWindow && event->type() == QEvent::MouseButtonPress) {
        if (!m_friendInfoWindow->geometry().contains(QCursor::pos())) {
            m_friendInfoWindow->close();
            return true;
        }
    }

    // 处理好友列表的悬停事件
    if (obj == ui->list_friend && event->type() == QEvent::MouseMove) {
        ui->list_friend->viewport()->update();
    }
    // 处理聊天区域滚动事件
    if (obj == ui->prints->viewport() && event->type() == QEvent::Wheel) {
        QWheelEvent *wheelEvent = static_cast<QWheelEvent *>(event);

        // 检查是否向上滚动到顶部
        if (wheelEvent->angleDelta().y() > 0 &&
                ui->prints->verticalScrollBar()->value() == 0) {

            if (!m_currentActivePeer.isEmpty()) {
                auto& state = m_chatHistoryState[m_currentActivePeer];
                if (state.hasMore && !state.isLoading) {
                    loadMoreMessages(m_currentActivePeer);
                }
            }
        }
    }

    // 1. 处理输入框的Enter键
    if (obj == ui->inputs && event->type() == QEvent::KeyPress) {
        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        if (keyEvent->key() == Qt::Key_Return || keyEvent->key() == Qt::Key_Enter) {
            if (!(keyEvent->modifiers() & Qt::ControlModifier)) {
                on_send_clicked();
                return true;
            }
        }

        // 按下任意键时隐藏所有菜单
        hideAllMenus();
    }

    // 2. 处理鼠标点击
    if (event->type() == QEvent::MouseButtonPress) {
        QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
        QPoint clickPos = mouseEvent->pos();

        // 检查是否点击在快捷菜单区域外
        if (ui->listView->isVisible()) {
            QRect listViewRect = ui->listView->geometry();
            QRect k1Rect = ui->k1->geometry();
            QRect k2Rect = ui->k2->geometry();
            QRect k3Rect = ui->k3->geometry();
            QRect kuaijieRect = ui->kuaijie->geometry();

            if (!listViewRect.contains(clickPos) &&
                    !k1Rect.contains(clickPos) &&
                    !k2Rect.contains(clickPos) &&
                    !k3Rect.contains(clickPos) &&
                    !kuaijieRect.contains(clickPos))
            {
                hideAllMenus();
            }
        }

        // 检查是否点击在更多菜单区域外
        if (ui->listView_2->isVisible()) {
            QRect listView2Rect = ui->listView_2->geometry();
            QRect b1Rect = ui->b1->geometry();
            QRect b2Rect = ui->b2->geometry();
            QRect b3Rect = ui->b3->geometry();
            QRect b4Rect = ui->b4->geometry();
            QRect b5Rect = ui->b5->geometry();
            QRect b6Rect = ui->b6->geometry();
            QRect moreRect = ui->more->geometry();

            if (!listView2Rect.contains(clickPos) &&
                    !b1Rect.contains(clickPos) &&
                    !b2Rect.contains(clickPos) &&
                    !b3Rect.contains(clickPos) &&
                    !b4Rect.contains(clickPos) &&
                    !b5Rect.contains(clickPos) &&
                    !b6Rect.contains(clickPos) &&
                    !moreRect.contains(clickPos))
            {
                hideAllMenus();
            }
        }
    }
    
    // 处理图片双击放大
    if (event->type() == QEvent::MouseButtonDblClick) {
        if (obj->property("isImageMessage").toBool()) {
            QString imagePath = obj->property("originalImagePath").toString();
            if (!imagePath.isEmpty()) {
                // 创建一个新窗口来显示完整大小的图片
                QDialog *imageDialog = new QDialog(this);
                imageDialog->setWindowTitle("图片查看");
                imageDialog->setWindowModality(Qt::ApplicationModal);
                
                QVBoxLayout *layout = new QVBoxLayout(imageDialog);
                QLabel *fullImageLabel = new QLabel(imageDialog);
                
                QPixmap fullPixmap(imagePath);
                if (!fullPixmap.isNull()) {
                    fullImageLabel->setPixmap(fullPixmap);
                    fullImageLabel->setAlignment(Qt::AlignCenter);
                    
                    // 如果图片太大，添加滚动条
                    QScrollArea *scrollArea = new QScrollArea(imageDialog);
                    scrollArea->setWidget(fullImageLabel);
                    scrollArea->setWidgetResizable(true);
                    
                    layout->addWidget(scrollArea);
                    
                    // 设置对话框大小
                    QSize screenSize = QApplication::primaryScreen()->size();
                    int maxWidth = screenSize.width() * 0.9;
                    int maxHeight = screenSize.height() * 0.9;
                    
                    QSize imageSize = fullPixmap.size();
                    if (imageSize.width() > maxWidth || imageSize.height() > maxHeight) {
                        imageSize = imageSize.scaled(maxWidth, maxHeight, Qt::KeepAspectRatio);
                    }
                    
                    imageDialog->resize(imageSize);
                    
                    // 显示对话框
                    imageDialog->exec();
                    delete imageDialog;
                }
            }
            return true;
        }
    }

    return QWidget::eventFilter(obj, event);
}


// 鼠标按下事件处理
void home::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        // 记录鼠标按下时的全局位置和窗口位置
        m_dragPosition = event->globalPos() - frameGeometry().topLeft();
        event->accept();
    }
}

// 鼠标移动事件处理
void home::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton) {
        // 计算窗口新位置
        move(event->globalPos() - m_dragPosition);
        event->accept();
    }
}

void home::on_close_clicked()
{
    close();
    QApplication::quit();

}

// 添加尖角标签绘制方法
void TriangleLabel::paintEvent(QPaintEvent* event) {
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    // 获取方向属性（默认为右边）
    bool isLeft = this->property("pointLeft").toBool();
    QColor color = this->property("color").value<QColor>();

    if (color.isValid()) {
        painter.setBrush(color);
    } else {
        // 默认绿色
        painter.setBrush(QColor(149, 236, 105));
    }
    painter.setPen(Qt::NoPen);

    QPolygon triangle;

    if (isLeft) {
        // 绘制指向左边的三角形（白色）
        triangle << QPoint(width(), height()/2 - 5)
                 << QPoint(0, height()/2)
                 << QPoint(width(), height()/2 + 5);
    } else {
        // 绘制指向右边的三角形（绿色）
        triangle << QPoint(0, height()/2 - 5)
                 << QPoint(width(), height()/2)
                 << QPoint(0, height()/2 + 5);
    }

    painter.drawPolygon(triangle);
}

// 截图选择窗口类的实现
ScreenshotSelector::ScreenshotSelector(const QPixmap& screenshot, QWidget* parent)
    : QWidget(parent), m_screenshot(screenshot), m_isSelecting(false)
{
    // 设置窗口全屏、无边框、置顶
    setWindowFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint | Qt::Window);
    setWindowState(Qt::WindowFullScreen);
    setCursor(Qt::CrossCursor);
    // 不需要半透明背景，直接绘制截图
    showFullScreen();
}

ScreenshotSelector::~ScreenshotSelector()
{
}

void ScreenshotSelector::paintEvent(QPaintEvent* event)
{
    Q_UNUSED(event);
    QPainter painter(this);

    // 确保截图不为空
    if (!m_screenshot.isNull()) {
        // 1. 绘制完整的截图作为背景
        painter.drawPixmap(0, 0, this->width(), this->height(), m_screenshot);
        
        // 2. 绘制半透明遮罩覆盖整个屏幕
        QColor overlayColor(0, 0, 0, 100);
        painter.fillRect(rect(), overlayColor);
        
        // 3. 如果正在选择区域，在选择区域绘制截图内容
        if (m_isSelecting && !m_selectionRect.isNull()) {
            // 从原始截图中复制选择区域的内容
            QPixmap selectedPixmap = m_screenshot.copy(m_selectionRect);
            // 在选择区域绘制截图内容
            painter.drawPixmap(m_selectionRect, selectedPixmap);
        }
    }

    // 4. 绘制选择区域边框（绿色）
    if (m_isSelecting && !m_selectionRect.isNull()) {
        painter.setPen(QPen(Qt::green, 2));
        painter.setBrush(Qt::NoBrush);
        painter.drawRect(m_selectionRect);
    }
}

void ScreenshotSelector::mousePressEvent(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton) {
        m_startPos = event->pos();
        m_isSelecting = true;
        m_selectionRect = QRect(m_startPos, QSize(0, 0));
        update();
    }
}

void ScreenshotSelector::mouseMoveEvent(QMouseEvent* event)
{
    if (m_isSelecting) {
        updateSelection(event->pos());
    }
}

void ScreenshotSelector::mouseReleaseEvent(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton && m_isSelecting) {
        updateSelection(event->pos());
        m_isSelecting = false;

        // 确保选择区域有效
        if (!m_selectionRect.isNull() && m_selectionRect.width() > 5 && m_selectionRect.height() > 5) {
            // 捕获选择的区域
            m_selectedRegion = m_screenshot.copy(m_selectionRect);
            emit screenshotSelected(m_selectedRegion);
            close();
        } else {
            // 选择区域太小，取消截图
            emit screenshotCancelled();
            close();
        }
    }
}

void ScreenshotSelector::keyPressEvent(QKeyEvent* event)
{
    if (event->key() == Qt::Key_Escape) {
        // 按ESC键取消截图
        emit screenshotCancelled();
        close();
    }
}

void ScreenshotSelector::updateSelection(const QPoint& endPos)
{
    // 计算选择区域
    int x = qMin(m_startPos.x(), endPos.x());
    int y = qMin(m_startPos.y(), endPos.y());
    int width = qAbs(endPos.x() - m_startPos.x());
    int height = qAbs(endPos.y() - m_startPos.y());

    m_selectionRect = QRect(x, y, width, height);
    update();
}

QPixmap home::createBubblePixmap(const QString& message, bool isSelf)
{
    QFont font = ui->prints->font();
    QFontMetrics fm(font);

    // 计算文本尺寸 (修复换行问题)
    int lineHeight = fm.height();
    int textWidth = 0;
    int textHeight = 0;

    QStringList lines;
    QString currentLine;
    int charCount = 0;

    // 遍历原始消息中的每个字符
    for (int i = 0; i < message.length(); i++) {
        QChar ch = message.at(i);
        currentLine += ch;
        charCount++;

        // 当字符数达到25或遇到换行符时进行换行
        if (charCount >= 16 || ch == '\n') {
            // 处理最后一个字符如果是换行符的情况
            if (ch == '\n') {
                charCount = 0;
            } else {
                // 插入换行符并重置计数器
                currentLine += '\n';
                charCount = 0;
            }

            lines.append(currentLine);
            currentLine.clear();
        }
    }

    // 处理最后一行剩余的字符
    if (!currentLine.isEmpty()) {
        lines.append(currentLine);
    }

    // 计算文本的实际宽度和高度
    for (const QString& line : lines) {
        textWidth = qMax(textWidth, fm.horizontalAdvance(line));
    }
    textHeight = lines.size() * lineHeight;

    // 添加内边距 (10px)
    textWidth = qMin(textWidth + 40, 350); // 限制最大宽度
    textHeight += 20; // 上下各10px边距

    // 创建透明背景图片
    QPixmap bubble(textWidth, textHeight);

    bubble.fill(Qt::transparent);

    QPainter painter(&bubble);
    painter.setRenderHint(QPainter::Antialiasing);

    // 绘制气泡主体（绿色圆角矩形）
    QRect bubbleRect(0, 0, textWidth, textHeight);
    if (isSelf) {
        painter.setBrush(QColor(149, 236, 105)); // 自己发送-绿色
    } else {
        painter.setBrush(QColor(254, 254, 254)); // 服务器发送-白色
    }
    painter.setPen(Qt::NoPen);
    painter.drawRoundedRect(bubbleRect, 5, 5);

    // 绘制文本
    painter.setPen(Qt::black);
    painter.setFont(font);

    // 逐行绘制文本
    int yPos = bubbleRect.top() + 10;
    for (const QString& line : lines) {
        painter.drawText(
                    bubbleRect.left() + 16,
                    yPos,
                    bubbleRect.width() - 40,
                    lineHeight,
                    Qt::TextSingleLine,
                    line
                    );
        yPos += lineHeight;
    }

    return bubble;
}

// 修改 on_send_clicked 方法
// 截图按钮点击事件处理
void home::on_jietu_clicked()
{
    // 获取当前屏幕
    QScreen *screen = QApplication::primaryScreen();
    if (!screen) {
        qDebug() << "无法获取屏幕";
        return;
    }

    // 获取屏幕几何信息
    QRect screenGeometry = screen->geometry();
    
    // 捕获整个屏幕（使用grabWindow方法，兼容旧版本Qt）
    // 使用QApplication::desktop()->winId()获取桌面窗口ID
    QPixmap screenshot = screen->grabWindow(QApplication::desktop()->winId(), 
                                           screenGeometry.x(), screenGeometry.y(), 
                                           screenGeometry.width(), screenGeometry.height());
    
    if (screenshot.isNull()) {
        qDebug() << "截图失败";
        return;
    }

    // 创建截图选择器窗口
    ScreenshotSelector* selector = new ScreenshotSelector(screenshot, this);
    
    // 连接截图选择完成信号
    connect(selector, &ScreenshotSelector::screenshotSelected, this, [this](const QPixmap& selected) {
        // 创建保存截图的临时文件路径
        QString timestamp = QDateTime::currentDateTime().toString("yyyyMMddHHmmsszzz");
        QString screenshotPath = QString("%1/screenshot_%2.png").arg(QDir::tempPath()).arg(timestamp);

        // 保存截图
        if (selected.save(screenshotPath)) {
            // 将截图直接插入到输入框中显示为图片
            QTextCursor cursor = ui->inputs->textCursor();
            QTextImageFormat imageFormat;
            imageFormat.setName(screenshotPath);
            // 可以设置图片的宽度，保持比例
            imageFormat.setWidth(100);
            cursor.insertImage(imageFormat);
            ui->inputs->setTextCursor(cursor);
        } else {
            qDebug() << "保存截图失败";
        }
    });
    
    // 连接截图取消信号
    connect(selector, &ScreenshotSelector::screenshotCancelled, this, []() {
        qDebug() << "截图已取消";
    });
    
    // 显示截图选择器
    selector->show();
}

void home::on_send_clicked()
{
    if (m_currentActivePeer.isEmpty()) return;
    
    // 获取输入框的QTextDocument
    QTextDocument *doc = ui->inputs->document();
    if (!doc) return;
    
    // 遍历文档内容，处理文本和图片
    QString finalMessage;
    QTextBlock block = doc->begin();
    while (block.isValid()) {
        QTextBlock::iterator it = block.begin();
        while (!it.atEnd()) {
            QTextFragment fragment = it.fragment();
            if (fragment.isValid()) {
                if (fragment.charFormat().isImageFormat()) {
                // 处理图片
                QTextImageFormat imageFormat = fragment.charFormat().toImageFormat();
                QString imagePath = imageFormat.name();
                // 检查是否已经是[IMAGE:file_path]格式
                if (imagePath.startsWith("[IMAGE:") && imagePath.endsWith("]")) {
                    // 如果已经是正确格式，直接使用
                    finalMessage += imagePath;
                } else {
                    // 否则生成[IMAGE:file_path]格式的消息内容
                    finalMessage += QString("[IMAGE:%1]").arg(imagePath);
                }
            } else {
                    // 处理文本
                    QString text = fragment.text();
                    finalMessage += text;
                }
            }
            ++it;
        }
        block = block.next();
    }
    
    // 清理消息
    finalMessage = finalMessage.trimmed();
    if (finalMessage.isEmpty()) return;
    
    // 生成唯一的毫秒级时间戳
    qint64 messageTimestamp = QDateTime::currentMSecsSinceEpoch();
    
    // 保存消息到数据库，使用相同的时间戳
    saveMessageToDatabase(m_username, m_currentActivePeer, finalMessage, messageTimestamp);

    // 根据当前聊天对象决定发送目标
    if (m_currentActivePeer == "SERVER") {
        // 发送消息到服务器，增加时间戳
        NetworkManager::instance()->sendTcpMessage(
                    QString("SERVER_MSG:%1:%2:%3").arg(m_username).arg(messageTimestamp).arg(finalMessage));
    } else {
        QString peerId = m_currentActivePeer.split('|').first();
        NetworkManager::instance()->sendTcpMessage(
                    QString("PRIVATE_MSG:%1:%2:%3").arg(peerId).arg(messageTimestamp).arg(finalMessage));
    }

    // 显示自己发送的消息，使用相同的时间戳
    displayMessageBubble(m_username, finalMessage, messageTimestamp);

    // 清空输入框
    ui->inputs->clear();
    ui->send->hide();
}

// 输入框文本变化处理
void home::on_inputs_textChanged()
{
    // 检查输入框是否有文本
    bool hasText = !ui->inputs->toPlainText().trimmed().isEmpty();

    // 根据是否有文本显示/隐藏发送按钮
    if (hasText) {
        ui->send->show();
        // 设置发送按钮样式
        ui->send->setStyleSheet(
                    "QPushButton {"
                    "  background-image: url(:/img/img/fasong.png);" // 使用发送图标
                    "  background-repeat: no-repeat;"
                    "  background-position: center;"
                    "  border: none;"
                    "  min-width: 120px;"
                    "  min-height: 40px;"
                    "  max-width: 120px;"
                    "  max-height: 40px;"
                    "  border-radius: 5px;"
                    "}"
                    "QPushButton:hover {"
                    "  background-color: rgba(0, 0, 0, 0.05);"
                    "}"
                    );
    } else {
        ui->send->hide();
    }
}

void home::on_mybut_clicked()
{

    hideAllMenus();

    // 切换显示/隐藏而不是每次都新建
    if (mywindow->isVisible()) {
        mywindow->hide();
    } else {
        QRect buttonRect = ui->mybut->geometry();
        QPoint globalPos = mapToGlobal(buttonRect.topRight());
        globalPos += QPoint(12, 0);
        mywindow->move(globalPos);
        mywindow->show();
    }
}

void home::on_kuaijie_clicked()
{
    // 切换显示状态（如果已显示则隐藏，反之显示）
    bool isVisible = !ui->listView->isVisible();
    ui->listView->setVisible(isVisible);
    ui->k1->setVisible(isVisible);
    ui->k2->setVisible(isVisible);
    ui->k3->setVisible(isVisible);

    // 隐藏其他菜单
    ui->listView_2->hide();
    ui->b1->hide();
    ui->b2->hide();
    ui->b3->hide();
    ui->b4->hide();
    ui->b5->hide();
    ui->b6->hide();
}

void home::on_more_clicked()
{
    hideAllMenus();

    // 切换显示状态（如果已显示则隐藏，反之显示）
    bool isVisible = !ui->listView_2->isVisible();
    ui->listView_2->setVisible(isVisible);
    ui->b1->setVisible(isVisible);
    ui->b2->setVisible(isVisible);
    ui->b3->setVisible(isVisible);
    ui->b4->setVisible(isVisible);
    ui->b5->setVisible(isVisible);
    ui->b6->setVisible(isVisible);
}

void home::on_k2_clicked()
{
    hideAllMenus();

    // 检查窗口是否已创建
    if (friendwindow == nullptr) {
        friendwindow = new add_friend();
    }

    friendwindow->show();
    friendwindow->raise();  // 提升到前台
    friendwindow->activateWindow();  // 激活窗口
}

void home::on_suoxiao_clicked()
{
    this->showMinimized(); // 最小化窗口
}




void home::on_b6_clicked()
{
    hideAllMenus();

    if (szwindow == nullptr) {
        szwindow = new shezhi();
        szwindow->setAttribute(Qt::WA_DeleteOnClose);

        // 确保连接返回主窗口信号
        connect(szwindow, &shezhi::requestBackToMainWindow,
                this, &home::handleBackToMainWindow);

        // 添加信号连接 - 确保 szwindow 不为空
        if (mywindow && szwindow) {  // 添加 szwindow 非空检查
            connect(mywindow, &myhome::nicknameChanged,
                    szwindow, &shezhi::updateNickname);
            // 初始化设置窗口的昵称
            szwindow->updateNickname(mywindow->getCurrentNickname());
        }

        // 窗口关闭时重置指针
        connect(szwindow, &shezhi::windowClosed, this, [this]() {
            szwindow = nullptr;
        });
    }

    // 设置用户名
    szwindow->setUsername(m_username);

    // 同步昵称
    if (mywindow) {
        szwindow->updateNickname(mywindow->getCurrentNickname());
    }

    szwindow->show();
    szwindow->raise();
    szwindow->activateWindow();

    // 更新头像
    if (const QPixmap* pixmap = ui->touxiang->pixmap()) {
        szwindow->updateTouxiangLabel(*pixmap);
    }
}

// 修改 on_shiping_dh_clicked 方法
void home::on_shiping_dh_clicked()
{
    if (spwindow == nullptr) {
        spwindow = new shiping();
        spwindow->setAttribute(Qt::WA_DeleteOnClose);

        // 确保窗口关闭时资源被释放
        connect(spwindow, &shiping::destroyed, this, [this]() {
            spwindow = nullptr;
        });
    }
    spwindow->show();
    spwindow->raise();
    spwindow->activateWindow();
}

// 修改 on_fangda_clicked 方法
void home::on_fangda_clicked()
{

}

void home::on_dianhua_clicked()
{

}

void home::on_wxlt_clicked()
{
    ui->xiaoxi->hide();
    ui->txl->hide();
    ui->list_yz->hide();
    ui->widget->hide();
    ui->list_friend->show();
}

void home::on_tongxun_clicked()
{
    ui->widget->show();
    ui->xiaoxi->show();
    ui->txl->show();
    ui->list_yz->show();


    ui->list_friend->hide();
}

void home::on_wenjian_clicked()
{
    static bool isProcessing = false;
    if (isProcessing) {
        return; // 防止重复调用
    }
    isProcessing = true;
    
    // 打开文件选择对话框，让用户选择要发送的文件
    QString filePath = QFileDialog::getOpenFileName(
                this,                          // 父窗口
                tr("选择文件"),                   // 对话框标题
                QDir::homePath(),              // 默认打开目录
                tr("所有文件 (*);;文本文件 (*.txt);;图片文件 (*.png *.jpg *.jpeg *.bmp);;文档文件 (*.doc *.docx *.pdf)")); // 文件过滤器

    if (!filePath.isEmpty()) {
        QFileInfo fileInfo(filePath);
        QString fileName = fileInfo.fileName();
        QString suffix = fileInfo.suffix().toLower();
        
        QString messageText;
        
        // 检测文件类型
        if (suffix == "png" || suffix == "jpg" || suffix == "jpeg" || suffix == "bmp") {
            // 对于图片文件，使用特殊格式标记
            messageText = QString("[IMAGE:%1]").arg(filePath);
            
            // 在输入框中显示图片
            QTextCursor cursor(ui->inputs->textCursor());
            if (!ui->inputs->toPlainText().isEmpty()) {
                cursor.movePosition(QTextCursor::End);
                cursor.insertText("\n");
            }
            
            // 加载图片并插入，不显示标记文本
            QImage image(filePath);
            if (!image.isNull()) {
                // 缩放图片以适应输入框，保持宽高比
                QImage scaledImage = image.scaled(
                            QSize(200, 200),  // 最大尺寸
                            Qt::KeepAspectRatio, 
                            Qt::SmoothTransformation);
                
                // 创建临时图片资源，使用文件路径作为标识
                QTextDocument *doc = ui->inputs->document();
                doc->addResource(QTextDocument::ImageResource, QUrl(messageText), scaledImage);
                
                // 插入图片，使用消息文本作为图片标识符
                cursor.insertImage(messageText);
                
                // 在图片后插入换行
                cursor.movePosition(QTextCursor::End);
                cursor.insertText("\n");
            } else {
                // 如果图片加载失败，显示错误信息
                cursor.movePosition(QTextCursor::End);
                cursor.insertText("图片加载失败: " + fileName);
                cursor.insertText("\n");
            }
        } else {
            // 对于其他文件类型，显示文件信息
            messageText = QString("[文件：%1 (%2)]").arg(fileName).arg(suffix.toUpper());
            
            // 将文件信息添加到输入栏
            QString currentText = ui->inputs->toPlainText();
            if (!currentText.isEmpty()) {
                currentText += "\n";
            }
            currentText += messageText;
            ui->inputs->setPlainText(currentText);
        }
        
        // 确保发送按钮可见
        ui->send->show();
    }
    
    isProcessing = false;
}

// 初始化表情选择窗口
void home::initEmojiWindow()
{
    m_emojiWindow = new QWidget(this);
    m_emojiWindow->setWindowFlags(Qt::Popup);
    m_emojiWindow->setFixedSize(200, 200);
    m_emojiWindow->setStyleSheet("background-color: white; border: 1px solid #e0e0e0;");
    
    m_emojiLayout = new QGridLayout(m_emojiWindow);
    m_emojiLayout->setSpacing(5);
    m_emojiLayout->setContentsMargins(5, 5, 5, 5);
    
    // 添加表情按钮
    int row = 0;
    int col = 0;
    for (const QString& emoji : m_commonEmojis) {
        QPushButton *emojiBtn = new QPushButton(emoji, m_emojiWindow);
        emojiBtn->setFixedSize(30, 30);
        emojiBtn->setStyleSheet("border: none; background-color: transparent;");
        
        // 连接表情按钮的点击信号
        connect(emojiBtn, &QPushButton::clicked, this, [this, emoji]() {
            on_emoji_selected(emoji);
        });
        
        m_emojiLayout->addWidget(emojiBtn, row, col);
        
        col++;
        if (col == 6) {
            col = 0;
            row++;
        }
    }
    
    m_emojiWindow->setLayout(m_emojiLayout);
}

// 表情按钮点击事件
void home::on_emo_clicked()
{
    if (m_emojiWindow) {
        // 计算表情窗口的位置
        QPoint pos = ui->emo->mapToGlobal(QPoint(0, ui->emo->height()));
        m_emojiWindow->move(pos);
        m_emojiWindow->show();
    }
}

// 表情选择事件
void home::on_emoji_selected(const QString& emoji)
{
    if (m_emojiWindow) {
        m_emojiWindow->hide();
    }
    
    // 获取当前输入框的光标位置
    QTextCursor cursor = ui->inputs->textCursor();
    
    // 将表情插入到光标位置
    cursor.insertText(emoji);
    
    // 确保输入框可见并获得焦点
    ui->inputs->show();
    ui->inputs->setFocus();
}
