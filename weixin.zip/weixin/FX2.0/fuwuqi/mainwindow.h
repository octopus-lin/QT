#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpServer>
#include <QTcpSocket>
#include <QUdpSocket>
#include <QList>
#include <QHash>
#include <QSqlDatabase>
#include <QBuffer>
#include <QStandardItemModel>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void newConnection();
    void readData();
    void clientDisconnected();
    void on_sendButton_clicked();
    void on_clearDbButton_clicked();
    void on_searchButton_clicked();
    void on_showFriendsButton_clicked();
    void readUdpData();

private:
    Ui::MainWindow *ui;
    QTcpServer *tcpServer;
    QUdpSocket *udpServer;
    QList<QTcpSocket*> clientSockets;
    QSqlDatabase db;
    QHash<QTcpSocket*, QString> clientUsers;
    QHash<QString, QTcpSocket*> onlineUsers;
    QStandardItemModel *friendsModel;

    // 好友请求管理
    QHash<QString, QSet<QString>> friendRequests; // 存储每个用户收到的好友请求
    void addPendingFriendUpdate(const QString &username, const QString &newFriend);
    // 视频通话状态管理
    struct VideoCall {
        QString initiator;
        QString receiver;
        QHostAddress initiatorAddr;
        quint16 initiatorUdpPort;
        QHostAddress receiverAddr;
        quint16 receiverUdpPort;
    };
    QHash<QString, VideoCall> activeVideoCalls;

    void addMessage(const QString &message);
    void sendTextToClient(QTcpSocket* clientSocket, const QString& message);
    void sendDataToClient(QTcpSocket* clientSocket, const QByteArray& data);
    void initDatabase();
    bool registerUser(const QString &username, const QString &password, const QString &nickname);
    bool authenticateUser(const QString &username, const QString &password);
    bool uploadAvatar(const QString &username, const QByteArray &avatarData);
    QByteArray downloadAvatar(const QString &username);
    bool addFriend(const QString &user1, const QString &user2);
    QList<QString> getFriends(const QString &username);
    void sendFriendList(QTcpSocket *socket, const QString &username);
    void sendOnlineNotification(const QString &username, bool isOnline);
    void sendPrivateMessage(const QString &sender, const QString &receiver, const QString &message);
    void updateOnlineUsersList();
    void handleVideoCallRequest(const QString &sender, const QString &receiver, QTcpSocket *socket);
    void endVideoCall(const QString &username);
    void processClientMessage(QTcpSocket* clientSocket, const QString& message);
    QString getNickname(const QString &username);
    bool updateNickname(const QString &username, const QString &nickname);

    // 新增好友请求处理函数
    void sendFriendRequestNotification(const QString &sender, const QString &receiver);
    void processFriendRequest(const QString &sender, const QString &receiver);
    void updateFriendListForUser(const QString &username);
    void resendPendingFriendRequests(const QString &username);
    void storeOfflineMessage(const QString &sender, const QString &receiver, const QString &message);
    void sendOfflineMessages(QTcpSocket *socket, const QString &username);
    bool areFriends(const QString &user1, const QString &user2);

    quint16 tcpPort;
    quint16 udpPort;
    void startServers(); // 新增服务器启动函数
    QString getLocalIP(); // 获取本地IP地址
    void on_applyPortButton_clicked();
    bool removeFriend(const QString &user1, const QString &user2);
};
#endif // MAINWINDOW_H
