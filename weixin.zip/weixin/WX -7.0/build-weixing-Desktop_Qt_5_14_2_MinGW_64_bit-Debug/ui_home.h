/********************************************************************************
** Form generated from reading UI file 'home.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOME_H
#define UI_HOME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListView>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_home
{
public:
    QWidget *homeWidget;
    QPushButton *close;
    QPushButton *mybut;
    QPushButton *wxlt;
    QListWidget *prints;
    QTextEdit *inputs;
    QListWidget *list_friend;
    QPushButton *send;
    QLabel *username;
    QPushButton *tongxun;
    QPushButton *shoucang;
    QPushButton *friend_quan;
    QPushButton *shipinhao;
    QPushButton *souyiso;
    QPushButton *xiaochengxu;
    QPushButton *phone;
    QPushButton *more;
    QPushButton *emo;
    QPushButton *wenjian;
    QPushButton *jietu;
    QPushButton *liaotianjilv;
    QPushButton *shiping_dh;
    QPushButton *dianhua;
    QPushButton *kuaijie;
    QListView *listView;
    QPushButton *k1;
    QPushButton *k2;
    QPushButton *k3;
    QListView *listView_2;
    QPushButton *b5;
    QPushButton *b2;
    QPushButton *b3;
    QPushButton *b6;
    QPushButton *b4;
    QPushButton *b1;
    QLabel *touxiang;
    QPushButton *liaotian_xx;
    QPushButton *fangda;
    QPushButton *suoxiao;
    QLabel *txl;
    QLabel *xiaoxi;
    QListWidget *list_yz;
    QWidget *widget;
    QLabel *beijing;

    void setupUi(QWidget *home)
    {
        if (home->objectName().isEmpty())
            home->setObjectName(QString::fromUtf8("home"));
        home->resize(1061, 811);
        homeWidget = new QWidget(home);
        homeWidget->setObjectName(QString::fromUtf8("homeWidget"));
        homeWidget->setGeometry(QRect(0, 0, 1061, 811));
        homeWidget->setStyleSheet(QString::fromUtf8(""));
        close = new QPushButton(homeWidget);
        close->setObjectName(QString::fromUtf8("close"));
        close->setGeometry(QRect(1005, 0, 57, 39));
        close->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 57px;\n"
"    min-height: 39px;\n"
"    max-width: 57px;\n"
"    max-height: 39px;\n"
"    border-top-right-radius: 10px; /* \345\217\263\344\270\212\350\247\222\345\234\206\350\247\22210px */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/red-x2.png\"); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\266\346\230\276\347\244\272\346\214\207\345\256\232\345\233\276\347\211\207 */\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-top-right-radius: 10px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\234\206\350\247\222 */\n"
"}"));
        mybut = new QPushButton(homeWidget);
        mybut->setObjectName(QString::fromUtf8("mybut"));
        mybut->setGeometry(QRect(13, 28, 46, 46));
        mybut->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 46px;\n"
"    min-height: 46px;\n"
"    max-width: 46px;\n"
"    max-height: 46px;\n"
"    border-radius: 4px;\n"
"}"));
        wxlt = new QPushButton(homeWidget);
        wxlt->setObjectName(QString::fromUtf8("wxlt"));
        wxlt->setGeometry(QRect(12, 95, 50, 50));
        wxlt->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 50px;\n"
"    min-height: 50px;\n"
"    max-width: 50px;\n"
"    max-height: 50px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        prints = new QListWidget(homeWidget);
        prints->setObjectName(QString::fromUtf8("prints"));
        prints->setGeometry(QRect(350, 86, 711, 513));
        prints->setStyleSheet(QString::fromUtf8("/* \345\237\272\347\241\200\345\210\227\350\241\250\346\240\267\345\274\217 */\n"
"QListWidget {\n"
"    background-color: rgb(243, 243, 243);\n"
"    border: none;\n"
"    font-size: 18px;\n"
"    font-family: \"Microsoft YaHei\";\n"
"\n"
"}\n"
"\n"
"\n"
"\n"
"  \n"
""));
        inputs = new QTextEdit(homeWidget);
        inputs->setObjectName(QString::fromUtf8("inputs"));
        inputs->setGeometry(QRect(360, 660, 680, 81));
        inputs->setStyleSheet(QString::fromUtf8("background-color: rgb(243, 243, 243); \n"
"border: none;\n"
"font-size: 18px; /* \345\201\207\350\256\276\344\271\213\345\211\215\350\256\276\347\275\256\347\232\204\345\255\227\345\217\267\357\274\214\345\217\257\344\277\235\347\225\231\346\210\226\350\260\203\346\225\264 */\n"
"font-family: \"Microsoft YaHei\"; /* Windows \347\263\273\347\273\237\345\270\270\347\224\250\344\270\255\346\226\207\345\255\227\344\275\223 */"));
        list_friend = new QListWidget(homeWidget);
        list_friend->setObjectName(QString::fromUtf8("list_friend"));
        list_friend->setGeometry(QRect(75, 86, 263, 721));
        list_friend->setStyleSheet(QString::fromUtf8("background-color: rgb(254, 254, 254); \n"
"border: none;\n"
""));
        send = new QPushButton(homeWidget);
        send->setObjectName(QString::fromUtf8("send"));
        send->setGeometry(QRect(922, 752, 120, 40));
        send->setStyleSheet(QString::fromUtf8("background-image: url(\":/img/img/fasong.png\");\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-radius: 5px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\233\233\344\270\252\350\247\222\345\234\206\350\247\222 */"));
        username = new QLabel(homeWidget);
        username->setObjectName(QString::fromUtf8("username"));
        username->setGeometry(QRect(355, 30, 531, 31));
        username->setStyleSheet(QString::fromUtf8("background-color: rgb(243, 243, 243); \n"
"border: none;\n"
"font-size: 20px; /* \345\201\207\350\256\276\344\271\213\345\211\215\350\256\276\347\275\256\347\232\204\345\255\227\345\217\267\357\274\214\345\217\257\344\277\235\347\225\231\346\210\226\350\260\203\346\225\264 */\n"
"font-family: \"Microsoft YaHei\"; /* Windows \347\263\273\347\273\237\345\270\270\347\224\250\344\270\255\346\226\207\345\255\227\344\275\223 */"));
        tongxun = new QPushButton(homeWidget);
        tongxun->setObjectName(QString::fromUtf8("tongxun"));
        tongxun->setGeometry(QRect(12, 155, 50, 50));
        tongxun->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 50px;\n"
"    min-height: 50px;\n"
"    max-width: 50px;\n"
"    max-height: 50px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        shoucang = new QPushButton(homeWidget);
        shoucang->setObjectName(QString::fromUtf8("shoucang"));
        shoucang->setGeometry(QRect(12, 215, 50, 50));
        shoucang->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 50px;\n"
"    min-height: 50px;\n"
"    max-width: 50px;\n"
"    max-height: 50px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        friend_quan = new QPushButton(homeWidget);
        friend_quan->setObjectName(QString::fromUtf8("friend_quan"));
        friend_quan->setGeometry(QRect(12, 275, 50, 50));
        friend_quan->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 50px;\n"
"    min-height: 50px;\n"
"    max-width: 50px;\n"
"    max-height: 50px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        shipinhao = new QPushButton(homeWidget);
        shipinhao->setObjectName(QString::fromUtf8("shipinhao"));
        shipinhao->setGeometry(QRect(12, 335, 50, 50));
        shipinhao->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 50px;\n"
"    min-height: 50px;\n"
"    max-width: 50px;\n"
"    max-height: 50px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        souyiso = new QPushButton(homeWidget);
        souyiso->setObjectName(QString::fromUtf8("souyiso"));
        souyiso->setGeometry(QRect(12, 395, 50, 50));
        souyiso->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 50px;\n"
"    min-height: 50px;\n"
"    max-width: 50px;\n"
"    max-height: 50px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        xiaochengxu = new QPushButton(homeWidget);
        xiaochengxu->setObjectName(QString::fromUtf8("xiaochengxu"));
        xiaochengxu->setGeometry(QRect(12, 455, 50, 50));
        xiaochengxu->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 50px;\n"
"    min-height: 50px;\n"
"    max-width: 50px;\n"
"    max-height: 50px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        phone = new QPushButton(homeWidget);
        phone->setObjectName(QString::fromUtf8("phone"));
        phone->setGeometry(QRect(12, 672, 50, 50));
        phone->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 50px;\n"
"    min-height: 50px;\n"
"    max-width: 50px;\n"
"    max-height: 50px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        more = new QPushButton(homeWidget);
        more->setObjectName(QString::fromUtf8("more"));
        more->setGeometry(QRect(12, 731, 50, 50));
        more->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 50px;\n"
"    min-height: 50px;\n"
"    max-width: 50px;\n"
"    max-height: 50px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        emo = new QPushButton(homeWidget);
        emo->setObjectName(QString::fromUtf8("emo"));
        emo->setGeometry(QRect(354, 612, 40, 40));
        emo->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 40px;\n"
"    min-height: 40px;\n"
"    max-width: 40px;\n"
"    max-height: 40px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        wenjian = new QPushButton(homeWidget);
        wenjian->setObjectName(QString::fromUtf8("wenjian"));
        wenjian->setGeometry(QRect(404, 612, 40, 40));
        wenjian->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 40px;\n"
"    min-height: 40px;\n"
"    max-width: 40px;\n"
"    max-height: 40px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        jietu = new QPushButton(homeWidget);
        jietu->setObjectName(QString::fromUtf8("jietu"));
        jietu->setGeometry(QRect(454, 612, 40, 40));
        jietu->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 40px;\n"
"    min-height: 40px;\n"
"    max-width: 40px;\n"
"    max-height: 40px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        liaotianjilv = new QPushButton(homeWidget);
        liaotianjilv->setObjectName(QString::fromUtf8("liaotianjilv"));
        liaotianjilv->setGeometry(QRect(519, 612, 40, 40));
        liaotianjilv->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 40px;\n"
"    min-height: 40px;\n"
"    max-width: 40px;\n"
"    max-height: 40px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        shiping_dh = new QPushButton(homeWidget);
        shiping_dh->setObjectName(QString::fromUtf8("shiping_dh"));
        shiping_dh->setGeometry(QRect(1002, 612, 40, 40));
        shiping_dh->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 40px;\n"
"    min-height: 40px;\n"
"    max-width: 40px;\n"
"    max-height: 40px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        dianhua = new QPushButton(homeWidget);
        dianhua->setObjectName(QString::fromUtf8("dianhua"));
        dianhua->setGeometry(QRect(950, 612, 40, 40));
        dianhua->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 40px;\n"
"    min-height: 40px;\n"
"    max-width: 40px;\n"
"    max-height: 40px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        kuaijie = new QPushButton(homeWidget);
        kuaijie->setObjectName(QString::fromUtf8("kuaijie"));
        kuaijie->setGeometry(QRect(291, 35, 33, 34));
        kuaijie->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 33px;\n"
"    min-height: 34px;\n"
"    max-width: 33px;\n"
"    max-height: 34px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.03); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        listView = new QListView(homeWidget);
        listView->setObjectName(QString::fromUtf8("listView"));
        listView->setGeometry(QRect(235, 80, 145, 156));
        listView->setStyleSheet(QString::fromUtf8("QListView#listView {\n"
"    border: none; \n"
"    /* \350\256\276\347\275\256\350\203\214\346\231\257\345\233\276\347\211\207\357\274\214\345\201\207\350\256\276\345\233\276\347\211\207\345\222\214\346\240\267\345\274\217\350\241\250\346\226\207\344\273\266\345\220\214\344\270\200\347\233\256\345\275\225\357\274\214\346\240\271\346\215\256\345\256\236\351\231\205\350\267\257\345\276\204\350\260\203\346\225\264 */\n"
"    background-image: url(:/img/img/list1.png); \n"
"    /* \350\256\251\350\203\214\346\231\257\345\233\276\347\211\207\351\200\202\345\272\224\346\216\247\344\273\266\345\244\247\345\260\217\357\274\214\345\217\257\346\240\271\346\215\256\351\234\200\346\261\202\350\260\203\346\225\264\357\274\214\346\257\224\345\246\202 repeat \347\255\211 */\n"
"	border-radius: 5px;\n"
"}"));
        k1 = new QPushButton(homeWidget);
        k1->setObjectName(QString::fromUtf8("k1"));
        k1->setGeometry(QRect(240, 96, 135, 45));
        k1->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent;\n"
"    color: black;\n"
"    border: none;\n"
"    min-width: 135px;\n"
"    min-height: 45px;\n"
"    max-width: 135px;\n"
"    max-height: 45px;\n"
"    border-radius: 8px; /* \345\233\233\344\270\252\350\247\222\351\203\275\350\256\276\347\275\256\344\270\27210px\345\234\206\350\247\222 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/k1.png\");\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-radius: 8px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\233\233\344\270\252\350\247\222\345\234\206\350\247\222 */\n"
"}"));
        k2 = new QPushButton(homeWidget);
        k2->setObjectName(QString::fromUtf8("k2"));
        k2->setGeometry(QRect(241, 141, 135, 45));
        k2->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent;\n"
"    color: black;\n"
"    border: none;\n"
"    min-width: 135px;\n"
"    min-height: 45px;\n"
"    max-width: 135px;\n"
"    max-height: 45px;\n"
"    border-radius: 8px; /* \345\233\233\344\270\252\350\247\222\351\203\275\350\256\276\347\275\256\344\270\27210px\345\234\206\350\247\222 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/k2.png\");\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-radius: 8px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\233\233\344\270\252\350\247\222\345\234\206\350\247\222 */\n"
"}"));
        k3 = new QPushButton(homeWidget);
        k3->setObjectName(QString::fromUtf8("k3"));
        k3->setGeometry(QRect(240, 186, 135, 45));
        k3->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent;\n"
"    color: black;\n"
"    border: none;\n"
"    min-width: 135px;\n"
"    min-height: 45px;\n"
"    max-width: 135px;\n"
"    max-height: 45px;\n"
"    border-radius: 8px; /* \345\233\233\344\270\252\350\247\222\351\203\275\350\256\276\347\275\256\344\270\27210px\345\234\206\350\247\222 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/k3.png\");\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-radius: 8px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\233\233\344\270\252\350\247\222\345\234\206\350\247\222 */\n"
"}"));
        listView_2 = new QListView(homeWidget);
        listView_2->setObjectName(QString::fromUtf8("listView_2"));
        listView_2->setGeometry(QRect(60, 490, 172, 290));
        listView_2->setStyleSheet(QString::fromUtf8("QListView#listView_2 {\n"
"    border: none; \n"
"    /* \350\256\276\347\275\256\350\203\214\346\231\257\345\233\276\347\211\207\357\274\214\345\201\207\350\256\276\345\233\276\347\211\207\345\222\214\346\240\267\345\274\217\350\241\250\346\226\207\344\273\266\345\220\214\344\270\200\347\233\256\345\275\225\357\274\214\346\240\271\346\215\256\345\256\236\351\231\205\350\267\257\345\276\204\350\260\203\346\225\264 */\n"
"    background-image: url(:/img/img/gengduo.png); \n"
"    /* \350\256\251\350\203\214\346\231\257\345\233\276\347\211\207\351\200\202\345\272\224\346\216\247\344\273\266\345\244\247\345\260\217\357\274\214\345\217\257\346\240\271\346\215\256\351\234\200\346\261\202\350\260\203\346\225\264\357\274\214\346\257\224\345\246\202 repeat \347\255\211 */\n"
"	border-radius: 5px;\n"
"}"));
        b5 = new QPushButton(homeWidget);
        b5->setObjectName(QString::fromUtf8("b5"));
        b5->setGeometry(QRect(70, 678, 153, 50));
        b5->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent;\n"
"    color: black;\n"
"    border: none;\n"
"    min-width: 153px;\n"
"    min-height: 50px;\n"
"    max-width: 153px;\n"
"    max-height: 50px;\n"
"    border-radius: 8px; /* \345\233\233\344\270\252\350\247\222\351\203\275\350\256\276\347\275\256\344\270\27210px\345\234\206\350\247\222 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/b5.png\");\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-radius: 8px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\233\233\344\270\252\350\247\222\345\234\206\350\247\222 */\n"
"}"));
        b2 = new QPushButton(homeWidget);
        b2->setObjectName(QString::fromUtf8("b2"));
        b2->setGeometry(QRect(70, 542, 153, 50));
        b2->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent;\n"
"    color: black;\n"
"    border: none;\n"
"    min-width: 153px;\n"
"    min-height: 50px;\n"
"    max-width: 153px;\n"
"    max-height: 50px;\n"
"    border-radius: 8px; /* \345\233\233\344\270\252\350\247\222\351\203\275\350\256\276\347\275\256\344\270\27210px\345\234\206\350\247\222 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/b2.png\");\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-radius: 8px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\233\233\344\270\252\350\247\222\345\234\206\350\247\222 */\n"
"}"));
        b3 = new QPushButton(homeWidget);
        b3->setObjectName(QString::fromUtf8("b3"));
        b3->setGeometry(QRect(70, 587, 153, 50));
        b3->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent;\n"
"    color: black;\n"
"    border: none;\n"
"    min-width: 153px;\n"
"    min-height: 50px;\n"
"    max-width: 153px;\n"
"    max-height: 50px;\n"
"    border-radius: 8px; /* \345\233\233\344\270\252\350\247\222\351\203\275\350\256\276\347\275\256\344\270\27210px\345\234\206\350\247\222 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/b3.png\");\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-radius: 8px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\233\233\344\270\252\350\247\222\345\234\206\350\247\222 */\n"
"}"));
        b6 = new QPushButton(homeWidget);
        b6->setObjectName(QString::fromUtf8("b6"));
        b6->setGeometry(QRect(71, 723, 153, 50));
        b6->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent;\n"
"    color: black;\n"
"    border: none;\n"
"    min-width: 153px;\n"
"    min-height: 50px;\n"
"    max-width: 153px;\n"
"    max-height: 50px;\n"
"    border-radius: 8px; /* \345\233\233\344\270\252\350\247\222\351\203\275\350\256\276\347\275\256\344\270\27210px\345\234\206\350\247\222 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/b6.png\");\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-radius: 8px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\233\233\344\270\252\350\247\222\345\234\206\350\247\222 */\n"
"}"));
        b4 = new QPushButton(homeWidget);
        b4->setObjectName(QString::fromUtf8("b4"));
        b4->setGeometry(QRect(70, 632, 153, 50));
        b4->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent;\n"
"    color: black;\n"
"    border: none;\n"
"    min-width: 153px;\n"
"    min-height: 50px;\n"
"    max-width: 153px;\n"
"    max-height: 50px;\n"
"    border-radius: 8px; /* \345\233\233\344\270\252\350\247\222\351\203\275\350\256\276\347\275\256\344\270\27210px\345\234\206\350\247\222 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/b4.png\");\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-radius: 8px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\233\233\344\270\252\350\247\222\345\234\206\350\247\222 */\n"
"}"));
        b1 = new QPushButton(homeWidget);
        b1->setObjectName(QString::fromUtf8("b1"));
        b1->setGeometry(QRect(70, 497, 153, 50));
        b1->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent;\n"
"    color: black;\n"
"    border: none;\n"
"    min-width: 153px;\n"
"    min-height: 50px;\n"
"    max-width: 153px;\n"
"    max-height: 50px;\n"
"    border-radius: 8px; /* \345\233\233\344\270\252\350\247\222\351\203\275\350\256\276\347\275\256\344\270\27210px\345\234\206\350\247\222 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/b1.png\");\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-radius: 8px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\233\233\344\270\252\350\247\222\345\234\206\350\247\222 */\n"
"}"));
        touxiang = new QLabel(homeWidget);
        touxiang->setObjectName(QString::fromUtf8("touxiang"));
        touxiang->setGeometry(QRect(13, 28, 46, 46));
        touxiang->setStyleSheet(QString::fromUtf8("min-width: 46px;\n"
"min-height: 46px;\n"
"max-width: 46px;\n"
"max-height: 46px;\n"
"border-radius: 4px;\n"
"background-color: rgb(255, 255, 127);\n"
""));
        liaotian_xx = new QPushButton(homeWidget);
        liaotian_xx->setObjectName(QString::fromUtf8("liaotian_xx"));
        liaotian_xx->setGeometry(QRect(1007, 39, 40, 40));
        liaotian_xx->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 40px;\n"
"    min-height: 40px;\n"
"    max-width: 40px;\n"
"    max-height: 40px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        fangda = new QPushButton(homeWidget);
        fangda->setObjectName(QString::fromUtf8("fangda"));
        fangda->setGeometry(QRect(947, 0, 56, 38));
        fangda->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"\n"
"}    "));
        suoxiao = new QPushButton(homeWidget);
        suoxiao->setObjectName(QString::fromUtf8("suoxiao"));
        suoxiao->setGeometry(QRect(890, 0, 56, 38));
        suoxiao->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"\n"
"}    "));
        txl = new QLabel(homeWidget);
        txl->setObjectName(QString::fromUtf8("txl"));
        txl->setGeometry(QRect(14, 161, 41, 41));
        txl->setStyleSheet(QString::fromUtf8("background-image: url(:/img/img/txl.png);"));
        xiaoxi = new QLabel(homeWidget);
        xiaoxi->setObjectName(QString::fromUtf8("xiaoxi"));
        xiaoxi->setGeometry(QRect(16, 101, 41, 41));
        xiaoxi->setStyleSheet(QString::fromUtf8("background-image: url(:/img/img/xiaoxi.png);"));
        list_yz = new QListWidget(homeWidget);
        list_yz->setObjectName(QString::fromUtf8("list_yz"));
        list_yz->setGeometry(QRect(75, 86, 263, 721));
        list_yz->setStyleSheet(QString::fromUtf8("background-color: rgb(254, 254, 254); \n"
"border: none;\n"
""));
        widget = new QWidget(homeWidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(340, 30, 721, 781));
        beijing = new QLabel(widget);
        beijing->setObjectName(QString::fromUtf8("beijing"));
        beijing->setGeometry(QRect(0, -180, 720, 951));
        beijing->setStyleSheet(QString::fromUtf8("background-color: rgb(243, 243, 243);\n"
"border: none;\n"
"font-size: 18px;\n"
"font-family: \"Microsoft YaHei\";\n"
""));
        username->raise();
        send->raise();
        prints->raise();
        widget->raise();
        list_friend->raise();
        kuaijie->raise();
        list_yz->raise();
        xiaoxi->raise();
        txl->raise();
        touxiang->raise();
        close->raise();
        mybut->raise();
        wxlt->raise();
        inputs->raise();
        tongxun->raise();
        shoucang->raise();
        friend_quan->raise();
        shipinhao->raise();
        souyiso->raise();
        xiaochengxu->raise();
        phone->raise();
        more->raise();
        emo->raise();
        wenjian->raise();
        jietu->raise();
        liaotianjilv->raise();
        shiping_dh->raise();
        dianhua->raise();
        listView->raise();
        k1->raise();
        k2->raise();
        k3->raise();
        listView_2->raise();
        b5->raise();
        b2->raise();
        b3->raise();
        b6->raise();
        b4->raise();
        b1->raise();
        liaotian_xx->raise();
        fangda->raise();
        suoxiao->raise();

        retranslateUi(home);

        QMetaObject::connectSlotsByName(home);
    } // setupUi

    void retranslateUi(QWidget *home)
    {
        home->setWindowTitle(QCoreApplication::translate("home", "Form", nullptr));
        close->setText(QString());
        mybut->setText(QString());
        wxlt->setText(QString());
        send->setText(QString());
        username->setText(QCoreApplication::translate("home", "\345\276\256\344\277\241\345\233\242\351\230\237", nullptr));
        tongxun->setText(QString());
        shoucang->setText(QString());
        friend_quan->setText(QString());
        shipinhao->setText(QString());
        souyiso->setText(QString());
        xiaochengxu->setText(QString());
        phone->setText(QString());
        more->setText(QString());
        emo->setText(QString());
        wenjian->setText(QString());
        jietu->setText(QString());
        liaotianjilv->setText(QString());
        shiping_dh->setText(QString());
        dianhua->setText(QString());
        kuaijie->setText(QString());
        k1->setText(QString());
        k2->setText(QString());
        k3->setText(QString());
        b5->setText(QString());
        b2->setText(QString());
        b3->setText(QString());
        b6->setText(QString());
        b4->setText(QString());
        b1->setText(QString());
        touxiang->setText(QString());
        liaotian_xx->setText(QString());
        fangda->setText(QString());
        suoxiao->setText(QString());
        txl->setText(QString());
        xiaoxi->setText(QString());
        beijing->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class home: public Ui_home {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOME_H
