// caijian.h
#ifndef CAIJIAN_H
#define CAIJIAN_H

#include <QDialog>
#include <QPixmap>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QGraphicsRectItem>

class CropDialog : public QDialog {
    Q_OBJECT
public:
    CropDialog(const QPixmap &pixmap, QWidget *parent = nullptr);
    QPixmap croppedPixmap() const;
    QRectF cropArea() const;

protected:
    void resizeEvent(QResizeEvent *event) override;

private:
    // 完整的嵌套类定义
    class AspectRatioRectItem : public QGraphicsRectItem {
    public:
        AspectRatioRectItem(QGraphicsItem *parent = nullptr);

        // 鼠标事件处理
        void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
        void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;
        void mouseReleaseEvent(QGraphicsSceneMouseEvent *event) override;

        // 位置变化处理
        QVariant itemChange(GraphicsItemChange change, const QVariant &value) override;

    private:
        Qt::Corner getCorner(const QPointF &pos);
        void resizeRect(const QPointF &pos);

        bool isResizing;
        Qt::Corner resizeCorner;
    };

    QGraphicsView *view;
    QGraphicsScene *scene;
    QGraphicsPixmapItem *pixmapItem;
    QPixmap originalPixmap;
    AspectRatioRectItem *cropRect;
};

#endif // CAIJIAN_H
