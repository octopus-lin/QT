/********************************************************************************
** Form generated from reading UI file 'add_friend.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADD_FRIEND_H
#define UI_ADD_FRIEND_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_add_friend
{
public:
    QWidget *centralwidget;
    QPushButton *close_f;
    QPushButton *lookf;
    QLineEdit *wx_id;
    QLabel *friend_xx;
    QLabel *touxiang;
    QPushButton *add_f;
    QLabel *name;
    QMenuBar *menubar;

    void setupUi(QMainWindow *add_friend)
    {
        if (add_friend->objectName().isEmpty())
            add_friend->setObjectName(QString::fromUtf8("add_friend"));
        add_friend->resize(404, 562);
        centralwidget = new QWidget(add_friend);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        close_f = new QPushButton(centralwidget);
        close_f->setObjectName(QString::fromUtf8("close_f"));
        close_f->setGeometry(QRect(349, -2, 57, 39));
        close_f->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 57px;\n"
"    min-height: 39px;\n"
"    max-width: 57px;\n"
"    max-height: 39px;\n"
"    border-top-right-radius: 18px; /* \345\217\263\344\270\212\350\247\222\345\234\206\350\247\22210px */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/red-x3.png\"); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\266\346\230\276\347\244\272\346\214\207\345\256\232\345\233\276\347\211\207 */\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-top-right-radius: 18px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\234\206\350\247\222 */\n"
"}"));
        lookf = new QPushButton(centralwidget);
        lookf->setObjectName(QString::fromUtf8("lookf"));
        lookf->setGeometry(QRect(290, 67, 87, 50));
        lookf->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent;\n"
"    color: black;\n"
"    border: none;\n"
"    min-width: 87px;\n"
"    min-height: 50px;\n"
"    max-width: 87px;\n"
"    max-height: 50px;\n"
"    border-radius: 10px; /* \345\233\233\344\270\252\350\247\222\351\203\275\350\256\276\347\275\256\344\270\27210px\345\234\206\350\247\222 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/sousuo.png\");\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-radius: 5px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\233\233\344\270\252\350\247\222\345\234\206\350\247\222 */\n"
"}"));
        wx_id = new QLineEdit(centralwidget);
        wx_id->setObjectName(QString::fromUtf8("wx_id"));
        wx_id->setGeometry(QRect(29, 67, 260, 50));
        wx_id->setCursor(QCursor(Qt::IBeamCursor));
        wx_id->setStyleSheet(QString::fromUtf8("/* \346\255\243\345\270\270\347\212\266\346\200\201\344\270\213\347\232\204\346\240\267\345\274\217 - \346\234\211\345\206\205\345\256\271\346\227\266\346\230\276\347\244\272\350\203\214\346\231\257\345\222\214\350\276\271\346\241\206 */\n"
"QLineEdit#wx_id {\n"
"    background-color: rgb(243, 243, 243);  /* \351\273\230\350\256\244\346\230\276\347\244\272\350\203\214\346\231\257 */\n"
"    border-radius: 5px;\n"
"    font-size: 18px;\n"
"    font-family: \"Microsoft YaHei\";\n"
"}\n"
"\n"
"\n"
"\n"
"/* \350\216\267\345\276\227\347\204\246\347\202\271\357\274\210\351\274\240\346\240\207\347\202\271\345\207\273\346\277\200\346\264\273\357\274\211\346\227\266\347\232\204\346\240\267\345\274\217 */\n"
"QLineEdit#wx_id:focus {\n"
"    background-color: rgb(254, 254, 254);  /* \346\230\276\347\244\272\350\203\214\346\231\257 */\n"
"    border: 2px solid rgb(6, 181, 90);     /* \346\230\276\347\244\272\347\273\277\350\211\262\350\276\271\346\241\206 */\n"
"    border-radius: 5px;\n"
"}"));
        wx_id->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        friend_xx = new QLabel(centralwidget);
        friend_xx->setObjectName(QString::fromUtf8("friend_xx"));
        friend_xx->setGeometry(QRect(30, 140, 349, 306));
        friend_xx->setStyleSheet(QString::fromUtf8("QLabel#friend_xx{\n"
"\n"
"background-image: url(:/img/img/friend-xx.png)\n"
"\n"
"\n"
"}"));
        touxiang = new QLabel(centralwidget);
        touxiang->setObjectName(QString::fromUtf8("touxiang"));
        touxiang->setGeometry(QRect(58, 170, 75, 75));
        touxiang->setStyleSheet(QString::fromUtf8("min-width: 75px;\n"
"min-height: 75px;\n"
"max-width: 75px;\n"
"max-height: 75px;\n"
"border-radius: 7px;\n"
"background-color: rgb(255, 255, 127);\n"
""));
        add_f = new QPushButton(centralwidget);
        add_f->setObjectName(QString::fromUtf8("add_f"));
        add_f->setGeometry(QRect(122, 295, 161, 37));
        add_f->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 161px;\n"
"    min-height: 37px;\n"
"    max-width: 161px;\n"
"    max-height: 37px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.03); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        name = new QLabel(centralwidget);
        name->setObjectName(QString::fromUtf8("name"));
        name->setGeometry(QRect(152, 168, 161, 31));
        name->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255); \n"
"border: none;\n"
"font-size: 20px; /* \345\201\207\350\256\276\344\271\213\345\211\215\350\256\276\347\275\256\347\232\204\345\255\227\345\217\267\357\274\214\345\217\257\344\277\235\347\225\231\346\210\226\350\260\203\346\225\264 */\n"
"font-family: \"Microsoft YaHei\"; /* Windows \347\263\273\347\273\237\345\270\270\347\224\250\344\270\255\346\226\207\345\255\227\344\275\223 */"));
        name->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        add_friend->setCentralWidget(centralwidget);
        menubar = new QMenuBar(add_friend);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 404, 26));
        add_friend->setMenuBar(menubar);

        retranslateUi(add_friend);

        QMetaObject::connectSlotsByName(add_friend);
    } // setupUi

    void retranslateUi(QMainWindow *add_friend)
    {
        add_friend->setWindowTitle(QCoreApplication::translate("add_friend", "MainWindow", nullptr));
        close_f->setText(QString());
        lookf->setText(QString());
        wx_id->setPlaceholderText(QCoreApplication::translate("add_friend", "\350\257\267\350\276\223\345\205\245\345\276\256\344\277\241\345\217\267", nullptr));
        friend_xx->setText(QString());
        touxiang->setText(QString());
        add_f->setText(QString());
        name->setText(QCoreApplication::translate("add_friend", "\350\212\261\346\256\213", nullptr));
    } // retranslateUi

};

namespace Ui {
    class add_friend: public Ui_add_friend {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADD_FRIEND_H
