/********************************************************************************
** Form generated from reading UI file 'friend_yz.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRIEND_YZ_H
#define UI_FRIEND_YZ_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_friend_yz
{
public:
    QWidget *centralwidget;
    QPushButton *quxiao;
    QPushButton *queding;
    QMenuBar *menubar;

    void setupUi(QMainWindow *friend_yz)
    {
        if (friend_yz->objectName().isEmpty())
            friend_yz->setObjectName(QString::fromUtf8("friend_yz"));
        friend_yz->resize(449, 825);
        friend_yz->setStyleSheet(QString::fromUtf8(""));
        centralwidget = new QWidget(friend_yz);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        quxiao = new QPushButton(centralwidget);
        quxiao->setObjectName(QString::fromUtf8("quxiao"));
        quxiao->setGeometry(QRect(230, 758, 116, 37));
        quxiao->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"	border-radius: 5px;\n"
"\n"
"}    "));
        queding = new QPushButton(centralwidget);
        queding->setObjectName(QString::fromUtf8("queding"));
        queding->setGeometry(QRect(100, 758, 120, 37));
        queding->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(6, 174, 87, 0.1); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"	border-radius: 5px;\n"
"\n"
"}    "));
        friend_yz->setCentralWidget(centralwidget);
        menubar = new QMenuBar(friend_yz);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 449, 26));
        friend_yz->setMenuBar(menubar);

        retranslateUi(friend_yz);

        QMetaObject::connectSlotsByName(friend_yz);
    } // setupUi

    void retranslateUi(QMainWindow *friend_yz)
    {
        friend_yz->setWindowTitle(QCoreApplication::translate("friend_yz", "MainWindow", nullptr));
        quxiao->setText(QString());
        queding->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class friend_yz: public Ui_friend_yz {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRIEND_YZ_H
