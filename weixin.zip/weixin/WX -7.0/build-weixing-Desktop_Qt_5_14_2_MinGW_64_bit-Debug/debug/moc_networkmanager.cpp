/****************************************************************************
** Meta object code from reading C++ file 'networkmanager.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../weixing/networkmanager.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'networkmanager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_NetworkManager_t {
    QByteArrayData data[45];
    char stringdata0[588];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_NetworkManager_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_NetworkManager_t qt_meta_stringdata_NetworkManager = {
    {
QT_MOC_LITERAL(0, 0, 14), // "NetworkManager"
QT_MOC_LITERAL(1, 15, 9), // "connected"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 12), // "disconnected"
QT_MOC_LITERAL(4, 39, 12), // "loginSuccess"
QT_MOC_LITERAL(5, 52, 8), // "nickname"
QT_MOC_LITERAL(6, 61, 11), // "loginFailed"
QT_MOC_LITERAL(7, 73, 6), // "reason"
QT_MOC_LITERAL(8, 80, 17), // "friendListUpdated"
QT_MOC_LITERAL(9, 98, 7), // "friends"
QT_MOC_LITERAL(10, 106, 22), // "privateMessageReceived"
QT_MOC_LITERAL(11, 129, 6), // "sender"
QT_MOC_LITERAL(12, 136, 7), // "message"
QT_MOC_LITERAL(13, 144, 18), // "avatarDataReceived"
QT_MOC_LITERAL(14, 163, 8), // "username"
QT_MOC_LITERAL(15, 172, 10), // "avatarData"
QT_MOC_LITERAL(16, 183, 20), // "videoRequestReceived"
QT_MOC_LITERAL(17, 204, 6), // "caller"
QT_MOC_LITERAL(18, 211, 7), // "udpPort"
QT_MOC_LITERAL(19, 219, 13), // "videoPeerInfo"
QT_MOC_LITERAL(20, 233, 4), // "peer"
QT_MOC_LITERAL(21, 238, 2), // "ip"
QT_MOC_LITERAL(22, 241, 4), // "port"
QT_MOC_LITERAL(23, 246, 13), // "videoRejected"
QT_MOC_LITERAL(24, 260, 8), // "receiver"
QT_MOC_LITERAL(25, 269, 10), // "videoEnded"
QT_MOC_LITERAL(26, 280, 15), // "registerSuccess"
QT_MOC_LITERAL(27, 296, 14), // "registerFailed"
QT_MOC_LITERAL(28, 311, 18), // "videoFrameReceived"
QT_MOC_LITERAL(29, 330, 9), // "frameData"
QT_MOC_LITERAL(30, 340, 13), // "errorOccurred"
QT_MOC_LITERAL(31, 354, 5), // "error"
QT_MOC_LITERAL(32, 360, 19), // "avatarUploadSuccess"
QT_MOC_LITERAL(33, 380, 18), // "avatarUploadFailed"
QT_MOC_LITERAL(34, 399, 20), // "searchResultReceived"
QT_MOC_LITERAL(35, 420, 5), // "found"
QT_MOC_LITERAL(36, 426, 21), // "friendRequestReceived"
QT_MOC_LITERAL(37, 448, 17), // "friendRequestSent"
QT_MOC_LITERAL(38, 466, 14), // "friendUsername"
QT_MOC_LITERAL(39, 481, 11), // "friendAdded"
QT_MOC_LITERAL(40, 493, 21), // "friendRequestAccepted"
QT_MOC_LITERAL(41, 515, 25), // "requesterNicknameReceived"
QT_MOC_LITERAL(42, 541, 21), // "serverMessageReceived"
QT_MOC_LITERAL(43, 563, 13), // "friendDeleted"
QT_MOC_LITERAL(44, 577, 10) // "friendName"

    },
    "NetworkManager\0connected\0\0disconnected\0"
    "loginSuccess\0nickname\0loginFailed\0"
    "reason\0friendListUpdated\0friends\0"
    "privateMessageReceived\0sender\0message\0"
    "avatarDataReceived\0username\0avatarData\0"
    "videoRequestReceived\0caller\0udpPort\0"
    "videoPeerInfo\0peer\0ip\0port\0videoRejected\0"
    "receiver\0videoEnded\0registerSuccess\0"
    "registerFailed\0videoFrameReceived\0"
    "frameData\0errorOccurred\0error\0"
    "avatarUploadSuccess\0avatarUploadFailed\0"
    "searchResultReceived\0found\0"
    "friendRequestReceived\0friendRequestSent\0"
    "friendUsername\0friendAdded\0"
    "friendRequestAccepted\0requesterNicknameReceived\0"
    "serverMessageReceived\0friendDeleted\0"
    "friendName"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_NetworkManager[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      25,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      25,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  139,    2, 0x06 /* Public */,
       3,    0,  140,    2, 0x06 /* Public */,
       4,    1,  141,    2, 0x06 /* Public */,
       6,    1,  144,    2, 0x06 /* Public */,
       8,    1,  147,    2, 0x06 /* Public */,
      10,    2,  150,    2, 0x06 /* Public */,
      13,    2,  155,    2, 0x06 /* Public */,
      16,    2,  160,    2, 0x06 /* Public */,
      19,    3,  165,    2, 0x06 /* Public */,
      23,    1,  172,    2, 0x06 /* Public */,
      25,    1,  175,    2, 0x06 /* Public */,
      26,    0,  178,    2, 0x06 /* Public */,
      27,    1,  179,    2, 0x06 /* Public */,
      28,    2,  182,    2, 0x06 /* Public */,
      30,    1,  187,    2, 0x06 /* Public */,
      32,    0,  190,    2, 0x06 /* Public */,
      33,    1,  191,    2, 0x06 /* Public */,
      34,    2,  194,    2, 0x06 /* Public */,
      36,    1,  199,    2, 0x06 /* Public */,
      37,    1,  202,    2, 0x06 /* Public */,
      39,    1,  205,    2, 0x06 /* Public */,
      40,    1,  208,    2, 0x06 /* Public */,
      41,    2,  211,    2, 0x06 /* Public */,
      42,    1,  216,    2, 0x06 /* Public */,
      43,    1,  219,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::QStringList,    9,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   11,   12,
    QMetaType::Void, QMetaType::QString, QMetaType::QByteArray,   14,   15,
    QMetaType::Void, QMetaType::QString, QMetaType::UShort,   17,   18,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::UShort,   20,   21,   22,
    QMetaType::Void, QMetaType::QString,   24,
    QMetaType::Void, QMetaType::QString,   20,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::QString, QMetaType::QByteArray,   11,   29,
    QMetaType::Void, QMetaType::QString,   31,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool,   14,   35,
    QMetaType::Void, QMetaType::QString,   11,
    QMetaType::Void, QMetaType::QString,   38,
    QMetaType::Void, QMetaType::QString,   38,
    QMetaType::Void, QMetaType::QString,   38,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   11,    5,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Void, QMetaType::QString,   44,

       0        // eod
};

void NetworkManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<NetworkManager *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->connected(); break;
        case 1: _t->disconnected(); break;
        case 2: _t->loginSuccess((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->loginFailed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->friendListUpdated((*reinterpret_cast< const QStringList(*)>(_a[1]))); break;
        case 5: _t->privateMessageReceived((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 6: _t->avatarDataReceived((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QByteArray(*)>(_a[2]))); break;
        case 7: _t->videoRequestReceived((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< quint16(*)>(_a[2]))); break;
        case 8: _t->videoPeerInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< quint16(*)>(_a[3]))); break;
        case 9: _t->videoRejected((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->videoEnded((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 11: _t->registerSuccess(); break;
        case 12: _t->registerFailed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 13: _t->videoFrameReceived((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QByteArray(*)>(_a[2]))); break;
        case 14: _t->errorOccurred((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 15: _t->avatarUploadSuccess(); break;
        case 16: _t->avatarUploadFailed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 17: _t->searchResultReceived((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 18: _t->friendRequestReceived((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 19: _t->friendRequestSent((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 20: _t->friendAdded((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 21: _t->friendRequestAccepted((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 22: _t->requesterNicknameReceived((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 23: _t->serverMessageReceived((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 24: _t->friendDeleted((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (NetworkManager::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::connected)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::disconnected)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::loginSuccess)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::loginFailed)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QStringList & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::friendListUpdated)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & , const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::privateMessageReceived)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & , const QByteArray & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::avatarDataReceived)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & , quint16 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::videoRequestReceived)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & , const QString & , quint16 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::videoPeerInfo)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::videoRejected)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::videoEnded)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::registerSuccess)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::registerFailed)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & , const QByteArray & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::videoFrameReceived)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::errorOccurred)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::avatarUploadSuccess)) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::avatarUploadFailed)) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::searchResultReceived)) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::friendRequestReceived)) {
                *result = 18;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::friendRequestSent)) {
                *result = 19;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::friendAdded)) {
                *result = 20;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::friendRequestAccepted)) {
                *result = 21;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & , const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::requesterNicknameReceived)) {
                *result = 22;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::serverMessageReceived)) {
                *result = 23;
                return;
            }
        }
        {
            using _t = void (NetworkManager::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkManager::friendDeleted)) {
                *result = 24;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject NetworkManager::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_NetworkManager.data,
    qt_meta_data_NetworkManager,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *NetworkManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *NetworkManager::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_NetworkManager.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int NetworkManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 25)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 25;
    }
    return _id;
}

// SIGNAL 0
void NetworkManager::connected()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void NetworkManager::disconnected()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void NetworkManager::loginSuccess(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void NetworkManager::loginFailed(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void NetworkManager::friendListUpdated(const QStringList & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void NetworkManager::privateMessageReceived(const QString & _t1, const QString & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void NetworkManager::avatarDataReceived(const QString & _t1, const QByteArray & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void NetworkManager::videoRequestReceived(const QString & _t1, quint16 _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void NetworkManager::videoPeerInfo(const QString & _t1, const QString & _t2, quint16 _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void NetworkManager::videoRejected(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void NetworkManager::videoEnded(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void NetworkManager::registerSuccess()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void NetworkManager::registerFailed(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void NetworkManager::videoFrameReceived(const QString & _t1, const QByteArray & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void NetworkManager::errorOccurred(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void NetworkManager::avatarUploadSuccess()
{
    QMetaObject::activate(this, &staticMetaObject, 15, nullptr);
}

// SIGNAL 16
void NetworkManager::avatarUploadFailed(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 16, _a);
}

// SIGNAL 17
void NetworkManager::searchResultReceived(const QString & _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 17, _a);
}

// SIGNAL 18
void NetworkManager::friendRequestReceived(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 18, _a);
}

// SIGNAL 19
void NetworkManager::friendRequestSent(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 19, _a);
}

// SIGNAL 20
void NetworkManager::friendAdded(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 20, _a);
}

// SIGNAL 21
void NetworkManager::friendRequestAccepted(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 21, _a);
}

// SIGNAL 22
void NetworkManager::requesterNicknameReceived(const QString & _t1, const QString & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 22, _a);
}

// SIGNAL 23
void NetworkManager::serverMessageReceived(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 23, _a);
}

// SIGNAL 24
void NetworkManager::friendDeleted(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 24, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
