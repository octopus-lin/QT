/********************************************************************************
** Form generated from reading UI file 'setwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETWINDOW_H
#define UI_SETWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_setwindow
{
public:
    QWidget *centralwidget;
    QPushButton *exit;
    QPushButton *fanhui;
    QWidget *switchWidget;
    QPushButton *switchButton;
    QLineEdit *input_ip;
    QLineEdit *input_prot;
    QLabel *dizhi;
    QLabel *duankou;
    QLabel *beijing;
    QPushButton *pying;
    QMenuBar *menubar;

    void setupUi(QMainWindow *setwindow)
    {
        if (setwindow->objectName().isEmpty())
            setwindow->setObjectName(QString::fromUtf8("setwindow"));
        setwindow->resize(348, 473);
        centralwidget = new QWidget(setwindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        exit = new QPushButton(centralwidget);
        exit->setObjectName(QString::fromUtf8("exit"));
        exit->setGeometry(QRect(292, 0, 57, 49));
        exit->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 57px;\n"
"    min-height: 49px;\n"
"    max-width: 57px;\n"
"    max-height: 49px;\n"
"    border-top-right-radius: 10px; /* \345\217\263\344\270\212\350\247\222\345\234\206\350\247\22210px */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/red-x.png\"); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\266\346\230\276\347\244\272\346\214\207\345\256\232\345\233\276\347\211\207 */\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-top-right-radius: 10px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\234\206\350\247\222 */\n"
"}"));
        fanhui = new QPushButton(centralwidget);
        fanhui->setObjectName(QString::fromUtf8("fanhui"));
        fanhui->setGeometry(QRect(9, 8, 35, 35));
        fanhui->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 35px;\n"
"    min-height: 35px;\n"
"    max-width: 35px;\n"
"    max-height: 35px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\26610%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}"));
        switchWidget = new QWidget(centralwidget);
        switchWidget->setObjectName(QString::fromUtf8("switchWidget"));
        switchWidget->setGeometry(QRect(263, 134, 36, 20));
        switchButton = new QPushButton(switchWidget);
        switchButton->setObjectName(QString::fromUtf8("switchButton"));
        switchButton->setGeometry(QRect(2, 2, 16, 16));
        input_ip = new QLineEdit(centralwidget);
        input_ip->setObjectName(QString::fromUtf8("input_ip"));
        input_ip->setGeometry(QRect(158, 210, 150, 30));
        input_ip->setCursor(QCursor(Qt::IBeamCursor));
        input_ip->setStyleSheet(QString::fromUtf8("/* \346\255\243\345\270\270\347\212\266\346\200\201\344\270\213\347\232\204\346\240\267\345\274\217 - \346\234\211\345\206\205\345\256\271\346\227\266\346\230\276\347\244\272\350\203\214\346\231\257\345\222\214\350\276\271\346\241\206 */\n"
"QLineEdit#input_ip {\n"
"    background-color: rgb(234, 234, 234);  /* \351\273\230\350\256\244\346\230\276\347\244\272\350\203\214\346\231\257 */\n"
"    border-radius: 5px;\n"
"    font-size: 18px;\n"
"    font-family: \"Microsoft YaHei\";\n"
"}\n"
"\n"
"\n"
"\n"
"/* \350\216\267\345\276\227\347\204\246\347\202\271\357\274\210\351\274\240\346\240\207\347\202\271\345\207\273\346\277\200\346\264\273\357\274\211\346\227\266\347\232\204\346\240\267\345\274\217 */\n"
"QLineEdit#input_ip:focus {\n"
"    background-color: rgb(255, 255, 255);  /* \346\230\276\347\244\272\350\203\214\346\231\257 */\n"
"    border: 2px solid rgb(6, 181, 90);     /* \346\230\276\347\244\272\347\273\277\350\211\262\350\276\271\346\241\206 */\n"
"    border-radius: 5px;\n"
"}\n"
"\n"
"QLineEdit#input"
                        "_ip:not(:focus) {\n"
"    border: 1px solid transparent;  /* \345\244\261\345\216\273\347\204\246\347\202\271\346\227\266\344\275\277\347\224\250\351\200\217\346\230\216\350\276\271\346\241\206 */\n"
"}"));
        input_ip->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        input_prot = new QLineEdit(centralwidget);
        input_prot->setObjectName(QString::fromUtf8("input_prot"));
        input_prot->setGeometry(QRect(158, 260, 150, 30));
        input_prot->setCursor(QCursor(Qt::IBeamCursor));
        input_prot->setStyleSheet(QString::fromUtf8("/* \346\255\243\345\270\270\347\212\266\346\200\201\344\270\213\347\232\204\346\240\267\345\274\217 - \346\234\211\345\206\205\345\256\271\346\227\266\346\230\276\347\244\272\350\203\214\346\231\257\345\222\214\350\276\271\346\241\206 */\n"
"QLineEdit#input_prot {\n"
"    background-color: rgb(234, 234, 234);  /* \351\273\230\350\256\244\346\230\276\347\244\272\350\203\214\346\231\257 */\n"
"    border-radius: 5px;\n"
"    font-size: 18px;\n"
"    font-family: \"Microsoft YaHei\";\n"
"}\n"
"\n"
"\n"
"\n"
"/* \350\216\267\345\276\227\347\204\246\347\202\271\357\274\210\351\274\240\346\240\207\347\202\271\345\207\273\346\277\200\346\264\273\357\274\211\346\227\266\347\232\204\346\240\267\345\274\217 */\n"
"QLineEdit#input_prot:focus {\n"
"    background-color: rgb(255, 255, 255);  /* \346\230\276\347\244\272\350\203\214\346\231\257 */\n"
"    border: 2px solid rgb(6, 181, 90);     /* \346\230\276\347\244\272\347\273\277\350\211\262\350\276\271\346\241\206 */\n"
"    border-radius: 5px;\n"
"}\n"
"\n"
"QLineEdit#i"
                        "nput_port:not(:focus) {\n"
"    border: 1px solid transparent;  /* \345\244\261\345\216\273\347\204\246\347\202\271\346\227\266\344\275\277\347\224\250\351\200\217\346\230\216\350\276\271\346\241\206 */\n"
"}"));
        input_prot->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        dizhi = new QLabel(centralwidget);
        dizhi->setObjectName(QString::fromUtf8("dizhi"));
        dizhi->setGeometry(QRect(50, 212, 60, 20));
        dizhi->setStyleSheet(QString::fromUtf8("font-size: 17px; /* \345\201\207\350\256\276\344\271\213\345\211\215\350\256\276\347\275\256\347\232\204\345\255\227\345\217\267\357\274\214\345\217\257\344\277\235\347\225\231\346\210\226\350\260\203\346\225\264 */\n"
"font-family: \"Microsoft YaHei\"; /* Windows \347\263\273\347\273\237\345\270\270\347\224\250\344\270\255\346\226\207\345\255\227\344\275\223 */"));
        duankou = new QLabel(centralwidget);
        duankou->setObjectName(QString::fromUtf8("duankou"));
        duankou->setGeometry(QRect(50, 262, 60, 20));
        duankou->setStyleSheet(QString::fromUtf8("font-size: 17px; /* \345\201\207\350\256\276\344\271\213\345\211\215\350\256\276\347\275\256\347\232\204\345\255\227\345\217\267\357\274\214\345\217\257\344\277\235\347\225\231\346\210\226\350\260\203\346\225\264 */\n"
"font-family: \"Microsoft YaHei\"; /* Windows \347\263\273\347\273\237\345\270\270\347\224\250\344\270\255\346\226\207\345\255\227\344\275\223 */"));
        beijing = new QLabel(centralwidget);
        beijing->setObjectName(QString::fromUtf8("beijing"));
        beijing->setGeometry(QRect(30, 190, 288, 123));
        beijing->setStyleSheet(QString::fromUtf8("\n"
"QLabel#beijing {\n"
"	background-color: rgb(247, 247, 247);\n"
"	border-radius: 12px;\n"
"\n"
"    border: 2px solid rgb(225, 225, 225); /* \346\226\260\345\242\236border\345\261\236\346\200\247 */\n"
"}"));
        pying = new QPushButton(centralwidget);
        pying->setObjectName(QString::fromUtf8("pying"));
        pying->setGeometry(QRect(127, 407, 95, 37));
        pying->setLayoutDirection(Qt::LeftToRight);
        pying->setStyleSheet(QString::fromUtf8("QPushButton {\n"
" 	background-color: rgb(7, 193, 96);\n"
"    color: white;                      /* \346\226\207\345\255\227\351\242\234\350\211\262\350\256\276\344\270\272\347\231\275\350\211\262\344\273\245\344\276\277\346\270\205\346\231\260\346\230\276\347\244\272 */\n"
"    border: none;\n"
"    min-width: 95px;\n"
"    min-height: 37px;\n"
"    max-width: 95px;\n"
"    max-height: 37px;\n"
"    border-radius: 5px;\n"
"	font-family: \"Microsoft YaHei\"; /* Windows \347\263\273\347\273\237\345\270\270\347\224\250\344\270\255\346\226\207\345\255\227\344\275\223 */\n"
"    font-size: 18px;                   /* \350\256\276\347\275\256\345\255\227\344\275\223\345\244\247\345\260\217 */\n"
"\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(6, 183, 91); /* \346\202\254\345\201\234\347\212\266\346\200\201\344\270\213\347\232\204\351\242\234\350\211\262 */\n"
"}\n"
"\n"
""));
        setwindow->setCentralWidget(centralwidget);
        beijing->raise();
        exit->raise();
        fanhui->raise();
        switchWidget->raise();
        input_ip->raise();
        input_prot->raise();
        dizhi->raise();
        duankou->raise();
        pying->raise();
        menubar = new QMenuBar(setwindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 348, 26));
        setwindow->setMenuBar(menubar);

        retranslateUi(setwindow);

        QMetaObject::connectSlotsByName(setwindow);
    } // setupUi

    void retranslateUi(QMainWindow *setwindow)
    {
        setwindow->setWindowTitle(QCoreApplication::translate("setwindow", "MainWindow", nullptr));
        exit->setText(QString());
        fanhui->setText(QString());
        switchButton->setText(QString());
        input_ip->setPlaceholderText(QString());
        input_prot->setPlaceholderText(QString());
        dizhi->setText(QCoreApplication::translate("setwindow", "\345\234\260\345\235\200\357\274\232", nullptr));
        duankou->setText(QCoreApplication::translate("setwindow", "\347\253\257\345\217\243\357\274\232", nullptr));
        beijing->setText(QString());
        pying->setText(QCoreApplication::translate("setwindow", "\344\277\235\345\255\230", nullptr));
    } // retranslateUi

};

namespace Ui {
    class setwindow: public Ui_setwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETWINDOW_H
