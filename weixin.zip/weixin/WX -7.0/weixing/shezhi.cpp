#include "shezhi.h"
#include "ui_shezhi.h"
#include <QMessageBox>
#include <QMouseEvent>
#include <QPainter>
#include "mainwindow.h"

shezhi::shezhi(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::shezhi)
{
    ui->setupUi(this);
    // 1. 删除标题栏
    setWindowFlags(Qt::FramelessWindowHint);
    // 2. 设置窗口背景透明
    setAttribute(Qt::WA_TranslucentBackground);

    // 3. 添加背景图片样式表
    ui->centralwidget->setStyleSheet(
                "  QWidget#centralwidget {"
                "  background-image: url(:/img/img/shezhi.png);"
                "  background-position: center;"
                "  background-repeat: no-repeat;"
                "  border-radius: 10px;"          // 圆角
                "  border: 1px solid rgba(0,0,0,75);" // 边框效果
                "}"
                );

    ui->y_n->hide();
    ui->yes->hide();
    ui->no->hide();

}

shezhi::~shezhi()
{
    delete ui;

}

void shezhi::updateNickname(const QString& newNickname)
{
    ui->names->setText(newNickname);
    ui->names->setFont(QFont("Microsoft YaHei", 9));
}

void shezhi::setUsername(const QString& username) {
    if (ui->ID) { // 确保标签存在
        ui->ID->setText(username);
        qDebug() << "成功设置用户名:" << username;
    } else {
        qDebug() << "错误: ID标签不存在!";
    }
}

void shezhi::updateTouxiangLabel(const QPixmap& newAvatar)
{
    // 获取标签尺寸
    QSize labelSize = ui->touxiang->size();

    // 使用遮罩创建圆角头像
    QPixmap roundedAvatar = createRoundedPixmap(newAvatar, 8); //圆角

    // 缩放图片以适配标签大小，保持宽高比
    QPixmap scaledAvatar = roundedAvatar.scaled(
                labelSize,
                Qt::KeepAspectRatio,
                Qt::SmoothTransformation
                );

    // 创建与标签相同大小的透明背景
    QPixmap result(labelSize);
    result.fill(Qt::transparent);

    // 计算居中位置
    QPoint offset(
                (labelSize.width() - scaledAvatar.width()) / 2,
                (labelSize.height() - scaledAvatar.height()) / 2
                );

    // 在透明背景上绘制缩放后的头像
    QPainter painter(&result);
    painter.drawPixmap(offset, scaledAvatar);

    // 设置到头像标签
    ui->touxiang->setPixmap(result);
    ui->touxiang->show();
}

QPixmap shezhi::createRoundedPixmap(const QPixmap& source, int radius)
{
    if (source.isNull()) return QPixmap();

    QPixmap result(source.size());
    result.fill(Qt::transparent);

    QPainter painter(&result);
    painter.setRenderHints(QPainter::Antialiasing | QPainter::SmoothPixmapTransform);

    // 创建圆角路径
    QPainterPath path;
    path.addRoundedRect(0, 0, source.width(), source.height(), radius, radius);
    painter.setClipPath(path);

    // 绘制原始图像
    painter.drawPixmap(0, 0, source);

    return result;
}
// 鼠标按下事件处理
void shezhi::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        // 记录鼠标按下时的全局位置和窗口位置
        m_dragPosition = event->globalPos() - frameGeometry().topLeft();
        event->accept();
    }
}

// 鼠标移动事件处理
void shezhi::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton) {
        // 计算窗口新位置
        move(event->globalPos() - m_dragPosition);
        event->accept();
    }
}

void shezhi::on_close_clicked()
{
    emit windowClosed();  // 发射关闭信号
    close();

}

void shezhi::on_exit_s_clicked()
{

    ui->y_n->show();
    ui->yes->show();
    ui->no->show();

}


void shezhi::on_no_clicked()
{
    ui->y_n->hide();
    ui->yes->hide();
    ui->no->hide();
}

void shezhi::on_yes_clicked()
{
    NetworkManager* netManager = NetworkManager::instance();
        disconnect(netManager, nullptr, this, nullptr);

        netManager->disconnectFromServer();
        emit requestBackToMainWindow();
        close();

}
