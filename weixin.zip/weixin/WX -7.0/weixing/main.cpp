#include "mainwindow.h"
#include <QApplication>
#include "networkmanager.h"
MainWindow *globalMainWindow = nullptr; // 全局指针
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    // 初始化网络管理器
    NetworkManager::instance();
    MainWindow w;
    w.show();
    return a.exec();
}
