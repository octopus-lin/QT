#ifndef FRIEND_YZ_H
#define FRIEND_YZ_H

#include <QMainWindow>

namespace Ui {
class friend_yz;
}

class friend_yz : public QMainWindow
{
    Q_OBJECT

public:
    explicit friend_yz(QWidget *parent, const QString& targetUsername);
    ~friend_yz();
    void setTargetUsername(const QString& username); // 添加设置目标用户名方法

signals:
    void friendRequestSent(const QString& target); // 添加好友请求信号

protected:
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
private slots:
    void on_quxiao_clicked();
    void on_queding_clicked(); // 添加确定按钮槽函数

private:
    Ui::friend_yz *ui;
    QPoint m_dragPosition;
    QString m_targetUsername; // 存储目标用户名
};

#endif // FRIEND_YZ_H
