#include "networkmanager.h"
#include <QHostInfo>
#include <QDebug>

NetworkManager* NetworkManager::m_instance = nullptr;

NetworkManager* NetworkManager::instance()
{
    if (!m_instance) {
        m_instance = new NetworkManager();
    }
    return m_instance;
}

NetworkManager::NetworkManager(QObject *parent)
    : QObject(parent),
      m_waitingForHeader(true),
      m_expectedSize(0),
      m_pendingFriendRequests()
{
    // 初始化 TCP socket
    m_tcpSocket = new QTcpSocket(this);

    // 初始化 UDP socket
    m_udpSocket = new QUdpSocket(this);

    // 连接 TCP socket 信号
    connect(m_tcpSocket, &QTcpSocket::connected, this, &NetworkManager::connected);
    connect(m_tcpSocket, &QTcpSocket::disconnected, this, &NetworkManager::disconnected);
    connect(m_tcpSocket, &QTcpSocket::readyRead, this, [this]() {
        while (m_tcpSocket->bytesAvailable()) {
            if (m_waitingForHeader) {
                if (m_tcpSocket->bytesAvailable() < 8) {
                    return; // 等待更多数据
                }

                // 读取8字节长度头
                QByteArray header = m_tcpSocket->read(8);
                bool ok;
                m_expectedSize = header.toLongLong(&ok);

                if (!ok || m_expectedSize <= 0 || m_expectedSize > 10 * 1024 * 1024) {
                    // 无效长度，重置状态
                    m_waitingForHeader = true;
                    m_expectedSize = 0;
                    m_buffer.clear();
                    emit errorOccurred("Invalid message header");
                    return;
                }

                m_waitingForHeader = false;
                m_buffer.reserve(m_expectedSize);
            }

            // 读取消息体
            qint64 bytesToRead = qMin(m_tcpSocket->bytesAvailable(),
                                      m_expectedSize - m_buffer.size());
            m_buffer.append(m_tcpSocket->read(bytesToRead));

            if (m_buffer.size() == m_expectedSize) {
                // 完整消息已接收
                processTcpMessage(m_buffer);

                // 重置状态
                m_waitingForHeader = true;
                m_expectedSize = 0;
                m_buffer.clear();
            }
        }
    });

    // 错误信号连接 (兼容 Qt5.15 以下版本)
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
    connect(m_tcpSocket, QOverload<QAbstractSocket::SocketError>::of(&QAbstractSocket::error),
            this, [this](QAbstractSocket::SocketError error) {
        Q_UNUSED(error);
        emit errorOccurred(m_tcpSocket->errorString());
    });
#else
    connect(m_tcpSocket, &QAbstractSocket::errorOccurred,
            this, [this](QAbstractSocket::SocketError error) {
        Q_UNUSED(error);
        emit errorOccurred(m_tcpSocket->errorString());
    });
#endif

    // 连接 UDP socket 信号
    connect(m_udpSocket, &QUdpSocket::readyRead, this, [this]() {
        while (m_udpSocket->hasPendingDatagrams()) {
            QByteArray datagram;
            datagram.resize(m_udpSocket->pendingDatagramSize());
            QHostAddress senderAddr;
            quint16 senderPort;

            m_udpSocket->readDatagram(datagram.data(), datagram.size(), &senderAddr, &senderPort);

            // 检查是否是视频数据
            if (datagram.startsWith("VIDEO_DATA:")) {
                int firstColon = datagram.indexOf(':');
                int secondColon = datagram.indexOf(':', firstColon + 1);
                int thirdColon = datagram.indexOf(':', secondColon + 1);

                if (firstColon != -1 && secondColon != -1 && thirdColon != -1) {
                    QString sender = datagram.mid(firstColon + 1, secondColon - firstColon - 1);
                    QString receiver = datagram.mid(secondColon + 1, thirdColon - secondColon - 1);

                    if (receiver == m_username) {
                        QByteArray frameData = datagram.mid(thirdColon + 1);
                        emit videoFrameReceived(sender, frameData);
                    }
                }
            }
        }
    });

    // 初始化心跳定时器
    m_heartbeatTimer = new QTimer(this);
    connect(m_heartbeatTimer, &QTimer::timeout, this, [this]() {
        if (m_tcpSocket->state() == QAbstractSocket::ConnectedState) {
            sendTcpMessage("HEARTBEAT");
        }
    });
    m_heartbeatTimer->start(30000); // 30秒心跳
}

NetworkManager::~NetworkManager()
{
    disconnectFromServer();
    delete m_tcpSocket;
    delete m_udpSocket;
}
void NetworkManager::disconnectFromServer()
{
    if (m_tcpSocket->state() == QAbstractSocket::ConnectedState) {
        m_tcpSocket->disconnectFromHost();
        if (m_tcpSocket->state() != QAbstractSocket::UnconnectedState) {
            m_tcpSocket->waitForDisconnected(1000);
        }
    }
    
    // 断开连接时不清空待处理好友请求，以便用户重新登录后仍能看到
    qDebug() << "NETWORKMANAGER: 断开连接，保留待处理好友请求列表";
}

bool NetworkManager::connectToServer(const QString& host, quint16 port)
{
    QSettings settings("MyCompany", "MyApp");

    QString useHost = host;
    quint16 usePort = port;

    // 检查是否有保存的自定义配置
    bool useCustom = settings.value("Server/UseCustom", false).toBool();
    if (useCustom) {
        QString savedIp = settings.value("Server/IP", "").toString();
        QString savedPort = settings.value("Server/Port", "").toString();

        if (!savedIp.isEmpty()) {
            useHost = savedIp;
        }

        if (!savedPort.isEmpty()) {
            bool ok;
            int portValue = savedPort.toInt(&ok);
            if (ok && portValue > 0 && portValue <= 65535) {
                usePort = static_cast<quint16>(portValue);
            }
        }
    }

    // 如果没有配置，使用默认值
    if (useHost.isEmpty()) {
        useHost = "192.168.46.226"; // 默认IP
    }
    if (usePort == 0) {
        usePort = 8888; // 默认端口
    }

    qDebug() << "Connecting to server:" << useHost << ":" << usePort;

    if (m_tcpSocket->state() == QAbstractSocket::ConnectedState) {
        return true;
    }

    m_tcpSocket->connectToHost(useHost, usePort);
    return m_tcpSocket->waitForConnected(3000); // 等待3秒连接
}

bool NetworkManager::isConnected() const
{
    return m_tcpSocket->state() == QAbstractSocket::ConnectedState;
}

void NetworkManager::sendTcpMessage(const QString& message)
{
    if (!isConnected()) {
        emit errorOccurred("未连接到服务器");
        return;
    }

    // 按协议格式发送消息: [8字节长度头] + 内容
    QByteArray data = message.toUtf8();
    // 确保长度头是8字节数字字符串，用前导零填充
    char sizeHeader[9];
    snprintf(sizeHeader, 9, "%08llu", static_cast<unsigned long long>(data.size()));
    m_tcpSocket->write(sizeHeader, 8);
    m_tcpSocket->write(data);
}

void NetworkManager::bindUdp(quint16 port)
{
    if (m_udpSocket->state() != QAbstractSocket::BoundState) {
        m_udpSocket->bind(QHostAddress::Any, port);
    }
}

void NetworkManager::sendVideoFrame(const QString& receiver, const QByteArray& frameData)
{
    if (m_udpSocket->state() != QAbstractSocket::BoundState) {
        emit errorOccurred("UDP socket not bound");
        return;
    }

    QString header = QString("VIDEO_DATA:%1:%2:").arg(m_username).arg(receiver);
    QByteArray datagram = header.toUtf8() + frameData;
    m_udpSocket->writeDatagram(datagram, QHostAddress("192.168.46.226"), 8890);
}

void NetworkManager::setUsername(const QString& username)
{
    qDebug() << "NETWORKMANAGER: 用户从" << m_username << "切换到" << username;
    // 在切换用户名时清空未处理的好友请求列表，确保每个用户只能看到自己的请求
    m_pendingFriendRequests.clear();
    qDebug() << "NETWORKMANAGER: 清空未处理好友请求列表";
    m_username = username;
}

QString NetworkManager::username() const
{
    return m_username;
}

void NetworkManager::processTcpMessage(const QByteArray& message)
{
    QString msgString = QString::fromUtf8(message);
    qDebug() << "收到原始消息:" << msgString; // 调试日志

    // 添加删除好友响应处理
    if (msgString.startsWith("FRIEND_DELETED_SUCCESS:")) {
        QString friendName = msgString.section(':', 1);
        emit friendDeleted(friendName);
    }
    else if (msgString.startsWith("FRIEND_DELETE_ERROR:")) {
        QString error = msgString.section(':', 1);
        emit errorOccurred("删除失败: " + error);
    }

    // 离线消息处理
    else if (msgString.startsWith("OFFLINE_MSG:")) {
        // 格式: "OFFLINE_MSG:sender:message" 或 "OFFLINE_MSG:sender:timestamp:message"
        int firstColon = msgString.indexOf(':');
        int secondColon = msgString.indexOf(':', firstColon + 1);
        int thirdColon = msgString.indexOf(':', secondColon + 1);

        if (secondColon != -1) {
            QString sender = msgString.mid(firstColon + 1, secondColon - firstColon - 1);
            QString content = msgString;

            // 确保发送者不包含消息内容
            if (sender.contains(':')) {
                sender = sender.split(':').first();
            }
            emit privateMessageReceived(sender, content);
        }
    }

    // 私聊消息处理
    else if (msgString.startsWith("PRIVATE_MSG:")) {
        // 格式: "PRIVATE_MSG:sender:timestamp:message"
        QStringList parts = msgString.mid(12).split(":");
        if (parts.size() >= 3) {
            QString sender = parts[0].trimmed();
            QString timestampStr = parts[1].trimmed();
            QString content = parts.mid(2).join(":");
            // 构建包含时间戳的完整消息，保持原始格式
            QString fullContent = QString("PRIVATE_MSG:%1:%2:%3").arg(sender).arg(timestampStr).arg(content);
            emit privateMessageReceived(sender, fullContent);
        } else if (parts.size() >= 2) {
            // 兼容旧格式的消息
            QString sender = parts[0].trimmed();
            QString content = parts.mid(1).join(":");
            emit privateMessageReceived(sender, content);
        }
    }

    // 服务器消息处理
    else if (msgString.startsWith("SERVER_MSG:")) {
        QString content = msgString.mid(11);
        emit serverMessageReceived(content);
        emit privateMessageReceived("SERVER", content); // 特殊发送者标识
    }

    // 处理请求者昵称
    else if (msgString.startsWith("REQUESTER_NICKNAME:")) {
        QStringList parts = msgString.split(':');
        if (parts.size() >= 3) {
            QString sender = parts[1];
            QString nickname = parts[2];
            emit requesterNicknameReceived(sender, nickname);
            // 这里可以更新好友请求项的显示
            qDebug() << "收到请求者账号:" << sender<<"昵称:" << nickname;
        }
    }

    // 好友列表更新
    else if (msgString.startsWith("FRIEND_LIST:")) {
        // 好友列表更新
        QStringList friends = msgString.section(':', 1).split(',');
        m_friendList = friends; // 存储好友列表
        emit friendListUpdated(friends);
    }

    // 搜索结果处理
    else if (msgString.startsWith("SEARCH_FOUND:")) {
        QString username = msgString.section(':', 1);
        emit searchResultReceived(username, true);
    }
    else if (msgString.startsWith("SEARCH_NOT_FOUND:")) {
        QString username = msgString.section(':', 1);
        emit searchResultReceived(username, false);
    }

    // 头像数据处理
    else if (msgString.startsWith("AVATAR_DATA_BASE64:")) {
        QStringList parts = msgString.split(':');
        if (parts.size() >= 4) {
            QString username = parts[1];
            qint64 size = parts[2].toLongLong();
            qDebug()<<size;
            // 修复：直接获取剩余所有部分作为Base64数据
            int base64Start = message.indexOf(':', message.indexOf(':', message.indexOf(':') + 1) + 1) + 1;
            QString base64Data = QString::fromLatin1(message.mid(base64Start));
            qDebug()<<base64Data;
            QByteArray imageData = QByteArray::fromBase64(base64Data.toLatin1());
            emit avatarDataReceived(username, imageData);
        }
    }
    else if (msgString.startsWith("AVATAR_DATA:")) {
        // 头像数据
        QString username = msgString.section(':', 1);
        qint64 size = msgString.section(':', 2).toLongLong();
        QByteArray avatarData = message.mid(msgString.indexOf(':', 2) + 1, size);
        emit avatarDataReceived(username, avatarData);
    }

    // 注册响应处理
    else if (msgString.startsWith("REGISTER_SUCCESS")) {
        emit registerSuccess();
    }
    else if (msgString.startsWith("REGISTER_FAILED")) {
        QString reason = msgString.section(':', 1);
        emit registerFailed(reason);
    }

    // 登录失效检测
    else if (msgString.startsWith("LOGIN_EXPIRED")) {
        emit loginFailed("登录已失效");
    }

    // 登录响应处理
    else if (msgString.startsWith("LOGIN_SUCCESS")) {
        // 登录成功
        QString nickname = msgString.section(':', 1); // 提取昵称部分
        emit loginSuccess(nickname); // 发送带有昵称的信号
    }
    else if (msgString.startsWith("LOGIN_FAILED")) {
        // 登录失败
        QString reason = msgString.section(':', 1);
        emit loginFailed(reason);
    }

    // 视频通话相关处理
    else if (msgString.startsWith("VIDEO_REQUEST:")) {
        // 视频通话请求
        QString caller = msgString.section(':', 1);
        quint16 udpPort = msgString.section(':', 2).toUShort();
        emit videoRequestReceived(caller, udpPort);
    }
    else if (msgString.startsWith("VIDEO_PEER:")) {
        // 视频通话对方信息
        QString peer = msgString.section(':', 1);
        QString ip = msgString.section(':', 2);
        quint16 port = msgString.section(':', 3).toUShort();
        emit videoPeerInfo(peer, ip, port);
    }
    else if (msgString.startsWith("VIDEO_REJECTED:")) {
        // 视频通话被拒绝
        QString receiver = msgString.section(':', 1);
        emit videoRejected(receiver);
    }
    else if (msgString.startsWith("VIDEO_ENDED:")) {
        // 视频通话结束
        QString peer = msgString.section(':', 1);
        emit videoEnded(peer);
    }

    // 错误消息处理
    else if (msgString.startsWith("ERROR:")) {
        // 错误消息
        emit errorOccurred(msgString.section(':', 1));
    }

    // 用户在线状态通知
    else if (msgString.startsWith("ONLINE:")) {
        // 用户上线通知
        QString username = msgString.section(':', 1);
        // 可以更新好友状态
    }
    else if (msgString.startsWith("OFFLINE:")) {
        // 用户下线通知
        QString username = msgString.section(':', 1);
        // 可以更新好友状态
    }

    // 昵称更新响应
    else if (msgString.startsWith("NICKNAME_UPDATE_SUCCESS")) {
        QString newNickname = msgString.section(':', 1);
        qDebug() << "昵称更新成功:" << newNickname;
    }
    else if (msgString.startsWith("NICKNAME_UPDATE_FAILED")) {
        QString reason = msgString.section(':', 1);
        qDebug() << "昵称更新失败:" << reason;
        emit errorOccurred(reason);
    }

    // 头像上传响应
    else if (msgString.startsWith("AVATAR_UPLOAD_SUCCESS")) {
        emit avatarUploadSuccess();
    }
    else if (msgString.startsWith("AVATAR_UPLOAD_FAILED")) {
        QString reason = msgString.section(':', 1);
        emit avatarUploadFailed(reason);
    }

    // 添加好友相关处理
    else if (msgString.startsWith("FRIEND_REQUEST:")) {
        QString sender = msgString.section(':', 1);
        qDebug() << "NETWORKMANAGER: 收到好友请求从" << sender;
        
        // 将未处理的好友请求添加到列表中，避免重复
        if (!m_pendingFriendRequests.contains(sender)) {
            m_pendingFriendRequests.append(sender);
            qDebug() << "NETWORKMANAGER: 将好友请求添加到待处理列表";
        }
        
        emit friendRequestReceived(sender);
    }
    // 发送好友请求成功
    else if (msgString.startsWith("FRIEND_REQUEST_SENT:")) {
        QString friendUsername = msgString.section(':', 1);
        emit friendRequestSent(friendUsername);
    }
    // 好友添加成功
    else if (msgString.startsWith("FRIEND_ADDED_SUCCESS:")) {
        QString friendUsername = msgString.section(':', 1);
        emit friendAdded(friendUsername);
    }
    // 好友请求被接受
    else if (msgString.startsWith("FRIEND_REQUEST_ACCEPTED:")) {
        QString friendUsername = msgString.section(':', 1);
        emit friendRequestAccepted(friendUsername);
    }
    // 好友操作错误
    else if (msgString.startsWith("FRIEND_ERROR:")) {
        QString error = msgString.section(':', 1);
        emit errorOccurred("好友操作失败: " + error);
    }

}
