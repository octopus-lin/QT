#include "myhome.h"
#include "ui_myhome.h"
#include "QCloseEvent"
#include "QPainter"
#include "QBitmap"
#include <QFileDialog>
#include <QPixmap>
#include <QIcon>
#include <QPainter>
#include <QMessageBox>
#include <QDialogButtonBox>
#include <QGraphicsView>
#include <QGraphicsRectItem>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QInputDialog>
#include <QBuffer>
#include "caijian.h"
#include "networkmanager.h"
#include <QDebug>
#include <home.h>


myhome::myhome(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::myhome)
{
    ui->setupUi(this);

    // 添加无边框和透明属性
    setWindowFlags(Qt::FramelessWindowHint | Qt::Popup);

    //  添加背景图片样式表
    ui->centralwidget->setObjectName("homeWidget"); // 添加这行
    ui->centralwidget->setStyleSheet(
                "QWidget#homeWidget {"
                "  background-image: url(:/img/img/myhome.png);"
                "  background-position: center;"
                "  background-repeat: no-repeat;"
                "  border-radius: 10px;"          // 圆角
                "  border: 1px solid rgba(0,0,0,40);" // 边框效果
                "}"
                );
    NetworkManager* netManager = NetworkManager::instance();
    connect(netManager, &NetworkManager::avatarDataReceived,
            this, &myhome::handleAvatarDataReceived);
}


myhome::~myhome()
{
    delete ui;
}

void myhome::handleAvatarDataReceived(const QString& username, const QByteArray& avatarData)
{

    if (username != ui->ID->text()) return; // 确保是当前用户

    QPixmap pixmap;

    if (!pixmap.loadFromData(avatarData)) {
            qDebug() << "加载头像失败，原因是:" << username;
            return;
        }
    if (pixmap.loadFromData(avatarData)) {
        // 更新按钮图标
        QSize buttonSize = ui->touxiang->size();
        QPixmap scaled = pixmap.scaled(buttonSize, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
        QPixmap rounded = createRoundedPixmap(scaled, 8);

        ui->touxiang->setIcon(QIcon(rounded));
        ui->touxiang->setIconSize(buttonSize);

        // 通知主界面更新头像
        emit avatarChangedForLabel(rounded);
    } else {
        qDebug() << "未能加载用户的头像图片:" << username;
    }
}

QString myhome::getCurrentNickname() const {
    return ui->names->text(); // 返回当前显示的昵称
}

void myhome::setUsername(const QString& username) {
    if (ui->ID) { // 确保标签存在
        ui->ID->setText(username);
        qDebug() << "成功设置用户名:" << username;
    } else {
        qDebug() << "错误: ID标签不存在!";
    }
}

void myhome::setNickname(const QString& nickname)
{
    if (ui->names) {
        ui->names->setText(nickname);
        qDebug() << "成功设置昵称:" << nickname;
    }
}


void myhome::on_touxiang_clicked() {
    QString filePath = QFileDialog::getOpenFileName(
                this,
                tr("选择头像图片"),
                "",
                tr("图像文件 (*.png *.jpg *.jpeg *.bmp *.gif);;所有文件 (*)")
                );

    if (!filePath.isEmpty()) {
        QPixmap originalPixmap(filePath);
        if (originalPixmap.isNull()) {
            QMessageBox::warning(this, tr("错误"), tr("无法加载图片"));
            return;
        }

        // 显示裁剪对话框
        CropDialog dialog(originalPixmap, this);
        if (dialog.exec() == QDialog::Accepted) {
            QPixmap cropped = dialog.croppedPixmap();

            // 1. 直接缩放到按钮大小
            QSize buttonSize = ui->touxiang->size();
            QPixmap scaled = cropped.scaled(
                        buttonSize,
                        Qt::IgnoreAspectRatio,  // 强制填满
                        Qt::SmoothTransformation
                        );

            // 2. 应用圆角遮罩 (半径8px)
            QPixmap rounded = createRoundedPixmap(scaled, 8);

            // 3. 设置为按钮图标
            ui->touxiang->setIcon(QIcon(rounded));
            ui->touxiang->setIconSize(buttonSize); // 关键：设置图标大小
            // 发射信号
            emit avatarChangedForLabel(rounded);

            // +++ 新增：上传头像到服务器 +++
            // 将头像转换为Base64
            QByteArray byteArray;
            QBuffer buffer(&byteArray);
            buffer.open(QIODevice::WriteOnly);

            // 压缩图片（质量90%），确保小于1MB
            int quality = 90;
            do {
                byteArray.clear();
                buffer.open(QIODevice::WriteOnly);
                rounded.save(&buffer, "JPG", quality);
                buffer.close();
                quality -= 10;
            } while (byteArray.size() > 1024 * 1024 && quality > 0); // 1MB限制

            if (byteArray.size() > 1024 * 1024) {
                QMessageBox::warning(this, tr("头像过大"), tr("头像大小超过1MB限制，请选择较小的图片"));
                return;
            }

            QString base64Avatar = QString::fromLatin1(byteArray.toBase64().data());

            // 构造上传指令
            QString command = "UPLOAD_AVATAR:" + base64Avatar;

            // 通过NetworkManager发送
            NetworkManager* netManager = NetworkManager::instance();
            if (netManager->isConnected()) {
                // 在发送前断开所有之前的连接
                disconnect(netManager, &NetworkManager::avatarUploadSuccess, this, nullptr);
                disconnect(netManager, &NetworkManager::avatarUploadFailed, this, nullptr);

                // 使用lambda捕获信号发送后的连接状态
                QMetaObject::Connection* uploadSuccessConnection = new QMetaObject::Connection;
                QMetaObject::Connection* uploadFailedConnection = new QMetaObject::Connection;

                // 连接上传结果信号
                *uploadSuccessConnection = connect(netManager, &NetworkManager::avatarUploadSuccess, this, [this, uploadSuccessConnection, uploadFailedConnection]() {
                    QMessageBox::information(this, tr("上传成功"), tr("头像上传成功！"));
                    // 断开连接并清理
                    disconnect(*uploadSuccessConnection);
                    disconnect(*uploadFailedConnection);
                    delete uploadSuccessConnection;
                    delete uploadFailedConnection;
                });

                *uploadFailedConnection = connect(netManager, &NetworkManager::avatarUploadFailed, this, [this, uploadSuccessConnection, uploadFailedConnection](const QString& reason) {
                    QMessageBox::warning(this, tr("上传失败"), tr("头像上传失败: %1").arg(reason));
                    // 断开连接并清理
                    disconnect(*uploadSuccessConnection);
                    disconnect(*uploadFailedConnection);
                    delete uploadSuccessConnection;
                    delete uploadFailedConnection;
                });

                netManager->sendTcpMessage(command);
            } else {
                QMessageBox::warning(this, tr("网络错误"), tr("未连接到服务器，头像上传失败"));
            }
        }
    }
}

void myhome::closeEvent(QCloseEvent *event)
{
    hide();  // 隐藏而不是关闭
    event->ignore();  // 忽略关闭事件
}

// 添加resizeEvent处理函数
void myhome::resizeEvent(QResizeEvent *event)
{
    QMainWindow::resizeEvent(event);
    updateMask(); // 窗口大小变化时更新遮罩
}

// 添加showEvent处理函数
void myhome::showEvent(QShowEvent *event)
{
    QMainWindow::showEvent(event);
    updateMask(); // 窗口显示时更新遮罩
}

// 创建遮罩函数
void myhome::updateMask()
{
    QPixmap pixmap(size());
    pixmap.fill(Qt::transparent);

    QPainter painter(&pixmap);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.setBrush(Qt::black);
    painter.setPen(Qt::NoPen);

    // 使用与头像相同的圆角半径
    painter.drawRoundedRect(rect(), 5, 5);

    setMask(pixmap.mask());
}


// 生成圆角图片的辅助函数
QPixmap myhome::createRoundedPixmap(const QPixmap& source, int radius)
{
    if (source.isNull()) return QPixmap();

    QPixmap result(source.size());
    result.fill(Qt::transparent);  // 确保背景透明

    QPainter painter(&result);
    painter.setRenderHints(QPainter::Antialiasing | QPainter::SmoothPixmapTransform);

    // 创建圆角路径
    QPainterPath path;
    path.addRoundedRect(0, 0, source.width(), source.height(), radius, radius);
    painter.setClipPath(path);

    // 绘制原始图像
    painter.drawPixmap(0, 0, source);

    return result;
}



void myhome::on_names_but_clicked()
{
    // 获取当前昵称
    QString currentName = ui->names->text();

    // 创建输入对话框对象
    QInputDialog dialog(this);
    dialog.setWindowTitle(tr("修改昵称"));
    dialog.setLabelText(tr("请输入新昵称（最多10个汉字）:"));
    dialog.setTextValue(currentName);

    // 设置输入框属性
    QLineEdit *lineEdit = dialog.findChild<QLineEdit*>();
    if (lineEdit) {
        lineEdit->setMaxLength(10); // 最大长度10个字符

        // 确保使用支持中文的字体
        lineEdit->setFont(QFont("Microsoft YaHei", 10));
    }

    // 显示对话框并处理结果
    if (dialog.exec() == QDialog::Accepted) {
        QString newName = dialog.textValue();
        if (!newName.isEmpty()) {
            ui->names->setText(newName);

            ui->names->setFont(QFont("Microsoft YaHei", 9));
            emit nicknameChanged(newName); // 发射信号

            // 新增：发送昵称更新请求到服务器
            NetworkManager* netManager = NetworkManager::instance();
            if (netManager->isConnected()) {
                // 发送更新昵称的请求，格式为："UPDATE_NICKNAME:新昵称"
                QString message = "UPDATE_NICKNAME:" + newName;
                netManager->sendTcpMessage(message);
            } else {
                QMessageBox::warning(this, "网络错误", "未连接到服务器，昵称修改无法同步");
            }

        }
    }
}

