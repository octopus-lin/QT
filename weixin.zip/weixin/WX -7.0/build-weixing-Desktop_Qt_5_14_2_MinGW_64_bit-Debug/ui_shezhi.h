/********************************************************************************
** Form generated from reading UI file 'shezhi.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHEZHI_H
#define UI_SHEZHI_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_shezhi
{
public:
    QWidget *centralwidget;
    QPushButton *close;
    QPushButton *exit_s;
    QLabel *touxiang;
    QLabel *y_n;
    QPushButton *no;
    QPushButton *yes;
    QLabel *names;
    QLabel *ID;
    QMenuBar *menubar;

    void setupUi(QMainWindow *shezhi)
    {
        if (shezhi->objectName().isEmpty())
            shezhi->setObjectName(QString::fromUtf8("shezhi"));
        shezhi->resize(686, 848);
        centralwidget = new QWidget(shezhi);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        close = new QPushButton(centralwidget);
        close->setObjectName(QString::fromUtf8("close"));
        close->setGeometry(QRect(629, 0, 57, 39));
        close->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 57px;\n"
"    min-height: 39px;\n"
"    max-width: 57px;\n"
"    max-height: 39px;\n"
"    border-top-right-radius: 10px; /* \345\217\263\344\270\212\350\247\222\345\234\206\350\247\22210px */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/red-x2.png\"); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\266\346\230\276\347\244\272\346\214\207\345\256\232\345\233\276\347\211\207 */\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-top-right-radius: 10px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\234\206\350\247\222 */\n"
"}"));
        exit_s = new QPushButton(centralwidget);
        exit_s->setObjectName(QString::fromUtf8("exit_s"));
        exit_s->setGeometry(QRect(533, 89, 90, 30));
        exit_s->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 90px;\n"
"    min-height: 30px;\n"
"    max-width: 90px;\n"
"    max-height: 30px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.04); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        touxiang = new QLabel(centralwidget);
        touxiang->setObjectName(QString::fromUtf8("touxiang"));
        touxiang->setGeometry(QRect(262, 81, 47, 47));
        touxiang->setStyleSheet(QString::fromUtf8("background-color: rgb(144, 228, 101);\n"
"border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"min-width: 47px;\n"
"min-height: 47px;\n"
"max-width: 47px;\n"
"max-height: 47px;\n"
"border-radius: 7px;\n"
"\n"
""));
        y_n = new QLabel(centralwidget);
        y_n->setObjectName(QString::fromUtf8("y_n"));
        y_n->setGeometry(QRect(165, 345, 352, 202));
        y_n->setStyleSheet(QString::fromUtf8("background-image: url(\":/img/img/y-n.png\"); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\266\346\230\276\347\244\272\346\214\207\345\256\232\345\233\276\347\211\207 */\n"
"background-repeat: no-repeat;\n"
"background-position: center;\n"
"border-top-right-radius: 10px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\234\206\350\247\222 */"));
        no = new QPushButton(centralwidget);
        no->setObjectName(QString::fromUtf8("no"));
        no->setGeometry(QRect(346, 470, 140, 35));
        no->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.04); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        yes = new QPushButton(centralwidget);
        yes->setObjectName(QString::fromUtf8("yes"));
        yes->setGeometry(QRect(196, 470, 140, 37));
        yes->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.04); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        names = new QLabel(centralwidget);
        names->setObjectName(QString::fromUtf8("names"));
        names->setGeometry(QRect(318, 80, 180, 30));
        names->setStyleSheet(QString::fromUtf8("background-color: rgb(245, 245, 245); \n"
"border: none;\n"
"font-size: 18px; /* \345\201\207\350\256\276\344\271\213\345\211\215\350\256\276\347\275\256\347\232\204\345\255\227\345\217\267\357\274\214\345\217\257\344\277\235\347\225\231\346\210\226\350\260\203\346\225\264 */\n"
"font-family: \"Microsoft YaHei\"; /* Windows \347\263\273\347\273\237\345\270\270\347\224\250\344\270\255\346\226\207\345\255\227\344\275\223 */"));
        names->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        ID = new QLabel(centralwidget);
        ID->setObjectName(QString::fromUtf8("ID"));
        ID->setGeometry(QRect(318, 110, 151, 20));
        ID->setStyleSheet(QString::fromUtf8("\n"
"font-family: \"Microsoft YaHei\";\n"
"color: rgb(158, 158, 158);    /* \345\255\227\344\275\223\344\270\272\346\265\205\347\201\260\350\211\262 */\n"
"border: none;                 /* \346\227\240\350\276\271\346\241\206 */\n"
"background-color: rgb(246, 246, 246);"));
        shezhi->setCentralWidget(centralwidget);
        menubar = new QMenuBar(shezhi);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 686, 26));
        shezhi->setMenuBar(menubar);

        retranslateUi(shezhi);

        QMetaObject::connectSlotsByName(shezhi);
    } // setupUi

    void retranslateUi(QMainWindow *shezhi)
    {
        shezhi->setWindowTitle(QCoreApplication::translate("shezhi", "MainWindow", nullptr));
        close->setText(QString());
        exit_s->setText(QString());
        touxiang->setText(QString());
        y_n->setText(QString());
        no->setText(QString());
        yes->setText(QString());
        names->setText(QCoreApplication::translate("shezhi", "\346\207\222\346\264\213\346\264\213", nullptr));
        ID->setText(QCoreApplication::translate("shezhi", "12345600000", nullptr));
    } // retranslateUi

};

namespace Ui {
    class shezhi: public Ui_shezhi {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHEZHI_H
