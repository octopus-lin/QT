/********************************************************************************
** Form generated from reading UI file 'gerengxx.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GERENGXX_H
#define UI_GERENGXX_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_gerengxx
{
public:
    QWidget *centralwidget;
    QLabel *ID;
    QLabel *names;
    QLabel *diqu;
    QLabel *nicheng;
    QLabel *beizhu;
    QLabel *touxiang;
    QMenuBar *menubar;

    void setupUi(QMainWindow *gerengxx)
    {
        if (gerengxx->objectName().isEmpty())
            gerengxx->setObjectName(QString::fromUtf8("gerengxx"));
        gerengxx->resize(349, 543);
        gerengxx->setStyleSheet(QString::fromUtf8("/*background-image: url(:/img/img/gerengxx.png);*/"));
        centralwidget = new QWidget(gerengxx);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        ID = new QLabel(centralwidget);
        ID->setObjectName(QString::fromUtf8("ID"));
        ID->setGeometry(QRect(180, 82, 151, 20));
        ID->setStyleSheet(QString::fromUtf8("background-color: white;      /* \350\203\214\346\231\257\344\270\272\347\231\275\350\211\262 */\n"
"font-family: \"Microsoft YaHei\";\n"
"color: rgb(158, 158, 158);    /* \345\255\227\344\275\223\344\270\272\346\265\205\347\201\260\350\211\262 */\n"
"border: none;                 /* \346\227\240\350\276\271\346\241\206 */\n"
""));
        names = new QLabel(centralwidget);
        names->setObjectName(QString::fromUtf8("names"));
        names->setGeometry(QRect(125, 27, 151, 30));
        names->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255); \n"
"border: none;\n"
"font-size: 18px; /* \345\201\207\350\256\276\344\271\213\345\211\215\350\256\276\347\275\256\347\232\204\345\255\227\345\217\267\357\274\214\345\217\257\344\277\235\347\225\231\346\210\226\350\260\203\346\225\264 */\n"
"font-family: \"Microsoft YaHei\"; /* Windows \347\263\273\347\273\237\345\270\270\347\224\250\344\270\255\346\226\207\345\255\227\344\275\223 */"));
        names->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        diqu = new QLabel(centralwidget);
        diqu->setObjectName(QString::fromUtf8("diqu"));
        diqu->setGeometry(QRect(170, 100, 151, 20));
        diqu->setStyleSheet(QString::fromUtf8("background-color: white;      /* \350\203\214\346\231\257\344\270\272\347\231\275\350\211\262 */\n"
"font-family: \"Microsoft YaHei\";\n"
"color: rgb(158, 158, 158);    /* \345\255\227\344\275\223\344\270\272\346\265\205\347\201\260\350\211\262 */\n"
"border: none;                 /* \346\227\240\350\276\271\346\241\206 */\n"
""));
        nicheng = new QLabel(centralwidget);
        nicheng->setObjectName(QString::fromUtf8("nicheng"));
        nicheng->setGeometry(QRect(170, 62, 151, 20));
        nicheng->setStyleSheet(QString::fromUtf8("background-color: white;      /* \350\203\214\346\231\257\344\270\272\347\231\275\350\211\262 */\n"
"font-family: \"Microsoft YaHei\";\n"
"color: rgb(158, 158, 158);    /* \345\255\227\344\275\223\344\270\272\346\265\205\347\201\260\350\211\262 */\n"
"border: none;                 /* \346\227\240\350\276\271\346\241\206 */\n"
""));
        beizhu = new QLabel(centralwidget);
        beizhu->setObjectName(QString::fromUtf8("beizhu"));
        beizhu->setGeometry(QRect(118, 162, 151, 30));
        beizhu->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255); \n"
"border: none;\n"
"font-size: 18px; /* \345\201\207\350\256\276\344\271\213\345\211\215\350\256\276\347\275\256\347\232\204\345\255\227\345\217\267\357\274\214\345\217\257\344\277\235\347\225\231\346\210\226\350\260\203\346\225\264 */\n"
"font-family: \"Microsoft YaHei\"; /* Windows \347\263\273\347\273\237\345\270\270\347\224\250\344\270\255\346\226\207\345\255\227\344\275\223 */"));
        beizhu->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        touxiang = new QLabel(centralwidget);
        touxiang->setObjectName(QString::fromUtf8("touxiang"));
        touxiang->setGeometry(QRect(28, 30, 78, 78));
        touxiang->setStyleSheet(QString::fromUtf8("min-width: 78px;\n"
"min-height: 78px;\n"
"max-width: 78px;\n"
"max-height: 78px;\n"
"border-radius: 8px;\n"
"background-color: rgb(255, 255, 127);\n"
""));
        gerengxx->setCentralWidget(centralwidget);
        menubar = new QMenuBar(gerengxx);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 349, 26));
        gerengxx->setMenuBar(menubar);

        retranslateUi(gerengxx);

        QMetaObject::connectSlotsByName(gerengxx);
    } // setupUi

    void retranslateUi(QMainWindow *gerengxx)
    {
        gerengxx->setWindowTitle(QCoreApplication::translate("gerengxx", "MainWindow", nullptr));
        ID->setText(QCoreApplication::translate("gerengxx", "12345600000", nullptr));
        names->setText(QCoreApplication::translate("gerengxx", "\345\244\207\346\263\250", nullptr));
        diqu->setText(QCoreApplication::translate("gerengxx", "\345\271\277\344\270\234 \345\271\277\345\267\236", nullptr));
        nicheng->setText(QCoreApplication::translate("gerengxx", "\345\226\234\345\226\234", nullptr));
        beizhu->setText(QCoreApplication::translate("gerengxx", "\345\244\207\346\263\250", nullptr));
        touxiang->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class gerengxx: public Ui_gerengxx {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GERENGXX_H
