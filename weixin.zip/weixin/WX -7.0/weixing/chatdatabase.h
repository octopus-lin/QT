#ifndef CHATDATABASE_H
#define CHATDATABASE_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QStandardPaths>
#include <QDir>

class ChatDatabase : public QObject
{
    Q_OBJECT
public:
    explicit ChatDatabase(QObject *parent = nullptr);
    ~ChatDatabase();
    bool saveAvatar(const QString& username, const QByteArray& avatarData);
    QByteArray loadAvatar(const QString& username);
    QPixmap getAvatarPixmap(const QString& username);

    bool initDatabase(const QString& username);
    bool saveMessage(const QString& sender, const QString& receiver,
                    const QString& message, qint64 timestamp);
    QList<QPair<QString, QString>> loadMessages(const QString& peer);
    QList<QPair<QString, QPair<QString, qint64>>> loadMessagesPaged(const QString& peer, int limit, int offset);
    bool deleteMessagesWithPeer(const QString& peer);

private:
    QSqlDatabase m_db;
    QString m_currentUser;
};

#endif // CHATDATABASE_H
