#ifndef ADD_FRIEND_H
#define ADD_FRIEND_H

#include <QMainWindow>
#include <QMessageBox>
#include "networkmanager.h"  // 包含网络管理器
#include "friend_yz.h"

namespace Ui {
class add_friend;
}

class add_friend : public QMainWindow
{
    Q_OBJECT

public:
    explicit add_friend(QWidget *parent = nullptr);
    ~add_friend();

protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);

private slots:
    void on_close_f_clicked();
    void handleSearchResult(const QString& username, bool found);  // 处理搜索结果
    void on_lookf_clicked();

    void on_add_f_clicked();

private:
    Ui::add_friend *ui;
    QPoint m_dragPosition;
    friend_yz * fryzwindow = nullptr;
};

#endif // ADD_FRIEND_H
