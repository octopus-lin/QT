// chatdatabase.cpp
#include "chatdatabase.h"

#include <QDateTime>
#include <QPixmap>

ChatDatabase::ChatDatabase(QObject *parent) : QObject(parent)
{}

ChatDatabase::~ChatDatabase()
{
    if (m_db.isOpen()) {
        m_db.close();
    }
}


// 新增头像保存方法
bool ChatDatabase::saveAvatar(const QString& username, const QByteArray& avatarData)
{
    QSqlQuery query(m_db);
    query.prepare(
        "INSERT OR REPLACE INTO avatars (username, avatar_data, last_updated) "
        "VALUES (:username, :avatar_data, :timestamp)"
    );

    query.bindValue(":username", username);
    query.bindValue(":avatar_data", avatarData);
    query.bindValue(":timestamp", QDateTime::currentSecsSinceEpoch());

    return query.exec();
}

// 新增头像加载方法
QByteArray ChatDatabase::loadAvatar(const QString& username)
{
    QSqlQuery query(m_db);
    query.prepare("SELECT avatar_data FROM avatars WHERE username = :username");
    query.bindValue(":username", username);

    if (query.exec() && query.next()) {
        return query.value(0).toByteArray();
    }
    return QByteArray();
}

// 获取头像QPixmap
QPixmap ChatDatabase::getAvatarPixmap(const QString& username)
{
    QByteArray data = loadAvatar(username);
    QPixmap pixmap;
    pixmap.loadFromData(data);
    return pixmap.isNull() ? QPixmap(":/img/img/default_avatar.png") : pixmap;
}


bool ChatDatabase::initDatabase(const QString& username)
{
    m_currentUser = username;

    // 获取应用数据目录
    QString dataPath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir dir(dataPath);
    if (!dir.exists()) {
        dir.mkpath(dataPath);
    }

    QString dbPath = dataPath + "/" + username + "_chat.db";

    m_db = QSqlDatabase::addDatabase("QSQLITE", username);
    m_db.setDatabaseName(dbPath);

    if (!m_db.open()) {
        qWarning() << "无法打开数据库:" << m_db.lastError().text();
        return false;
    }

    // 创建消息表
    QSqlQuery query(m_db);
    query.prepare(
        "CREATE TABLE IF NOT EXISTS messages ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "sender TEXT NOT NULL,"
        "receiver TEXT NOT NULL,"
        "message TEXT NOT NULL,"
        "timestamp INTEGER NOT NULL)"
    );

    if (!query.exec()) {
        qWarning() << "创建消息表失败:" << query.lastError().text();
        return false;
    }

    // 创建头像表
    query.prepare(
        "CREATE TABLE IF NOT EXISTS avatars ("
        "username TEXT PRIMARY KEY,"
        "avatar_data BLOB NOT NULL,"
        "last_updated INTEGER NOT NULL)"
    );

    if (!query.exec()) {
        qWarning() << "创建头像表失败:" << query.lastError().text();
        return false;
    }

    // 创建索引提高查询性能
    query.prepare("CREATE INDEX IF NOT EXISTS idx_peer ON messages (sender, receiver)");
    query.exec();

    return true;
}

bool ChatDatabase::saveMessage(const QString& sender, const QString& receiver,
                              const QString& message, qint64 timestamp)
{
    QSqlQuery query(m_db);
    query.prepare(
        "INSERT INTO messages (sender, receiver, message, timestamp) "
        "VALUES (:sender, :receiver, :message, :timestamp)"
    );

    query.bindValue(":sender", sender);
    query.bindValue(":receiver", receiver);
    query.bindValue(":message", message);
    query.bindValue(":timestamp", timestamp);

    if (!query.exec()) {
        qWarning() << "保存消息失败:" << query.lastError().text();
        return false;
    }

    return true;
}

QList<QPair<QString, QString>> ChatDatabase::loadMessages(const QString& peer)
{
    QList<QPair<QString, QString>> messages;

    if (!m_db.isOpen()) {
        qWarning() << "数据库未打开";
        return messages;
    }

    QSqlQuery query(m_db);
    query.prepare(
        "SELECT sender, message FROM messages "
        "WHERE (sender = :currentUser AND receiver = :peer) OR "
        "(sender = :peer AND receiver = :currentUser) "
        "ORDER BY timestamp ASC"
    );

    query.bindValue(":currentUser", m_currentUser);
    query.bindValue(":peer", peer);

    if (!query.exec()) {
        qWarning() << "加载消息失败:" << query.lastError().text();
        return messages;
    }

    qDebug() << "加载与" << peer << "的聊天记录，找到" << query.size() << "条消息";

    while (query.next()) {
        QString sender = query.value(0).toString();
        QString message = query.value(1).toString();
        messages.append(qMakePair(sender, message));
    }

    return messages;
}

// 添加分页查询实现
QList<QPair<QString, QPair<QString, qint64>>> ChatDatabase::loadMessagesPaged(const QString& peer, int limit, int offset)
{
    QList<QPair<QString, QPair<QString, qint64>>> messages;

    if (!m_db.isOpen()) {
        qWarning() << "数据库未打开";
        return messages;
    }

    QSqlQuery query(m_db);
    query.prepare(
            "SELECT sender, message, timestamp FROM messages "
            "WHERE (sender = :currentUser AND receiver = :peer) OR "
            "(sender = :peer AND receiver = :currentUser) "
            "ORDER BY timestamp DESC "  // 改为倒序排列
            "LIMIT :limit OFFSET :offset"
        );

    query.bindValue(":currentUser", m_currentUser);
    query.bindValue(":peer", peer);
    query.bindValue(":limit", limit);
    query.bindValue(":offset", offset);

    if (!query.exec()) {
        qWarning() << "分页加载消息失败:" << query.lastError().text();
        return messages;
    }

    while (query.next()) {
        QString sender = query.value(0).toString();
        QString message = query.value(1).toString();
        qint64 timestamp = query.value(2).toLongLong();
        messages.append(qMakePair(sender, qMakePair(message, timestamp)));
    }

    // 反转列表，使消息按时间正序排列（旧消息在前）
    std::reverse(messages.begin(), messages.end());
    return messages;
}

// 添加删除与特定好友聊天记录的函数
bool ChatDatabase::deleteMessagesWithPeer(const QString& peer)
{
    if (!m_db.isOpen()) {
        qWarning() << "数据库未打开";
        return false;
    }

    QSqlQuery query(m_db);
    query.prepare(
        "DELETE FROM messages "
        "WHERE (sender = :currentUser AND receiver = :peer) OR "
        "(sender = :peer AND receiver = :currentUser)"
    );

    query.bindValue(":currentUser", m_currentUser);
    query.bindValue(":peer", peer);

    if (!query.exec()) {
        qWarning() << "删除与" << peer << "的聊天记录失败:" << query.lastError().text();
        return false;
    }

    qDebug() << "成功删除与" << peer << "的" << query.numRowsAffected() << "条聊天记录";
    return true;
}
