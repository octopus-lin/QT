#ifndef MYHOME_H
#define MYHOME_H

#include <QMainWindow>

namespace Ui {
class myhome;
}

class myhome : public QMainWindow
{
    Q_OBJECT

public:
    explicit myhome(QWidget *parent = nullptr);
    ~myhome();
    void setUsername(const QString& username);  // 添加这个方法
    QString getCurrentNickname() const;
    void setNickname(const QString& nickname); // 添加设置昵称方法
    void handleAvatarDataReceived(const QString &username, const QByteArray &avatarData);

signals:  // 添加信号
    void avatarChanged(const QPixmap& newAvatar);  // 确保这个信号已存在
    void avatarChangedForLabel(const QPixmap& newAvatar);  // 添加这个新信号
    void cropRequested(const QPixmap& image); // 新增信号
    void nicknameChanged(const QString& newNickname); // 新增信号


protected:
    // 添加关闭事件处理
    void closeEvent(QCloseEvent *event) override;
    // 添加大小变化事件
    void resizeEvent(QResizeEvent *event) override;
    // 添加显示事件
    void showEvent(QShowEvent *event) override;



private slots:
    void on_touxiang_clicked();

    void on_names_but_clicked();

private:
    Ui::myhome *ui;
    void updateMask();
    QPixmap createRoundedPixmap(const QPixmap& source, int radius);
};

#endif // MYHOME_H
