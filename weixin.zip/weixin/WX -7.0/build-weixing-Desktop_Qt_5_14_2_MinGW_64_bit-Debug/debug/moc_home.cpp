/****************************************************************************
** Meta object code from reading C++ file 'home.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../weixing/home.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'home.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ClickableLabel_t {
    QByteArrayData data[3];
    char stringdata0[24];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ClickableLabel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ClickableLabel_t qt_meta_stringdata_ClickableLabel = {
    {
QT_MOC_LITERAL(0, 0, 14), // "ClickableLabel"
QT_MOC_LITERAL(1, 15, 7), // "clicked"
QT_MOC_LITERAL(2, 23, 0) // ""

    },
    "ClickableLabel\0clicked\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ClickableLabel[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void,

       0        // eod
};

void ClickableLabel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ClickableLabel *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (ClickableLabel::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ClickableLabel::clicked)) {
                *result = 0;
                return;
            }
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject ClickableLabel::staticMetaObject = { {
    QMetaObject::SuperData::link<QLabel::staticMetaObject>(),
    qt_meta_stringdata_ClickableLabel.data,
    qt_meta_data_ClickableLabel,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *ClickableLabel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ClickableLabel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ClickableLabel.stringdata0))
        return static_cast<void*>(this);
    return QLabel::qt_metacast(_clname);
}

int ClickableLabel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QLabel::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void ClickableLabel::clicked()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
struct qt_meta_stringdata_FriendListDelegate_t {
    QByteArrayData data[1];
    char stringdata0[19];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_FriendListDelegate_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_FriendListDelegate_t qt_meta_stringdata_FriendListDelegate = {
    {
QT_MOC_LITERAL(0, 0, 18) // "FriendListDelegate"

    },
    "FriendListDelegate"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FriendListDelegate[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void FriendListDelegate::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject FriendListDelegate::staticMetaObject = { {
    QMetaObject::SuperData::link<QStyledItemDelegate::staticMetaObject>(),
    qt_meta_stringdata_FriendListDelegate.data,
    qt_meta_data_FriendListDelegate,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *FriendListDelegate::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FriendListDelegate::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_FriendListDelegate.stringdata0))
        return static_cast<void*>(this);
    return QStyledItemDelegate::qt_metacast(_clname);
}

int FriendListDelegate::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QStyledItemDelegate::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_ScreenshotSelector_t {
    QByteArrayData data[5];
    char stringdata0[70];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ScreenshotSelector_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ScreenshotSelector_t qt_meta_stringdata_ScreenshotSelector = {
    {
QT_MOC_LITERAL(0, 0, 18), // "ScreenshotSelector"
QT_MOC_LITERAL(1, 19, 18), // "screenshotSelected"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 10), // "screenshot"
QT_MOC_LITERAL(4, 50, 19) // "screenshotCancelled"

    },
    "ScreenshotSelector\0screenshotSelected\0"
    "\0screenshot\0screenshotCancelled"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ScreenshotSelector[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   24,    2, 0x06 /* Public */,
       4,    0,   27,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QPixmap,    3,
    QMetaType::Void,

       0        // eod
};

void ScreenshotSelector::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ScreenshotSelector *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->screenshotSelected((*reinterpret_cast< const QPixmap(*)>(_a[1]))); break;
        case 1: _t->screenshotCancelled(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (ScreenshotSelector::*)(const QPixmap & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ScreenshotSelector::screenshotSelected)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (ScreenshotSelector::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ScreenshotSelector::screenshotCancelled)) {
                *result = 1;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject ScreenshotSelector::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_ScreenshotSelector.data,
    qt_meta_data_ScreenshotSelector,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *ScreenshotSelector::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ScreenshotSelector::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ScreenshotSelector.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int ScreenshotSelector::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void ScreenshotSelector::screenshotSelected(const QPixmap & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ScreenshotSelector::screenshotCancelled()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
struct qt_meta_stringdata_home_t {
    QByteArrayData data[43];
    char stringdata0[722];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_home_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_home_t qt_meta_stringdata_home = {
    {
QT_MOC_LITERAL(0, 0, 4), // "home"
QT_MOC_LITERAL(1, 5, 21), // "requestResetToQrLogin"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 13), // "avatarChanged"
QT_MOC_LITERAL(4, 42, 9), // "newAvatar"
QT_MOC_LITERAL(5, 52, 14), // "showFriendInfo"
QT_MOC_LITERAL(6, 67, 8), // "username"
QT_MOC_LITERAL(7, 76, 16), // "on_close_clicked"
QT_MOC_LITERAL(8, 93, 15), // "on_send_clicked"
QT_MOC_LITERAL(9, 109, 21), // "on_inputs_textChanged"
QT_MOC_LITERAL(10, 131, 16), // "on_mybut_clicked"
QT_MOC_LITERAL(11, 148, 18), // "on_kuaijie_clicked"
QT_MOC_LITERAL(12, 167, 15), // "on_more_clicked"
QT_MOC_LITERAL(13, 183, 19), // "updateTouxiangLabel"
QT_MOC_LITERAL(14, 203, 20), // "updateMyButtonAvatar"
QT_MOC_LITERAL(15, 224, 13), // "on_k2_clicked"
QT_MOC_LITERAL(16, 238, 18), // "on_suoxiao_clicked"
QT_MOC_LITERAL(17, 257, 17), // "on_fangda_clicked"
QT_MOC_LITERAL(18, 275, 13), // "on_b6_clicked"
QT_MOC_LITERAL(19, 289, 22), // "handleBackToMainWindow"
QT_MOC_LITERAL(20, 312, 21), // "on_shiping_dh_clicked"
QT_MOC_LITERAL(21, 334, 18), // "on_dianhua_clicked"
QT_MOC_LITERAL(22, 353, 15), // "on_wxlt_clicked"
QT_MOC_LITERAL(23, 369, 18), // "on_tongxun_clicked"
QT_MOC_LITERAL(24, 388, 19), // "handleFriendRequest"
QT_MOC_LITERAL(25, 408, 6), // "sender"
QT_MOC_LITERAL(26, 415, 27), // "handleFriendRequestAccepted"
QT_MOC_LITERAL(27, 443, 27), // "handleFriendRequestRejected"
QT_MOC_LITERAL(28, 471, 23), // "handleRequesterNickname"
QT_MOC_LITERAL(29, 495, 8), // "nickname"
QT_MOC_LITERAL(30, 504, 16), // "updateFriendList"
QT_MOC_LITERAL(31, 521, 7), // "friends"
QT_MOC_LITERAL(32, 529, 21), // "onServerFriendClicked"
QT_MOC_LITERAL(33, 551, 23), // "handleFriendInfoRequest"
QT_MOC_LITERAL(34, 575, 24), // "onFriendInfoWindowClosed"
QT_MOC_LITERAL(35, 600, 21), // "showFriendContextMenu"
QT_MOC_LITERAL(36, 622, 3), // "pos"
QT_MOC_LITERAL(37, 626, 20), // "onDeleteFriendAction"
QT_MOC_LITERAL(38, 647, 18), // "on_wenjian_clicked"
QT_MOC_LITERAL(39, 666, 16), // "on_jietu_clicked"
QT_MOC_LITERAL(40, 683, 14), // "on_emo_clicked"
QT_MOC_LITERAL(41, 698, 17), // "on_emoji_selected"
QT_MOC_LITERAL(42, 716, 5) // "emoji"

    },
    "home\0requestResetToQrLogin\0\0avatarChanged\0"
    "newAvatar\0showFriendInfo\0username\0"
    "on_close_clicked\0on_send_clicked\0"
    "on_inputs_textChanged\0on_mybut_clicked\0"
    "on_kuaijie_clicked\0on_more_clicked\0"
    "updateTouxiangLabel\0updateMyButtonAvatar\0"
    "on_k2_clicked\0on_suoxiao_clicked\0"
    "on_fangda_clicked\0on_b6_clicked\0"
    "handleBackToMainWindow\0on_shiping_dh_clicked\0"
    "on_dianhua_clicked\0on_wxlt_clicked\0"
    "on_tongxun_clicked\0handleFriendRequest\0"
    "sender\0handleFriendRequestAccepted\0"
    "handleFriendRequestRejected\0"
    "handleRequesterNickname\0nickname\0"
    "updateFriendList\0friends\0onServerFriendClicked\0"
    "handleFriendInfoRequest\0"
    "onFriendInfoWindowClosed\0showFriendContextMenu\0"
    "pos\0onDeleteFriendAction\0on_wenjian_clicked\0"
    "on_jietu_clicked\0on_emo_clicked\0"
    "on_emoji_selected\0emoji"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_home[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      34,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  184,    2, 0x06 /* Public */,
       3,    1,  185,    2, 0x06 /* Public */,
       5,    1,  188,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       7,    0,  191,    2, 0x08 /* Private */,
       8,    0,  192,    2, 0x08 /* Private */,
       9,    0,  193,    2, 0x08 /* Private */,
      10,    0,  194,    2, 0x08 /* Private */,
      11,    0,  195,    2, 0x08 /* Private */,
      12,    0,  196,    2, 0x08 /* Private */,
      13,    1,  197,    2, 0x08 /* Private */,
      14,    1,  200,    2, 0x08 /* Private */,
      15,    0,  203,    2, 0x08 /* Private */,
      16,    0,  204,    2, 0x08 /* Private */,
      17,    0,  205,    2, 0x08 /* Private */,
      18,    0,  206,    2, 0x08 /* Private */,
      19,    0,  207,    2, 0x08 /* Private */,
      20,    0,  208,    2, 0x08 /* Private */,
      21,    0,  209,    2, 0x08 /* Private */,
      22,    0,  210,    2, 0x08 /* Private */,
      23,    0,  211,    2, 0x08 /* Private */,
      24,    1,  212,    2, 0x08 /* Private */,
      26,    0,  215,    2, 0x08 /* Private */,
      27,    0,  216,    2, 0x08 /* Private */,
      28,    2,  217,    2, 0x08 /* Private */,
      30,    1,  222,    2, 0x08 /* Private */,
      32,    0,  225,    2, 0x08 /* Private */,
      33,    1,  226,    2, 0x08 /* Private */,
      34,    0,  229,    2, 0x08 /* Private */,
      35,    1,  230,    2, 0x08 /* Private */,
      37,    0,  233,    2, 0x08 /* Private */,
      38,    0,  234,    2, 0x08 /* Private */,
      39,    0,  235,    2, 0x08 /* Private */,
      40,    0,  236,    2, 0x08 /* Private */,
      41,    1,  237,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPixmap,    4,
    QMetaType::Void, QMetaType::QString,    6,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPixmap,    4,
    QMetaType::Void, QMetaType::QPixmap,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   25,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   25,   29,
    QMetaType::Void, QMetaType::QStringList,   31,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,   36,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   42,

       0        // eod
};

void home::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<home *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->requestResetToQrLogin(); break;
        case 1: _t->avatarChanged((*reinterpret_cast< const QPixmap(*)>(_a[1]))); break;
        case 2: _t->showFriendInfo((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->on_close_clicked(); break;
        case 4: _t->on_send_clicked(); break;
        case 5: _t->on_inputs_textChanged(); break;
        case 6: _t->on_mybut_clicked(); break;
        case 7: _t->on_kuaijie_clicked(); break;
        case 8: _t->on_more_clicked(); break;
        case 9: _t->updateTouxiangLabel((*reinterpret_cast< const QPixmap(*)>(_a[1]))); break;
        case 10: _t->updateMyButtonAvatar((*reinterpret_cast< const QPixmap(*)>(_a[1]))); break;
        case 11: _t->on_k2_clicked(); break;
        case 12: _t->on_suoxiao_clicked(); break;
        case 13: _t->on_fangda_clicked(); break;
        case 14: _t->on_b6_clicked(); break;
        case 15: _t->handleBackToMainWindow(); break;
        case 16: _t->on_shiping_dh_clicked(); break;
        case 17: _t->on_dianhua_clicked(); break;
        case 18: _t->on_wxlt_clicked(); break;
        case 19: _t->on_tongxun_clicked(); break;
        case 20: _t->handleFriendRequest((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 21: _t->handleFriendRequestAccepted(); break;
        case 22: _t->handleFriendRequestRejected(); break;
        case 23: _t->handleRequesterNickname((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 24: _t->updateFriendList((*reinterpret_cast< const QStringList(*)>(_a[1]))); break;
        case 25: _t->onServerFriendClicked(); break;
        case 26: _t->handleFriendInfoRequest((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 27: _t->onFriendInfoWindowClosed(); break;
        case 28: _t->showFriendContextMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 29: _t->onDeleteFriendAction(); break;
        case 30: _t->on_wenjian_clicked(); break;
        case 31: _t->on_jietu_clicked(); break;
        case 32: _t->on_emo_clicked(); break;
        case 33: _t->on_emoji_selected((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (home::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&home::requestResetToQrLogin)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (home::*)(const QPixmap & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&home::avatarChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (home::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&home::showFriendInfo)) {
                *result = 2;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject home::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_home.data,
    qt_meta_data_home,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *home::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *home::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_home.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int home::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 34)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 34;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 34)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 34;
    }
    return _id;
}

// SIGNAL 0
void home::requestResetToQrLogin()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void home::avatarChanged(const QPixmap & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void home::showFriendInfo(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
