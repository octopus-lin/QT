#ifndef HOME_H
#define HOME_H

#include <QWidget>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QLabel>
#include <QListWidget>
#include "myhome.h"  // 确保包含头文件
#include <QBitmap> // 添加这行
#include "add_friend.h"
#include "shezhi.h"
#include "shiping.h"
#include <QStyledItemDelegate>
#include "chatdatabase.h"
#include "gerengxx.h"
#include <QGridLayout>
#include <QPushButton>
#include <QMessageBox>
#include <QScrollArea>


class ClickableLabel : public QLabel {
    Q_OBJECT
public:
    explicit ClickableLabel(QWidget* parent = nullptr) : QLabel(parent) {}
signals:
    void clicked();  // 自定义点击信号
protected:
    void mousePressEvent(QMouseEvent* event) override {
        QLabel::mousePressEvent(event);
        emit clicked();  // 触发点击信号
    }
};

class FriendListDelegate : public QStyledItemDelegate {
    Q_OBJECT
public:
    using QStyledItemDelegate::QStyledItemDelegate;

    void paint(QPainter *painter, const QStyleOptionViewItem &option,
               const QModelIndex &index) const override;

    QSize sizeHint(const QStyleOptionViewItem &option,
                   const QModelIndex &index) const override;
};

// 添加尖角标签类声明
class TriangleLabel : public QLabel {
public:
    explicit TriangleLabel(QWidget* parent = nullptr) : QLabel(parent) {}
protected:
    void paintEvent(QPaintEvent* event) override;
};

// 添加截图选择窗口类声明
class ScreenshotSelector : public QWidget {
    Q_OBJECT
public:
    explicit ScreenshotSelector(const QPixmap& screenshot, QWidget* parent = nullptr);
    ~ScreenshotSelector() override;
    QPixmap getSelectedRegion() const { return m_selectedRegion; }

protected:
    void paintEvent(QPaintEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;
    void mouseMoveEvent(QMouseEvent* event) override;
    void mouseReleaseEvent(QMouseEvent* event) override;
    void keyPressEvent(QKeyEvent* event) override;

signals:
    void screenshotSelected(const QPixmap& screenshot);
    void screenshotCancelled();

private:
    QPixmap m_screenshot;
    QPixmap m_selectedRegion;
    QRect m_selectionRect;
    QPoint m_startPos;
    bool m_isSelecting;
    void updateSelection(const QPoint& endPos);
};

namespace Ui {
class home;
}

class home : public QWidget
{
    Q_OBJECT

public:
    explicit home(QWidget *parent = nullptr);
    void setUsername(const QString& username);  // 添加设置用户名方法
    void setNickname(const QString& nickname);
    ~home();

signals:
    void requestResetToQrLogin(); // 添加这个信号
    void avatarChanged(const QPixmap& newAvatar);
    void showFriendInfo(const QString& username);

protected:
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    bool eventFilter(QObject *obj, QEvent *event) override;
    void showEvent(QShowEvent *event) override; // 添加这行
    void sendMessageToServer(const QString& message);


private slots:
    void on_close_clicked();
    void on_send_clicked();
    void on_inputs_textChanged();
    void on_mybut_clicked();
    void on_kuaijie_clicked();
    void on_more_clicked();
    void updateTouxiangLabel(const QPixmap& newAvatar);  // 添加这个槽函数
    void updateMyButtonAvatar(const QPixmap& newAvatar);  // 新增的槽函数
    void on_k2_clicked();
    void on_suoxiao_clicked();
    void on_fangda_clicked();
    void on_b6_clicked();
    void handleBackToMainWindow();
    void on_shiping_dh_clicked();
    void on_dianhua_clicked();
    void on_wxlt_clicked();
    void on_tongxun_clicked();
    void handleFriendRequest(const QString& sender); // 处理好友请求
    void handleFriendRequestAccepted();
    void handleFriendRequestRejected();
    void handleRequesterNickname(const QString& sender, const QString& nickname);
    void updateFriendList(const QStringList& friends);
    void onServerFriendClicked();
    void handleFriendInfoRequest(const QString& username); // 新增槽函数
    void onFriendInfoWindowClosed(); // 新增槽函数
    void showFriendContextMenu(const QPoint &pos);
    void onDeleteFriendAction();
    void on_wenjian_clicked();
    void on_jietu_clicked();
    void on_emo_clicked();
    void on_emoji_selected(const QString& emoji);

private:
    Ui::home *ui;
    myhome *mywindow = nullptr;  // 声明为成员变量
    QPoint m_dragPosition;
    add_friend * friendwindow=nullptr;
    shezhi * szwindow=nullptr;
    shiping * spwindow=nullptr;
    void addServerAsFriend();
    // 隐藏所有菜单的辅助函数
    void hideAllMenus();
    QPixmap createRoundedPixmap(const QPixmap& source, int radius);
    QPixmap createBubblePixmap(const QString& message,bool isSelf);
    bool isFullScreen = false;  // 添加全屏状态标志
    QString m_username; // 添加成员变量存储用户名
    QString m_nickname;
    QPixmap m_currentAvatar;
    QByteArray m_avatarData;
    void handleAvatarDataReceived(const QString &username, const QByteArray &data);
    void addFriendRequestToList(const QString& sender); // 添加好友请求到列表
    void removeFriendRequest(const QString& sender);   // 新增：从列表中移除好友请求
    void handleFriendRequestAction(bool accepted);
    QMap<QString, QListWidgetItem*> m_friendRequests; // 存储好友请求项
    QMap<QString, QString> m_pendingNicknames;
    FriendListDelegate* m_friendListDelegate = nullptr;
    bool m_serverFriendAdded = false;
    void switchToChatSession(const QString& peer);
    QString getNickname(const QString& username) const;
    void displayMessageInChat(const QString& sender, const QString& message);
    void showSystemNotification(const QString& sender, const QString& message);
    QWidget* createAvatarWidget(bool isSelf);
    QWidget* createMessageBubble(const QString& message, bool isSelf);
    ChatDatabase m_chatDatabase;
    QWidget* createSelfMessageBubble(const QString& message);
    QWidget* createPeerMessageBubble(const QString& message, const QString& sender);
    void displayMessageBubble(const QString& sender, const QString& message, qint64 timestamp);
    void saveMessageToDatabase(const QString &sender, const QString &receiver, const QString &message, qint64 timestamp);
    QString m_currentActivePeer; // 当前选中的好友
    void loadChatHistory(const QString& peer); // 加载指定好友的聊天记录
    void saveCurrentChat(); // 保存当前聊天记录
    void updateUnreadBadge(QListWidgetItem* item, int count);
    QString getBaseUsername(const QString& fullUsername) const {
        if (fullUsername.isEmpty()) return "";

        // 处理带昵称格式 "username|nickname"
        QString base = fullUsername.split('|').first();

        // 清理可能的附加信息
        if (base.contains(':')) {
            base = base.split(':').first();
        }
        return base;
    }

    void onPrivateMessageReceived(const QString &sender, const QString &message);
    QPixmap loadAvatar(const QString &path, const QSize &size, int radius);
    QSet<QString> m_receivedMessageHashes; // 记录已接收消息的哈希值
    QSet<QString> m_deletedFriends; // 记录已删除的好友，用于过滤服务器返回的错误列表
    QString generateMessageFingerprint(const QString &sender, const QString &content);
    QHash<QString, QDateTime> m_recentMessages;


    struct ChatHistoryState {
        int loadedCount = 0;      // 已加载的消息数量
        int totalMessages = 0;    // 总消息数量
        bool isLoading = false;   // 防止重复加载
        bool hasMore = true;      // 是否还有更多消息
    };

    QMap<QString, ChatHistoryState> m_chatHistoryState;  // 每个好友的聊天状态

    // 添加以下私有方法
    void loadInitialMessages(const QString& peer);
    void loadMoreMessages(const QString& peer);
    QWidget *createMessageWidgetForBubble(const QString &sender, const QString &message);

    void processIncomingMessage(const QString &sender, const QString &message, bool isOffline);
    QString getNicknameFromUsername(const QString &username) const;
    // 在私有成员区域添加
    QMap<QString, QPixmap> m_avatarCache; // 头像内存缓存

    // 添加私有方法
    void requestFriendAvatars(const QStringList& friends);
    void updateFriendAvatar(const QString& username, const QPixmap& avatar);
    void handleFriendAvatarDataReceived(const QString &username, const QByteArray &data);
    QMap<QString, QMap<QString, QListWidgetItem*>> m_accountFriendRequests;
    gerengxx* m_friendInfoWindow = nullptr; // 好友信息窗口指针
    QMap<QString, QString> m_friendNicknameMap; // 存储好友账号到昵称的映射
    QMenu *m_contextMenu;
    QAction *m_deleteAction;
    QString m_contextMenuFriend; // 当前右键选中的好友
    
    // 表情相关成员变量
    QWidget *m_emojiWindow; // 表情选择窗口
    QGridLayout *m_emojiLayout; // 表情布局
    QStringList m_commonEmojis; // 常用表情列表
    void initEmojiWindow(); // 初始化表情窗口
};




#endif // HOME_H
