#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMouseEvent>
#include "home.h"
#include "setwindow.h"
#include "networkmanager.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void showMainWindow();
    void clearCredentials() {
        m_lastUsername = "";
        m_lastPassword = "";
    }

protected:
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void showEvent(QShowEvent *event) override;

private slots:
    void on_exit_clicked();

    void on_going_clicked();

    void on_qiehuan_clicked();

    void on_chuanshu_clicked();

    void on_chuanshu_2_clicked();

    void on_shezhi_clicked();

    void handleSetWindowBack(const QPoint& position);

    void on_pying_clicked();
    void handleLoginResponse(bool success, const QString& message); // 处理登录响应
    void handleLoginSuccess(const QString& nickname);
private:
    Ui::MainWindow *ui;
    QPoint m_dragPosition;
    home * homewindow;
    setwindow * Setwindow;
    void resetToQrLoginState();
    NetworkManager* m_netManager; // 网络管理器实例
    QString m_lastUsername;  // 保存上次登录用户名
    QString m_lastPassword;  // 保存上次登录密码

};
#endif // MAINWINDOW_H
