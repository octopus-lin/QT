/********************************************************************************
** Form generated from reading UI file 'shiping.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHIPING_H
#define UI_SHIPING_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_shiping
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLabel *label_2;
    QPushButton *fanzhuan;
    QMenuBar *menubar;

    void setupUi(QMainWindow *shiping)
    {
        if (shiping->objectName().isEmpty())
            shiping->setObjectName(QString::fromUtf8("shiping"));
        shiping->resize(448, 798);
        centralwidget = new QWidget(shiping);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 448, 798));
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 255, 255);"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(310, 30, 130, 200));
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        fanzhuan = new QPushButton(centralwidget);
        fanzhuan->setObjectName(QString::fromUtf8("fanzhuan"));
        fanzhuan->setGeometry(QRect(310, 30, 130, 200));
        fanzhuan->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"\n"
"}    "));
        shiping->setCentralWidget(centralwidget);
        menubar = new QMenuBar(shiping);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 448, 26));
        shiping->setMenuBar(menubar);

        retranslateUi(shiping);

        QMetaObject::connectSlotsByName(shiping);
    } // setupUi

    void retranslateUi(QMainWindow *shiping)
    {
        shiping->setWindowTitle(QCoreApplication::translate("shiping", "MainWindow", nullptr));
        label->setText(QString());
        label_2->setText(QString());
        fanzhuan->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class shiping: public Ui_shiping {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHIPING_H
