#include "add_friend.h"
#include "ui_add_friend.h"
#include <QMouseEvent>

add_friend::add_friend(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::add_friend),
    fryzwindow(nullptr)
{
    ui->setupUi(this);
    // 1. 删除标题栏
    setWindowFlags(Qt::FramelessWindowHint);
    // 2. 设置窗口背景透明
    setAttribute(Qt::WA_TranslucentBackground);
    // 3. 添加背景图片样式表
    ui->centralwidget->setStyleSheet(
                "QWidget#centralwidget {"
                "  background-image: url(:/img/img/addfriend.png);"
                "  background-position: center;"
                "  background-repeat: no-repeat;"
                "  border-radius: 10px;"          // 圆角
                "  border: 1px solid rgba(0,0,0,75);" // 边框效果
                "}"
                );

    ui->add_f->hide();
    ui->friend_xx->hide();
    ui->touxiang->hide();
    ui->name->hide();

    // 连接网络管理器的搜索结果信号
    NetworkManager *netManager = NetworkManager::instance();
    connect(netManager, &NetworkManager::searchResultReceived,
            this, &add_friend::handleSearchResult);

}

add_friend::~add_friend()
{
    delete ui;
}

void add_friend::handleSearchResult(const QString& username, bool found)
{


    if (found) {
        // 显示好友信息区域
        ui->friend_xx->show();
        ui->touxiang->show();
        ui->name->show();
        ui->add_f->show();

        // 设置用户名到name标签
        ui->name->setText(username);
    } else {
        ui->add_f->hide();
        ui->friend_xx->hide();
        ui->touxiang->hide();
        ui->name->hide();
        QMessageBox::information(this, "搜索好友", "用户不存在");
    }
}


// 鼠标按下事件处理
void add_friend::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        // 记录鼠标按下时的全局位置和窗口位置
        m_dragPosition = event->globalPos() - frameGeometry().topLeft();
        event->accept();
    }
}

// 鼠标移动事件处理
void add_friend::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton) {
        // 计算窗口新位置
        move(event->globalPos() - m_dragPosition);
        event->accept();
    }
}
void add_friend::on_close_f_clicked()
{
    this->close();
}

void add_friend::on_lookf_clicked()
{
    QString wx_id = ui->wx_id->text().trimmed();
    if (wx_id.isEmpty()) {
        QMessageBox::warning(this, "搜索好友", "请输入微信号");
        return;
    }

    NetworkManager *netManager = NetworkManager::instance();
    if (!netManager->isConnected()) {
        QMessageBox::warning(this, "网络错误", "未连接到服务器");
        return;
    }

    // 发送搜索请求
    QString command = "SEARCH_USER:" + wx_id;
    netManager->sendTcpMessage(command);
}

void add_friend::on_add_f_clicked()
{
    QString targetUsername = ui->name->text(); // 获取搜索到的用户名

    NetworkManager *netManager = NetworkManager::instance();
    QString currentUser = netManager->username(); // 获取当前用户名

    // 检查是否在添加自己
    if (targetUsername == currentUser) {
        QMessageBox::information(this, "搜索好友", "不能添加自己为好友");
        ui->add_f->hide();
        ui->friend_xx->hide();
        ui->touxiang->hide();
        ui->name->hide();
        return;
    }

    // +++ 新增：检查是否已经是好友 +++
    QStringList friendList = netManager->getFriendList(); // 获取好友列表
    if (friendList.contains(targetUsername)) {
        QMessageBox::information(this, "添加好友", "您已经和对方是好友了");
        // 隐藏添加按钮和信息显示
        ui->add_f->hide();
        ui->friend_xx->hide();
        ui->touxiang->hide();
        ui->name->hide();
        return;
    }



    if (fryzwindow == nullptr) {
        fryzwindow = new friend_yz(nullptr, targetUsername);
        connect(fryzwindow, &friend_yz::destroyed, this, [this]() {
            fryzwindow = nullptr;
        });
    } else {
        fryzwindow->setTargetUsername(targetUsername);
    }

    fryzwindow->show();
}
