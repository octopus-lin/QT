/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_2;
    QLabel *label;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_4;
    QLineEdit *ipLineEdit;
    QLabel *label_5;
    QLineEdit *tcpPortEdit;
    QLabel *label_6;
    QLineEdit *udpPortEdit;
    QPushButton *applyPortButton;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout_2;
    QListWidget *listWidget;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout_3;
    QListWidget *onlineUsersList;
    QGroupBox *groupBox_3;
    QVBoxLayout *verticalLayout_4;
    QLineEdit *searchEdit;
    QHBoxLayout *horizontalLayout;
    QPushButton *searchButton;
    QPushButton *showFriendsButton;
    QLabel *statusLabel;
    QTableView *friendsTableView;
    QGroupBox *groupBox_4;
    QGridLayout *gridLayout;
    QLabel *label_2;
    QLineEdit *messageEdit;
    QPushButton *sendButton;
    QLabel *label_3;
    QLineEdit *targetPortEdit;
    QPushButton *clearDbButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1000, 750);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout_2 = new QGridLayout(centralwidget);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setStyleSheet(QString::fromUtf8("font: 24pt \"Arial\"; font-weight: bold; color: #3498db;"));
        label->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label, 0, 0, 1, 2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_2->addWidget(label_4);

        ipLineEdit = new QLineEdit(centralwidget);
        ipLineEdit->setObjectName(QString::fromUtf8("ipLineEdit"));
        ipLineEdit->setReadOnly(true);
        ipLineEdit->setStyleSheet(QString::fromUtf8("background-color: #34495e; color: #ecf0f1;"));

        horizontalLayout_2->addWidget(ipLineEdit);

        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_2->addWidget(label_5);

        tcpPortEdit = new QLineEdit(centralwidget);
        tcpPortEdit->setObjectName(QString::fromUtf8("tcpPortEdit"));
        tcpPortEdit->setStyleSheet(QString::fromUtf8("background-color: #34495e; color: #ecf0f1;"));

        horizontalLayout_2->addWidget(tcpPortEdit);

        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_2->addWidget(label_6);

        udpPortEdit = new QLineEdit(centralwidget);
        udpPortEdit->setObjectName(QString::fromUtf8("udpPortEdit"));
        udpPortEdit->setStyleSheet(QString::fromUtf8("background-color: #34495e; color: #ecf0f1;"));

        horizontalLayout_2->addWidget(udpPortEdit);

        applyPortButton = new QPushButton(centralwidget);
        applyPortButton->setObjectName(QString::fromUtf8("applyPortButton"));

        horizontalLayout_2->addWidget(applyPortButton);


        gridLayout_2->addLayout(horizontalLayout_2, 1, 0, 1, 2);

        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        verticalLayout_2 = new QVBoxLayout(groupBox);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        listWidget = new QListWidget(groupBox);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setMinimumSize(QSize(0, 200));

        verticalLayout_2->addWidget(listWidget);


        gridLayout_2->addWidget(groupBox, 2, 0, 1, 2);

        groupBox_2 = new QGroupBox(centralwidget);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        verticalLayout_3 = new QVBoxLayout(groupBox_2);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        onlineUsersList = new QListWidget(groupBox_2);
        onlineUsersList->setObjectName(QString::fromUtf8("onlineUsersList"));

        verticalLayout_3->addWidget(onlineUsersList);


        gridLayout_2->addWidget(groupBox_2, 3, 0, 1, 1);

        groupBox_3 = new QGroupBox(centralwidget);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        verticalLayout_4 = new QVBoxLayout(groupBox_3);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        searchEdit = new QLineEdit(groupBox_3);
        searchEdit->setObjectName(QString::fromUtf8("searchEdit"));

        verticalLayout_4->addWidget(searchEdit);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        searchButton = new QPushButton(groupBox_3);
        searchButton->setObjectName(QString::fromUtf8("searchButton"));

        horizontalLayout->addWidget(searchButton);

        showFriendsButton = new QPushButton(groupBox_3);
        showFriendsButton->setObjectName(QString::fromUtf8("showFriendsButton"));

        horizontalLayout->addWidget(showFriendsButton);


        verticalLayout_4->addLayout(horizontalLayout);

        statusLabel = new QLabel(groupBox_3);
        statusLabel->setObjectName(QString::fromUtf8("statusLabel"));
        statusLabel->setStyleSheet(QString::fromUtf8("color: #3498db; font-weight: bold;"));

        verticalLayout_4->addWidget(statusLabel);

        friendsTableView = new QTableView(groupBox_3);
        friendsTableView->setObjectName(QString::fromUtf8("friendsTableView"));

        verticalLayout_4->addWidget(friendsTableView);


        gridLayout_2->addWidget(groupBox_3, 3, 1, 1, 1);

        groupBox_4 = new QGroupBox(centralwidget);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        gridLayout = new QGridLayout(groupBox_4);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_2 = new QLabel(groupBox_4);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 0, 0, 1, 1);

        messageEdit = new QLineEdit(groupBox_4);
        messageEdit->setObjectName(QString::fromUtf8("messageEdit"));

        gridLayout->addWidget(messageEdit, 0, 1, 1, 1);

        sendButton = new QPushButton(groupBox_4);
        sendButton->setObjectName(QString::fromUtf8("sendButton"));

        gridLayout->addWidget(sendButton, 0, 2, 1, 1);

        label_3 = new QLabel(groupBox_4);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 1, 0, 1, 1);

        targetPortEdit = new QLineEdit(groupBox_4);
        targetPortEdit->setObjectName(QString::fromUtf8("targetPortEdit"));

        gridLayout->addWidget(targetPortEdit, 1, 1, 1, 1);

        clearDbButton = new QPushButton(groupBox_4);
        clearDbButton->setObjectName(QString::fromUtf8("clearDbButton"));

        gridLayout->addWidget(clearDbButton, 1, 2, 1, 1);


        gridLayout_2->addWidget(groupBox_4, 4, 0, 1, 2);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1000, 26));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "\351\253\230\347\272\247\350\201\212\345\244\251\346\234\215\345\212\241\345\231\250", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "\351\253\230\347\272\247\350\201\212\345\244\251\346\234\215\345\212\241\345\231\250", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "\346\234\215\345\212\241\345\231\250IP:", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "TCP\347\253\257\345\217\243:", nullptr));
        tcpPortEdit->setText(QCoreApplication::translate("MainWindow", "8888", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "UDP\347\253\257\345\217\243:", nullptr));
        udpPortEdit->setText(QCoreApplication::translate("MainWindow", "8890", nullptr));
        applyPortButton->setText(QCoreApplication::translate("MainWindow", "\345\272\224\347\224\250\347\253\257\345\217\243", nullptr));
        groupBox->setTitle(QCoreApplication::translate("MainWindow", "\346\234\215\345\212\241\345\231\250\346\227\245\345\277\227", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("MainWindow", "\345\234\250\347\272\277\347\224\250\346\210\267", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("MainWindow", "\345\245\275\345\217\213\345\205\263\347\263\273", nullptr));
        searchEdit->setPlaceholderText(QCoreApplication::translate("MainWindow", "\346\220\234\347\264\242\345\245\275\345\217\213\345\205\263\347\263\273...", nullptr));
        searchButton->setText(QCoreApplication::translate("MainWindow", "\346\220\234\347\264\242", nullptr));
        showFriendsButton->setText(QCoreApplication::translate("MainWindow", "\346\237\245\347\234\213\345\245\275\345\217\213", nullptr));
        statusLabel->setText(QCoreApplication::translate("MainWindow", "\347\212\266\346\200\201: \345\260\261\347\273\252", nullptr));
        groupBox_4->setTitle(QCoreApplication::translate("MainWindow", "\346\234\215\345\212\241\345\231\250\346\223\215\344\275\234", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\346\266\210\346\201\257\345\206\205\345\256\271\357\274\232", nullptr));
        sendButton->setText(QCoreApplication::translate("MainWindow", "\345\217\221\351\200\201", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "\347\233\256\346\240\207\347\253\257\345\217\243\357\274\232", nullptr));
        clearDbButton->setText(QCoreApplication::translate("MainWindow", "\346\270\205\347\251\272\346\225\260\346\215\256\345\272\223", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
