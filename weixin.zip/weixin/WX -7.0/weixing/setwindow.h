#ifndef SETWINDOW_H
#define SETWINDOW_H

#include <QMainWindow>
#include <QPropertyAnimation>
#include <QSettings> // 添加QSettings支持

namespace Ui {
class setwindow;
}

class setwindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit setwindow(QWidget *parent = nullptr);
    ~setwindow();

protected:
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;

signals:
    void showMainWindow(const QPoint& position);

private slots:
    void on_exit_clicked();
    void on_fanhui_clicked();
    void toggleSwitch();  // 添加切换开关的槽函数
    void on_pying_clicked();

private:
    Ui::setwindow *ui;
    bool switchState = false;  // 开关状态
    QPropertyAnimation *slideAnimation;  // 滑动动画
    QPoint m_dragPosition;

    // 添加服务器配置保存和加载方法
    void saveServerSettings();
    void loadServerSettings();
};

#endif // SETWINDOW_H
