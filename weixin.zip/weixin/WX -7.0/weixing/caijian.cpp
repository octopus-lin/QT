#include "caijian.h"
#include <QDialogButtonBox>
#include <QVBoxLayout>
#include <QGraphicsSceneMouseEvent>
#include <QResizeEvent>
#include <cmath>

// AspectRatioRectItem 实现
CropDialog::AspectRatioRectItem::AspectRatioRectItem(QGraphicsItem *parent)
    : QGraphicsRectItem(parent), isResizing(false) {
    setFlag(QGraphicsItem::ItemIsMovable);
    setFlag(QGraphicsItem::ItemIsSelectable);
    setFlag(QGraphicsItem::ItemSendsGeometryChanges);
}

void CropDialog::AspectRatioRectItem::mousePressEvent(QGraphicsSceneMouseEvent *event) {
    const qreal margin = 10;
    QRectF innerRect = rect().adjusted(margin, margin, -margin, -margin);

    if (!innerRect.contains(event->pos())) {
        isResizing = true;
        resizeCorner = getCorner(event->pos());
        event->accept();
        return;
    }

    QGraphicsRectItem::mousePressEvent(event);
}

void CropDialog::AspectRatioRectItem::mouseMoveEvent(QGraphicsSceneMouseEvent *event) {
    if (isResizing) {
        resizeRect(event->pos());
        event->accept();
    } else {
        QGraphicsRectItem::mouseMoveEvent(event);
    }
}

void CropDialog::AspectRatioRectItem::mouseReleaseEvent(QGraphicsSceneMouseEvent *event) {
    isResizing = false;
    QGraphicsRectItem::mouseReleaseEvent(event);
}

QVariant CropDialog::AspectRatioRectItem::itemChange(GraphicsItemChange change, const QVariant &value) {
    if (change == ItemPositionChange && scene()) {
        QRectF pixmapRect = scene()->sceneRect();
        QPointF newPos = value.toPointF();
        QRectF rect = this->rect();

        if (newPos.x() < pixmapRect.left())
            newPos.setX(pixmapRect.left());
        if (newPos.y() < pixmapRect.top())
            newPos.setY(pixmapRect.top());
        if (newPos.x() + rect.width() > pixmapRect.right())
            newPos.setX(pixmapRect.right() - rect.width());
        if (newPos.y() + rect.height() > pixmapRect.bottom())
            newPos.setY(pixmapRect.bottom() - rect.height());

        return newPos;
    }
    return QGraphicsRectItem::itemChange(change, value);
}

Qt::Corner CropDialog::AspectRatioRectItem::getCorner(const QPointF &pos) {
    QRectF r = rect();
    if (pos.x() < r.left() + 10 && pos.y() < r.top() + 10)
        return Qt::TopLeftCorner;
    if (pos.x() > r.right() - 10 && pos.y() < r.top() + 10)
        return Qt::TopRightCorner;
    if (pos.x() < r.left() + 10 && pos.y() > r.bottom() - 10)
        return Qt::BottomLeftCorner;
    return Qt::BottomRightCorner;
}

void CropDialog::AspectRatioRectItem::resizeRect(const QPointF &pos) {
    QRectF r = rect();
    qreal size = qMax(std::fabs(pos.x()), std::fabs(pos.y()));

    switch (resizeCorner) {
    case Qt::TopLeftCorner:
        r.setTopLeft(QPointF(-size, -size));
        r.setSize(QSize(size, size));
        break;
    case Qt::TopRightCorner:
        r.setTopRight(QPointF(size, -size));
        r.setSize(QSize(size, size));
        break;
    case Qt::BottomLeftCorner:
        r.setBottomLeft(QPointF(-size, size));
        r.setSize(QSize(size, size));
        break;
    case Qt::BottomRightCorner:
        r.setBottomRight(QPointF(size, size));
        r.setSize(QSize(size, size));
        break;
    }

    if (r.width() >= 10 && r.height() >= 10) {
        setRect(r);
    }
}

// CropDialog 实现
CropDialog::CropDialog(const QPixmap &pixmap, QWidget *parent)
    : QDialog(parent), originalPixmap(pixmap) {
    setWindowTitle("裁剪头像");
    setFixedSize(600, 600);

    // 创建场景和视图
    scene = new QGraphicsScene(this);
    view = new QGraphicsView(scene);
    view->setRenderHint(QPainter::Antialiasing);

    // 添加图片到场景
    pixmapItem = scene->addPixmap(originalPixmap);

    // 创建裁剪框
    cropRect = new AspectRatioRectItem();
    cropRect->setPen(QPen(Qt::red, 2));
    cropRect->setBrush(QBrush(QColor(0, 0, 0, 50)));
    scene->addItem(cropRect);

    // 按钮
    QDialogButtonBox *buttonBox = new QDialogButtonBox(
        QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
    connect(buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);

    // 布局
    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(view);
    layout->addWidget(buttonBox);
    setLayout(layout);

    // 初始裁剪区域（1:1）
    QRectF rect = pixmapItem->boundingRect();
    double size = qMin(rect.width(), rect.height());
    cropRect->setRect(0, 0, size, size);
    cropRect->setPos(rect.center() - QPointF(size/2, size/2));

    // 设置视图大小
    view->fitInView(pixmapItem, Qt::KeepAspectRatio);
}

QPixmap CropDialog::croppedPixmap() const {
    QRectF rect = cropRect->rect();
    return originalPixmap.copy(
        cropRect->pos().x() + rect.x(),
        cropRect->pos().y() + rect.y(),
        rect.width(),
        rect.height()
    );
}

QRectF CropDialog::cropArea() const {
    return cropRect->mapRectToScene(cropRect->rect());
}


void CropDialog::resizeEvent(QResizeEvent *event) {
    QDialog::resizeEvent(event);
    view->fitInView(pixmapItem, Qt::KeepAspectRatio);
}
