#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QPaintEvent>
#include <QDesktopServices>
#include <QPropertyAnimation>
#include <QScreen>
#include <QMessageBox>
#include <QDebug>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    ,homewindow(new home)
    , Setwindow(nullptr)
    , m_lastUsername("")
    , m_lastPassword("")
{
    ui->setupUi(this);
    ui->chuanshu_2->hide();

    // 1. 删除标题栏
    setWindowFlags(Qt::FramelessWindowHint);

    // 2. 设置窗口背景透明
    setAttribute(Qt::WA_TranslucentBackground);

    // 3. 设置样式表（添加边框效果）
    ui->centralwidget->setStyleSheet(
                "QWidget#centralwidget {"
                "  background-image: url(:/img/img/wsmain.png);"
                "  background-position: center;"
                "  background-repeat no-repeat;"
                "  border-radius: 10px;"          // 圆角
                "  border: 1px solid rgba(0,0,0,75);"
                "}"
                );

    // 连接home的重置信号
    connect(homewindow, &home::requestResetToQrLogin,
            this, &MainWindow::resetToQrLoginState);

    ui->useradd->hide();
    ui->passadd->hide();
    ui->pying->hide();

    // 初始化网络管理器
    m_netManager = NetworkManager::instance();

    // 连接登录响应信号
    connect(m_netManager, static_cast<void (NetworkManager::*)(const QString&)>(&NetworkManager::loginSuccess),
            this, &MainWindow::handleLoginSuccess);
    connect(m_netManager, &NetworkManager::loginFailed,
            this, [this](const QString& reason) {
        handleLoginResponse(false, reason);
    });
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::handleLoginSuccess(const QString& nickname)
{
    // 登录成功时保存凭证
    m_lastUsername = ui->useradd->text();
    m_lastPassword = ui->passadd->text();
    QString username = ui->useradd->text();

    // 删除旧的home窗口，创建新的实例以确保正确初始化好友请求列表
    delete homewindow;
    homewindow = new home();

    // 连接home的重置信号
    connect(homewindow, &home::requestResetToQrLogin,
            this, &MainWindow::resetToQrLoginState);

    // 设置home的用户名和昵称
    homewindow->setUsername(username);
    homewindow->setNickname(nickname); // 设置昵称

    // 登录成功
    this->hide();

    // 设置 home 窗口居中显示
    QRect screenGeometry = QApplication::primaryScreen()->geometry();
    int x = (screenGeometry.width() - homewindow->width()) / 2;
    int y = (screenGeometry.height() - homewindow->height()) / 2;
    homewindow->move(x, y);
    homewindow->show();

}

// 处理登录响应
void MainWindow::handleLoginResponse(bool success, const QString& message) {
    qDebug()<<"登录状态："<<success;
    qDebug()<<"状态信息："<<message;
    if (success) {
        // 登录成功时保存凭证
        m_lastUsername = ui->useradd->text();
        m_lastPassword = ui->passadd->text();
        QString username = ui->useradd->text();

        delete homewindow;  // 删除旧的home窗口
        homewindow = new home();  // 创建新的home窗口

        // 直接设置home的用户名
        homewindow->setUsername(username);

        // 登录成功
        this->hide();

        // 设置 home 窗口居中显示
        QRect screenGeometry = QApplication::primaryScreen()->geometry();
        int x = (screenGeometry.width() - homewindow->width()) / 2;
        int y = (screenGeometry.height() - homewindow->height()) / 2;
        homewindow->move(x, y);

        homewindow->show();
        qWarning() << "在处理登录响应时取得意外成功";
    }
    else
    {
        // 登录失败
        on_qiehuan_clicked();
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(this, "登录失败",
                                      message + "\n是否注册该账号?",
                                      QMessageBox::Yes | QMessageBox::No);

        if (reply == QMessageBox::Yes)
        {
            // 用户选择注册
            QString username = ui->useradd->text();
            QString password = ui->passadd->text();

            if (!username.isEmpty() && !password.isEmpty()) {
                // 发送注册请求
                QString registerMsg = QString("REGISTER:%1,%2").arg(username).arg(password);
                m_netManager->sendTcpMessage(registerMsg);
                disconnect(m_netManager, &NetworkManager::registerSuccess, this, nullptr);
                // 连接注册成功/失败信号
                auto conn = std::make_shared<QMetaObject::Connection>();
                *conn = connect(m_netManager, &NetworkManager::registerSuccess, this,
                                [this, conn]() {
                    QMessageBox::information(this, "注册成功", "账号注册成功，请重新登录");
                    disconnect(*conn); // 断开连接
                });

                *conn = connect(m_netManager, &NetworkManager::registerFailed, this,
                                [this, conn](const QString& reason) {
                    QMessageBox::warning(this, "注册失败", "失败原因: " + reason);
                    disconnect(*conn); // 断开连接
                });

            } else {
                QMessageBox::warning(this, "注册失败", "用户名或密码不能为空");
            }
        }
    }
}

void MainWindow::resetToQrLoginState()
{
    // 重置为二维码登录界面
    ui->centralwidget->setStyleSheet(
                "QWidget#centralwidget {"
                "  background-image: url(:/img/img/wsmain.png);"
                "  background-position: center;"
                "  background-repeat no-repeat;"
                "  border-radius: 10px;"          // 圆角
                "  border: 1px solid rgba(0,0,0,75);"
                "}"
                );

    ui->name->show();
    ui->touxiang->show();
    ui->qiehuan->show();
    ui->chuanshu->show();
    ui->going->show();

    // 隐藏账号密码登录元素
    ui->chuanshu_2->hide();
    ui->useradd->hide();
    ui->passadd->hide();
    ui->pying->hide();
}

// 新增函数：显示主窗口
void MainWindow::showMainWindow()
{
    resetToQrLoginState();
    ui->useradd->hide();
    ui->passadd->hide();
    ui->pying->hide();
    // 创建淡入动画
    QPropertyAnimation *animation = new QPropertyAnimation(this, "windowOpacity");
    animation->setDuration(500); // 500毫秒
    animation->setStartValue(0.0);
    animation->setEndValue(1.0);
    animation->setEasingCurve(QEasingCurve::InOutQuad);

    // 显示窗口并启动动画
    this->show();
    animation->start(QPropertyAnimation::DeleteWhenStopped);
}

void MainWindow::on_shezhi_clicked()
{
    // 创建设置窗口
    Setwindow = new setwindow();

    // 获取当前主窗口位置
    QPoint currentPos = this->pos();

    // 设置新窗口位置为主窗口当前位置
    Setwindow->move(currentPos);

    // 连接信号
    connect(Setwindow, &setwindow::showMainWindow, this, &MainWindow::handleSetWindowBack);

    // 显示设置窗口并隐藏当前窗口
    Setwindow->show();
    this->hide();
}

void MainWindow::handleSetWindowBack(const QPoint& position)
{
    // 移动到设置窗口的位置
    this->move(position);

    // 创建淡入动画
    QPropertyAnimation *animation = new QPropertyAnimation(this, "windowOpacity");
    animation->setDuration(500);
    animation->setStartValue(0.0);
    animation->setEndValue(1.0);
    animation->setEasingCurve(QEasingCurve::InOutQuad);

    // 显示窗口并启动动画
    this->show();
    animation->start(QPropertyAnimation::DeleteWhenStopped);

    // 清理设置窗口
    if (Setwindow) {
        Setwindow->deleteLater();
        Setwindow = nullptr;
    }
}

// 添加showEvent事件处理
void MainWindow::showEvent(QShowEvent *event)
{
    QMainWindow::showEvent(event);

    // 创建淡入动画
    QPropertyAnimation *animation = new QPropertyAnimation(this, "windowOpacity");
    animation->setDuration(500); // 500毫秒
    animation->setStartValue(0.0);
    animation->setEndValue(1.0);
    animation->setEasingCurve(QEasingCurve::InOutQuad);
    animation->start(QPropertyAnimation::DeleteWhenStopped);
}


// 鼠标事件处理
void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        m_dragPosition = event->globalPos() - frameGeometry().topLeft();
        event->accept();
    }
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton) {
        move(event->globalPos() - m_dragPosition);
        event->accept();
    }
}

void MainWindow::on_exit_clicked()
{
    // 创建淡出动画
    QPropertyAnimation *animation = new QPropertyAnimation(this, "windowOpacity");
    animation->setDuration(500); // 400毫秒
    animation->setStartValue(1.0);
    animation->setEndValue(0.0);
    animation->setEasingCurve(QEasingCurve::InOutQuad);

    // 动画结束时关闭窗口
    connect(animation, &QPropertyAnimation::finished, this, [=]() {
        close();  // 关闭窗口
        animation->deleteLater(); // 安全删除动画对象
    });

    animation->start();
}

void MainWindow::on_going_clicked()
{
    // 如果有保存的凭证，尝试自动登录
    if (!m_lastUsername.isEmpty() && !m_lastPassword.isEmpty()) {
        // 确保连接到服务器
        if (!m_netManager->isConnected()) {
            if (!m_netManager->connectToServer("192.168.46.226", 8888)) {
                QMessageBox::warning(this, "连接失败", "无法连接到服务器");
                return;
            }
        }

        // 发送登录请求
        QString loginMsg = QString("LOGIN:%1,%2").arg(m_lastUsername).arg(m_lastPassword);
        m_netManager->sendTcpMessage(loginMsg);
        return;
    }

    QMessageBox::warning(this, "登录已失效", "请重新登录");
    // 没有保存的凭证，显示登录
    on_qiehuan_clicked();
}

void MainWindow::on_qiehuan_clicked()
{
    ui->centralwidget->setStyleSheet(
                "QWidget#centralwidget {"
                "  background-image: url(:/img/img/wsmain2.png);"
                "  background-position: center;"
                "  background-repeat: no-repeat;"
                "  border-radius: 10px;"          // 圆角
                "  border: 1px solid rgba(0,0,0,75);"
                "}"
                );
    ui->name->hide();
    ui->touxiang->hide();
    ui->qiehuan->hide();
    ui->chuanshu->hide();
    ui->going->hide();

    ui->chuanshu_2->show();
    ui->useradd->show();
    ui->passadd->show();
    ui->pying->show();
}

void MainWindow::on_chuanshu_clicked()
{
    // 打开微信文件传输助手网页
    QDesktopServices::openUrl(QUrl("https://filehelper.weixin.qq.com/?from=windows&type=recommend"));
}

void MainWindow::on_chuanshu_2_clicked()
{
    // 打开微信文件传输助手网页
    QDesktopServices::openUrl(QUrl("https://filehelper.weixin.qq.com/?from=windows&type=recommend"));
}



void MainWindow::on_pying_clicked()
{
    QString username = ui->useradd->text();
    QString password = ui->passadd->text();

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "登录失败", "用户名或密码不能为空");
        return;
    }

    // 确保连接到服务器 - 使用配置连接
    if (!m_netManager->connectToServer()) {
        QMessageBox::warning(this, "连接失败", "无法连接到服务器");
        return;
    }

    // 发送登录请求 (格式: "LOGIN:用户名,密码")
    QString loginMsg = QString("LOGIN:%1,%2").arg(username).arg(password);
    m_netManager->sendTcpMessage(loginMsg);

    // 设置用户名（用于后续通信）
    m_netManager->setUsername(username);
}
