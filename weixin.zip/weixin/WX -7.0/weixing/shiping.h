#ifndef SHIPING_H
#define SHIPING_H

#include <QMainWindow>
#include <QCamera>
#include <QVideoWidget>
#include <QMediaRecorder>

namespace Ui {
class shiping;
}

class shiping : public QMainWindow
{
    Q_OBJECT

public:
    explicit shiping(QWidget *parent = nullptr);
    ~shiping();
    void toggleFullscreen();

protected:
    void resizeEvent(QResizeEvent* event) override;  // 添加重写函数

private slots:
    void on_fanzhuan_clicked();

private:
    Ui::shiping *ui;
    QCamera *camera = nullptr;
    QVideoWidget *videoWidget = nullptr;
    QMediaRecorder *recorder = nullptr;

    void setupCamera();
    bool isFullScreen = false;
    bool isLabel2Mode = true;  // 添加显示模式标志
};

#endif // SHIPING_H
