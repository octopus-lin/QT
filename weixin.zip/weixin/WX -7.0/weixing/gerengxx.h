#ifndef GERENGXX_H
#define GERENGXX_H

#include <QMainWindow>
#include <QPixmap>

namespace Ui {
class gerengxx;
}

class gerengxx : public QMainWindow
{
    Q_OBJECT

public:
    explicit gerengxx(QWidget *parent = nullptr);
    ~gerengxx();
    void setUserInfo(const QString& username, const QString& nickname, const QPixmap& avatar);

private:
    Ui::gerengxx *ui;
};

#endif // GERENGXX_H
