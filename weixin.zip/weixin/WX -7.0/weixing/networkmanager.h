#ifndef NETWORKMANAGER_H
#define NETWORKMANAGER_H

#include <QObject>
#include <QTcpSocket>
#include <QUdpSocket>
#include <QHostAddress>
#include <QMap>
#include <QByteArray>
#include <QTimer>
#include <QtGlobal>
#include <QSettings>

class NetworkManager : public QObject
{
    Q_OBJECT
public:
    static NetworkManager* instance();
    bool connectToServer(const QString& host = "", quint16 port = 0); // 修改为可选参数
    void disconnectFromServer();
    bool isConnected() const;

    // TCP 消息发送
    void sendTcpMessage(const QString& message);

    // UDP 管理
    void bindUdp(quint16 port);
    void sendVideoFrame(const QString& receiver, const QByteArray& frameData);

    // 用户信息
    void setUsername(const QString& username);
    QString username() const;
    QStringList getFriendList() const { return m_friendList; }
    void processTcpMessage(const QByteArray& message);
    QStringList getPendingFriendRequests() const { return m_pendingFriendRequests; }
    void clearPendingFriendRequests() { m_pendingFriendRequests.clear(); }


signals:
    // TCP 相关信号
    void connected();
    void disconnected();
    void loginSuccess(const QString& nickname);
    void loginFailed(const QString& reason);
    void friendListUpdated(const QStringList& friends);
    void privateMessageReceived(const QString& sender, const QString& message);
    void avatarDataReceived(const QString& username, const QByteArray& avatarData);
    void videoRequestReceived(const QString& caller, quint16 udpPort);
    void videoPeerInfo(const QString& peer, const QString& ip, quint16 port);
    void videoRejected(const QString& receiver);
    void videoEnded(const QString& peer);
    void registerSuccess();
    void registerFailed(const QString& reason);

    // UDP 相关信号
    void videoFrameReceived(const QString& sender, const QByteArray& frameData);

    // 错误信号
    void errorOccurred(const QString& error);
    void avatarUploadSuccess();
    void avatarUploadFailed(const QString& reason);
    void searchResultReceived(const QString& username, bool found);
    void friendRequestReceived(const QString& sender); // 添加好友请求信号
    void friendRequestSent(const QString& friendUsername); // 发送好友请求成功
    void friendAdded(const QString& friendUsername); // 好友添加成功
    void friendRequestAccepted(const QString& friendUsername); // 好友请求被接受
    void requesterNicknameReceived(const QString& sender, const QString& nickname);
    void serverMessageReceived(const QString& message);
    void friendDeleted(const QString& friendName);

private:
    explicit NetworkManager(QObject *parent = nullptr);
    ~NetworkManager();


    QTcpSocket* m_tcpSocket;
    QUdpSocket* m_udpSocket;
    QString m_username;

    // TCP 消息处理状态
    bool m_waitingForHeader;
    qint64 m_expectedSize;
    QByteArray m_buffer;

    // 心跳检测
    QTimer* m_heartbeatTimer;

    // 单例实例
    static NetworkManager* m_instance;
    QStringList m_friendList; // 存储好友列表
    QStringList m_pendingFriendRequests; // 存储未处理的好友请求
};

#endif // NETWORKMANAGER_H
