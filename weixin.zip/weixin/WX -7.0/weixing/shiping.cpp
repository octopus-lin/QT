#include "shiping.h"
#include "ui_shiping.h"
#include <QCameraInfo>
#include <QScreen>
#include <QApplication>
#include <QTimer>
#include <QResizeEvent>

shiping::shiping(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::shiping)
{
    ui->setupUi(this);
    setAttribute(Qt::WA_TranslucentBackground);
    isFullScreen = false;
    isLabel2Mode = true;

    ui->centralwidget->setStyleSheet(
        "QWidget#centralwidget {"
        "  background-color: rgba(0, 0, 0, 0.7);"
        "  border-radius: 10px;"
        "  border: 1px solid rgba(0,0,0,75);"
        "}"
    );

    // 创建视频显示控件 - 初始父对象设为label_2
      videoWidget = new QVideoWidget(ui->label_2); // 修复：设置初始父对象
      videoWidget->setAspectRatioMode(Qt::IgnoreAspectRatio);
      videoWidget->setStyleSheet("border-radius: 10px;");
      videoWidget->setGeometry(0, 0, ui->label_2->width(), ui->label_2->height());

      // 连接按钮点击信号
      connect(ui->fanzhuan, &QPushButton::clicked, this, &shiping::on_fanzhuan_clicked);

      setupCamera();

      // 修复：初始显示小窗口模式
      ui->label->hide(); // 隐藏全窗口标签
      ui->label_2->show(); // 显示小窗口标签
}

void shiping::resizeEvent(QResizeEvent* event)
{
    QMainWindow::resizeEvent(event);

    qDebug() << "窗口大小变化: " << event->size();
    qDebug() << "当前模式: " << (isLabel2Mode ? "小窗口" : "全窗口");

    if (isLabel2Mode) {
        if (videoWidget->parent() == ui->label_2) {
            qDebug() << "更新小窗口尺寸: " << ui->label_2->size();
            videoWidget->setGeometry(0, 0, ui->label_2->width(), ui->label_2->height());
        }
    } else {
        if (videoWidget->parent() == ui->label) {
            qDebug() << "更新全窗口尺寸: " << ui->label->size();
            videoWidget->setGeometry(0, 0, ui->label->width(), ui->label->height());
        }
    }
}

void shiping::toggleFullscreen()
{
    if (isFullScreen) {
        // 退出全屏
        showNormal();
        // 恢复竖屏9:16比例的初始尺寸
        videoWidget->setGeometry(0, 0, 448, 798);
        ui->centralwidget->setStyleSheet(
            "QWidget#centralwidget {"
            "  background-color: rgba(0, 0, 0, 0.7);"
            "  border-radius: 10px;"
            "  border: 1px solid rgba(0,0,0,75);"
            "}"
        );
    } else {
        // 进入全屏
        showFullScreen();

        // 获取屏幕尺寸
        QScreen *screen = QApplication::primaryScreen();
        QRect screenGeometry = screen->geometry();

        // 设置视频控件为屏幕尺寸（拉伸填满窗口）
        videoWidget->setGeometry(0, 0, screenGeometry.width(), screenGeometry.height());

        // 更新背景样式（全屏时无边框）
        ui->centralwidget->setStyleSheet(
            "QWidget#centralwidget {"
            "  background-color: rgba(0, 0, 0, 0.9);" // 更深的背景
            "  border: none;" // 全屏时无边框
            "}"
        );
    }
    isFullScreen = !isFullScreen;
}

shiping::~shiping()
{
    if (camera) {
        camera->stop();
        delete camera;
    }
    delete ui;
}


void shiping::on_fanzhuan_clicked()
{
    if (isLabel2Mode) {
        // 切换到小窗口模式 (label_2)
        videoWidget->setParent(ui->label_2);
        videoWidget->setGeometry(0, 0, ui->label_2->width(), ui->label_2->height());

        ui->label->hide();
        ui->label_2->show();
        qDebug() << "切换到:" << "小窗口";
         isFullScreen = !isFullScreen;
    }
    if(!isFullScreen) {
        // 切换到全窗口模式 (label)
        videoWidget->setParent(ui->label);
        videoWidget->setGeometry(0, 0, ui->label->width(), ui->label->height());

        ui->label_2->hide();
        ui->label->show();
        qDebug() << "切换到:" << "大窗口";
        isLabel2Mode = !isLabel2Mode;
    }

    // 确保按钮在视频控件上方
    ui->fanzhuan->raise();
}

// 修改相机设置函数
void shiping::setupCamera()
{
    const QList<QCameraInfo> cameras = QCameraInfo::availableCameras();
    if (cameras.isEmpty()) {
        qDebug() << "未找到摄像头";
        return;
    }

    camera = new QCamera(cameras.first());
    camera->setViewfinder(videoWidget);

    // 确保在视频控件附加到父对象后启动相机
    QTimer::singleShot(100, [this]() {
        camera->start();
        qDebug() << "相机启动";
    });
}
