#ifndef SHEZHI_H
#define SHEZHI_H

#include <QMainWindow>
#include "myhome.h"

namespace Ui {
class shezhi;
}

class shezhi : public QMainWindow
{
    Q_OBJECT

public:
    explicit shezhi(QWidget *parent = nullptr);
    ~shezhi();
    void setUsername(const QString& username);
    void updateTouxiangLabel(const QPixmap &newAvatar);
    QString getCurrentNickname() const;

public slots:
    void updateNickname(const QString& newNickname);



signals:
    void windowClosed();  // 关闭信号
    void requestBackToMainWindow();

protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
private slots:
    void on_close_clicked();
    void on_exit_s_clicked();
    QPixmap createRoundedPixmap(const QPixmap &source, int radius);

    void on_no_clicked();

    void on_yes_clicked();

private:
    Ui::shezhi *ui;
    QPoint m_dragPosition;
};

#endif // SHEZHI_H
