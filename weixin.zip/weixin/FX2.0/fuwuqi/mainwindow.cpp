#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDateTime>
#include <QMessageBox>
#include <QScrollBar>
#include <QSqlQuery>
#include <QSqlError>
#include <QCryptographicHash>
#include <QBuffer>
#include <QFile>
#include <QPixmap>
#include <QSqlRecord>
#include <QStandardItem>
#include <QListView>
#include <QInputDialog>
#include <QTimer>
#include <QNetworkInterface>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , tcpServer(new QTcpServer(this))
    , udpServer(new QUdpSocket(this))  // 初始化UDP服务器
    , tcpPort(8888)  // 默认TCP端口
    , udpPort(8890)  // 默认UDP端口
{
    ui->setupUi(this);

    // 设置UI样式
    this->setStyleSheet(
                "QMainWindow { background-color: #2c3e50; }"
                "QGroupBox { background-color: #34495e; border: 2px solid #3498db; border-radius: 8px; margin-top: 1ex; }"
                "QGroupBox::title { color: #ecf0f1; subcontrol-origin: margin; left: 10px; padding: 0 3px; }"
                "QListWidget { background-color: #2c3e50; color: #ecf0f1; border: 1px solid #3498db; border-radius: 4px; }"
                "QLineEdit, QTextEdit { background-color: #2c3e50; color: #ecf0f1; border: 1px solid #3498db; border-radius: 4px; padding: 5px; }"
                "QPushButton { background-color: #3498db; color: white; border: none; border-radius: 4px; padding: 8px; font-weight: bold; }"
                "QPushButton:hover { background-color: #2980b9; }"
                "QPushButton#clearDbButton { background-color: #e74c3c; }"
                "QPushButton#clearDbButton:hover { background-color: #c0392b; }"
                "QLabel { color: #ecf0f1; }"
                "QTableView { background-color: #2c3e50; color: #ecf0f1; border: 1px solid #3498db; border-radius: 4px; gridline-color: #3498db; }"
                "QHeaderView::section { background-color: #3498db; color: white; padding: 4px; }"
                );

    this->setWindowTitle("高级聊天服务器");
    this->setWindowIcon(QIcon(":/icons/server.png"));

    // 初始化好友模型
    friendsModel = new QStandardItemModel(this);
    friendsModel->setHorizontalHeaderLabels(QStringList() << "好友关系");
    ui->friendsTableView->setModel(friendsModel);
    ui->friendsTableView->horizontalHeader()->setStretchLastSection(true);

    initDatabase();

    connect(tcpServer, &QTcpServer::newConnection, this, &MainWindow::newConnection);

    // 设置在线用户列表
    ui->onlineUsersList->setStyleSheet(
                "QListWidget { background-color: #2c3e50; color: #ecf0f1; border: 1px solid #3498db; border-radius: 4px; }"
                "QListWidget::item { padding: 5px; }"
                "QListWidget::item:selected { background-color: #3498db; color: white; }"
                );
    ui->ipLineEdit->setText(getLocalIP());
    ui->tcpPortEdit->setText(QString::number(tcpPort));
    ui->udpPortEdit->setText(QString::number(udpPort));

    // 连接应用端口按钮
    connect(ui->applyPortButton, &QPushButton::clicked,
            this, &MainWindow::on_applyPortButton_clicked);

    initDatabase();
    startServers(); // 启动服务器
}

MainWindow::~MainWindow()
{
    foreach (QTcpSocket *socket, clientSockets) {
        socket->disconnectFromHost();
        if (socket->state() != QAbstractSocket::UnconnectedState) {
            socket->waitForDisconnected(1000);
        }
        socket->deleteLater(); // 安全删除
    }

    if (tcpServer->isListening()) {
        tcpServer->close();
    }

    if (db.isOpen()) {
        db.close();
    }

    delete ui;
}


bool MainWindow::removeFriend(const QString &user1, const QString &user2)
{
    if (user1.isEmpty() || user2.isEmpty() || user1 == user2) {
        return false;
    }

    QSqlDatabase::database().transaction();
    QSqlQuery query;
    bool success = true;

    // 删除正向好友关系
    query.prepare("DELETE FROM friends WHERE (user1 = :user1 AND user2 = :user2)");
    query.bindValue(":user1", user1);
    query.bindValue(":user2", user2);
    if (!query.exec()) {
        addMessage("❌ 删除好友失败: " + query.lastError().text());
        success = false;
    }

    // 删除反向好友关系
    if (success) {
        query.prepare("DELETE FROM friends WHERE (user1 = :user2 AND user2 = :user1)");
        query.bindValue(":user1", user2);
        query.bindValue(":user2", user1);
        if (!query.exec()) {
            addMessage("❌ 删除反向好友关系失败: " + query.lastError().text());
            success = false;
        }
    }


    if (success) {
        QSqlDatabase::database().commit();
        return true;
    } else {
        QSqlDatabase::database().rollback();
        return false;
    }
}

// 新增函数：获取本地IP地址
QString MainWindow::getLocalIP()
{
    QString ipAddress;
    QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();

    // 优先获取IPv4地址
    for (const QHostAddress &address : qAsConst(ipAddressesList)) {
        if (address != QHostAddress::LocalHost &&
                address.protocol() == QAbstractSocket::IPv4Protocol) {
            ipAddress = address.toString();
            break;
        }
    }

    // 如果没有找到非本地IPv4地址，则使用本地主机地址
    if (ipAddress.isEmpty())
        ipAddress = QHostAddress(QHostAddress::LocalHost).toString();

    return ipAddress;
}


void MainWindow::startServers()
{
    // 关闭现有服务器
    if (tcpServer->isListening()) {
        tcpServer->close();
    }
    // 关闭并重置UDP服务器
    if (udpServer->state() == QUdpSocket::BoundState) {
        udpServer->close();
        disconnect(udpServer, &QUdpSocket::readyRead, this, &MainWindow::readUdpData);
    }

    // 启动TCP服务器
    if (!tcpServer->listen(QHostAddress::Any, tcpPort)) {
        QMessageBox::critical(this, "服务器错误",
                              "无法启动TCP服务器: " + tcpServer->errorString());
    } else {
        addMessage(QString("✅ TCP服务器已启动，监听端口: %1").arg(tcpPort));
    }

    // 启动UDP服务器
    if (!udpServer->bind(QHostAddress::Any, udpPort)) {
        QMessageBox::critical(this, "UDP错误",
                              "无法启动UDP服务器: " + udpServer->errorString());
    } else {
        addMessage(QString("✅ UDP服务器已启动，监听端口: %1").arg(udpPort));
        connect(udpServer, &QUdpSocket::readyRead,
                this, &MainWindow::readUdpData);
    }

    // 更新窗口标题显示IP和端口
    this->setWindowTitle(QString("高级聊天服务器 - %1:%2/%3")
                         .arg(ui->ipLineEdit->text())
                         .arg(tcpPort)
                         .arg(udpPort));
}

// 新增槽函数：应用端口设置
void MainWindow::on_applyPortButton_clicked()
{
    bool tcpOk, udpOk;
    quint16 newTcpPort = ui->tcpPortEdit->text().toUShort(&tcpOk);
    quint16 newUdpPort = ui->udpPortEdit->text().toUShort(&udpOk);

    if (!tcpOk || !udpOk) {
        QMessageBox::warning(this, "端口错误", "端口号必须是1-65535之间的整数");
        return;
    }

    if (newTcpPort == newUdpPort) {
        QMessageBox::warning(this, "端口错误", "TCP和UDP端口不能相同");
        return;
    }

    // 断开所有客户端连接
    foreach (QTcpSocket *socket, clientSockets) {
        socket->disconnectFromHost();
    }

    // 更新端口
    tcpPort = newTcpPort;
    udpPort = newUdpPort;

    // 重启服务器
    startServers();

    addMessage(QString("🔄 端口已更新: TCP=%1, UDP=%2").arg(tcpPort).arg(udpPort));
}

bool MainWindow::areFriends(const QString &user1, const QString &user2)
{
    QSqlQuery query;
    query.prepare("SELECT COUNT(*) FROM friends "
                  "WHERE (user1 = :user1 AND user2 = :user2) "
                  "OR (user1 = :user2 AND user2 = :user1)");
    query.bindValue(":user1", user1);
    query.bindValue(":user2", user2);

    if (query.exec() && query.next()) {
        return query.value(0).toInt() > 0;
    }
    return false;
}

void MainWindow::resendPendingFriendRequests(const QString &username)
{
    QSqlQuery query;
    query.prepare("SELECT requester FROM friend_requests WHERE receiver = :receiver");
    query.bindValue(":receiver", username);

    if (query.exec()) {
        while (query.next()) {
            QString requester = query.value(0).toString();

            // 添加日志：重新发送好友请求
            addMessage("📩 重新发送好友请求: " + requester + " → " + username);

            // 发送好友请求通知
            sendTextToClient(onlineUsers.value(username), "FRIEND_REQUEST:" + requester);

            // 发送请求方的昵称
            QString nickname = getNickname(requester);
            sendTextToClient(onlineUsers.value(username), "REQUESTER_NICKNAME:" + requester + ":" + nickname);
        }
    } else {
        addMessage("❌ 查询待处理好友请求失败: " + query.lastError().text());
    }
}

void MainWindow::updateFriendListForUser(const QString &username)
{
    addMessage("🔄 更新好友列表: " + username);
    // 如果用户在线，立即更新好友列表
    if (onlineUsers.contains(username)) {
        QTcpSocket *socket = onlineUsers.value(username);
        sendFriendList(socket, username);
    }
    // 如果用户离线，标记需要更新
    else {
        QSqlQuery query;
        query.prepare("INSERT OR IGNORE INTO pending_friend_updates "
                      "(username) VALUES (:username)");
        query.bindValue(":username", username);
        query.exec();
    }
}

// 添加UDP数据处理函数
void MainWindow::readUdpData()
{
    while (udpServer->hasPendingDatagrams()) {
        QByteArray datagram;
        datagram.resize(udpServer->pendingDatagramSize());
        QHostAddress senderAddr;
        quint16 senderPort;

        udpServer->readDatagram(datagram.data(), datagram.size(), &senderAddr, &senderPort);

        // 视频数据转发逻辑
        QString dataStr = QString::fromUtf8(datagram);
        if (dataStr.startsWith("VIDEO_DATA:")) {
            QStringList parts = dataStr.split(':', Qt::SkipEmptyParts);
            if (parts.size() >= 3) {
                QString sender = parts[1];
                QString receiver = parts[2];

                // 添加调试信息
                addMessage(QString("📹 收到来自 %1 给 %2 的视频包，大小: %3 字节")
                           .arg(sender).arg(receiver).arg(datagram.size()));

                if (activeVideoCalls.contains(sender) && activeVideoCalls[sender].receiver == receiver) {
                    VideoCall call = activeVideoCalls[sender];
                    QByteArray forwardData = datagram;

                    // 添加调试信息
                    addMessage(QString("📹 转发视频包到 %1:%2 (接收方)")
                               .arg(call.receiverAddr.toString()).arg(call.receiverUdpPort));

                    qint64 bytesSent = udpServer->writeDatagram(forwardData,
                                                                call.receiverAddr,
                                                                call.receiverUdpPort);

                    // 添加发送结果调试
                    if (bytesSent == -1) {
                        addMessage("❌ 视频转发失败: " + udpServer->errorString());
                    } else {
                        addMessage(QString("✅ 视频转发成功: %1 字节").arg(bytesSent));
                    }
                }
            }
        }
    }
}

void MainWindow::initDatabase()
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("server_users.db");

    if (!db.open()) {
        QMessageBox::critical(this, "数据库错误", "无法打开数据库: " + db.lastError().text());
        return;
    }

    QSqlQuery query;
    bool success; // 声明变量
    QSqlQuery uniqueQuery;

    success = query.exec(
        "CREATE TABLE IF NOT EXISTS friends ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "user1 TEXT NOT NULL, "
        "user2 TEXT NOT NULL, "
        "created_at DATETIME DEFAULT CURRENT_TIMESTAMP, "
        "UNIQUE(user1, user2), "
        "FOREIGN KEY(user1) REFERENCES users(username) ON DELETE CASCADE, "
        "FOREIGN KEY(user2) REFERENCES users(username) ON DELETE CASCADE"
    );


    // 创建离线消息表
    success = query.exec(
                "CREATE TABLE IF NOT EXISTS offline_messages ("
                "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "receiver TEXT NOT NULL, "
                "sender TEXT NOT NULL, "
                "message TEXT NOT NULL, "
                "created_at DATETIME DEFAULT CURRENT_TIMESTAMP)"
                );

    if (!success) {
        QMessageBox::critical(this, "数据库错误", "创建离线消息表失败: " + query.lastError().text());
    }


    uniqueQuery.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_pending_updates_unique "
                     "ON pending_friend_updates(username, new_friend)");

    query.exec("CREATE TABLE IF NOT EXISTS pending_friend_updates ("
               "username TEXT PRIMARY KEY)");
    // 创建好友请求表
    success = query.exec(
                "CREATE TABLE IF NOT EXISTS pending_friend_updates ("
                "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "username TEXT NOT NULL, "
                "new_friend TEXT NOT NULL, "
                "created_at DATETIME DEFAULT CURRENT_TIMESTAMP)"
                );

    if (!success) {
        QMessageBox::critical(this, "数据库错误", "创建好友请求表失败: " + query.lastError().text());
    }

    // 添加好友请求表
    success = query.exec(
                "CREATE TABLE IF NOT EXISTS friend_requests ("
                "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "requester TEXT NOT NULL, "
                "receiver TEXT NOT NULL, "
                "created_at DATETIME DEFAULT CURRENT_TIMESTAMP, "
                "UNIQUE(requester, receiver))"
                );

    if (!success) {
        QMessageBox::critical(this, "数据库错误", "创建好友请求表失败: " + query.lastError().text());
    }

    // 创建用户表
    success = query.exec(
                "CREATE TABLE IF NOT EXISTS users ("
                "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "username TEXT UNIQUE NOT NULL, "
                "password TEXT NOT NULL, "
                "avatar BLOB, "
                "created_at DATETIME DEFAULT CURRENT_TIMESTAMP)"
                );

    if (!success) {
        QMessageBox::critical(this, "数据库错误", "创建用户表失败: " + query.lastError().text());
    }

    // 创建好友关系表
    success = query.exec(
                "CREATE TABLE IF NOT EXISTS friends ("
                "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "user1 TEXT NOT NULL, "
                "user2 TEXT NOT NULL, "
                "created_at DATETIME DEFAULT CURRENT_TIMESTAMP, "
                "UNIQUE(user1, user2))"
                );

    if (!success) {
        QMessageBox::critical(this, "数据库错误", "创建好友表失败: " + query.lastError().text());
    }

    // 检查并添加avatar列
    if (!db.record("users").contains("avatar")) {
        if (!query.exec("ALTER TABLE users ADD COLUMN avatar BLOB")) {
            QMessageBox::warning(this, "数据库警告", "添加头像列失败: " + query.lastError().text());
        }
    }
    // 检查并添加nickname列
    if (!db.record("users").contains("nickname")) {
        if (!query.exec("ALTER TABLE users ADD COLUMN nickname TEXT DEFAULT ''")) {
            QMessageBox::warning(this, "数据库警告", "添加昵称列失败: " + query.lastError().text());
        }
    }

    addMessage("✅ 数据库初始化成功");
}

bool MainWindow::registerUser(const QString &username, const QString &password, const QString &nickname)
{
    if (username.isEmpty() || password.isEmpty()) {
        return false;
    }

    QByteArray hashedPassword = QCryptographicHash::hash(
                password.toUtf8(),
                QCryptographicHash::Sha256
                ).toHex();

    QSqlQuery query;
    query.prepare("INSERT INTO users (username, password, nickname) VALUES (:username, :password, :nickname)");
    query.bindValue(":username", username);
    query.bindValue(":password", hashedPassword);
    query.bindValue(":nickname", nickname);

    if (!query.exec()) {
        addMessage("❌ 注册失败: " + query.lastError().text());
        return false;
    }

    return true;
}

bool MainWindow::authenticateUser(const QString &username, const QString &password)
{
    if (username.isEmpty() || password.isEmpty()) {
        return false;
    }

    QByteArray hashedPassword = QCryptographicHash::hash(
                password.toUtf8(),
                QCryptographicHash::Sha256
                ).toHex();

    QSqlQuery query;
    query.prepare("SELECT password FROM users WHERE username = :username");
    query.bindValue(":username", username);

    if (!query.exec()) {
        addMessage("❌ 查询失败: " + query.lastError().text());
        return false;
    }

    if (query.next()) {
        QString storedPassword = query.value(0).toString();
        return (storedPassword == hashedPassword);
    }

    return false;
}

bool MainWindow::uploadAvatar(const QString &username, const QByteArray &avatarData)
{
    if (username.isEmpty() || avatarData.isEmpty()) {
        return false;
    }

    QSqlQuery query;
    query.prepare("UPDATE users SET avatar = :avatar WHERE username = :username");
    query.bindValue(":avatar", avatarData);
    query.bindValue(":username", username);

    if (!query.exec()) {
        addMessage("❌ 头像上传失败: " + query.lastError().text());
        return false;
    }

    return true;
}

QByteArray MainWindow::downloadAvatar(const QString &username)
{
    if (username.isEmpty()) {
        return QByteArray();
    }

    QSqlQuery query;
    query.prepare("SELECT avatar FROM users WHERE username = :username");
    query.bindValue(":username", username);

    if (!query.exec()) {
        addMessage("❌ 头像查询失败: " + query.lastError().text());
        return QByteArray();
    }

    if (query.next()) {
        return query.value(0).toByteArray();
    }

    return QByteArray();
}

bool MainWindow::addFriend(const QString &user1, const QString &user2)
{
    if (user1.isEmpty() || user2.isEmpty() || user1 == user2) {
        return false;
    }

    QSqlDatabase::database().transaction();
    QSqlQuery query;
    bool success = true;

    // 主方向
    query.prepare("INSERT OR IGNORE INTO friends (user1, user2) VALUES (:user1, :user2)");
    query.bindValue(":user1", user1);
    query.bindValue(":user2", user2);
    if (!query.exec()) {
        addMessage("❌ 添加好友失败: " + query.lastError().text());
        success = false;
    }

    // 反方向 (修复占位符错误)
    if (success) {
        query.prepare("INSERT OR IGNORE INTO friends (user1, user2) VALUES (:user1, :user2)");
        query.bindValue(":user1", user2);  // 正确绑定
        query.bindValue(":user2", user1);  // 正确绑定
        if (!query.exec()) {
            addMessage("❌ 添加反向好友关系失败: " + query.lastError().text());
            success = false;
        }
    }

    if (success) {
        QSqlDatabase::database().commit();
        return true;
    } else {
        QSqlDatabase::database().rollback();
        return false;
    }
}

QList<QString> MainWindow::getFriends(const QString &username)
{
    QList<QString> friendsList;

    if (username.isEmpty()) {
        return friendsList;
    }

    QSqlQuery query;
    query.prepare(
                "SELECT DISTINCT "
                "CASE WHEN user1 = :username THEN user2 ELSE user1 END AS friend "
                "FROM friends "
                "WHERE user1 = :username OR user2 = :username"
                );
    query.bindValue(":username", username);

    if (!query.exec()) {
        addMessage("❌ 获取好友列表失败: " + query.lastError().text());
        return friendsList;
    }

    while (query.next()) {
        friendsList.append(query.value(0).toString());
    }

    return friendsList;
}

void MainWindow::sendFriendList(QTcpSocket *socket, const QString &username)
{
    QList<QString> friends = getFriends(username);
    QString friendList = "FRIEND_LIST:";

    foreach (const QString &friendName, friends) {
        QString nickname = getNickname(friendName);
        friendList += friendName + "|" + nickname + ","; // 使用|分隔用户名和昵称
    }

    if (friends.size() > 0) {
        friendList.chop(1); // 移除最后一个逗号
    }

    // 添加调试信息
    addMessage("📤 发送好友列表给 " + username + ": " + friendList);

    sendTextToClient(socket, friendList);
}

void MainWindow::sendOnlineNotification(const QString &username, bool isOnline)
{
    QString message = isOnline ? "ONLINE:" + username : "OFFLINE:" + username;

    // 通知所有在线用户
    foreach (QTcpSocket *socket, clientSockets) {
        if (socket->state() == QTcpSocket::ConnectedState) {
            sendTextToClient(socket, message);
        }
    }

    updateOnlineUsersList();
    QMetaObject::invokeMethod(this, [this]() {
        updateOnlineUsersList();
    }, Qt::QueuedConnection);
}

void MainWindow::sendPrivateMessage(const QString &sender, const QString &receiver, const QString &message)
{
    if (onlineUsers.contains(receiver)) {
        QTcpSocket *receiverSocket = onlineUsers.value(receiver);

        // 添加调试信息
        addMessage(QString("📤 转发私聊消息: %1 -> %2 (socket: %3:%4)")
                   .arg(sender)
                   .arg(receiver)
                   .arg(receiverSocket->peerAddress().toString())
                   .arg(receiverSocket->peerPort()));

        sendTextToClient(receiverSocket, "PRIVATE_MSG:" + sender + ":" + message);
    } else {
        // 记录详细的错误信息
        addMessage(QString("❌ 用户 %1 不在线，当前在线用户: %2")
                   .arg(receiver)
                   .arg(onlineUsers.keys().join(", ")));

        storeOfflineMessage(sender, receiver, message);
    }
}

void MainWindow::updateOnlineUsersList()
{
    ui->onlineUsersList->clear();
    foreach (const QString &user, onlineUsers.keys()) {
        ui->onlineUsersList->addItem("🟢 " + user);
    }
}

void MainWindow::newConnection()
{
    while (tcpServer->hasPendingConnections()) {
        QTcpSocket *clientSocket = tcpServer->nextPendingConnection();
        clientSockets.append(clientSocket);
        clientUsers.insert(clientSocket, "Unknown");

        QString clientInfo = QString("%1:%2")
                .arg(clientSocket->peerAddress().toString())
                .arg(clientSocket->peerPort());

        addMessage("🔌 新客户端连接: " + clientInfo);

        connect(clientSocket, &QTcpSocket::readyRead, this, &MainWindow::readData);
        connect(clientSocket, &QTcpSocket::disconnected, this, &MainWindow::clientDisconnected);
    }
}

void MainWindow::readData()
{
    QTcpSocket *clientSocket = qobject_cast<QTcpSocket*>(sender());
    if (!clientSocket) return;

    static QHash<QTcpSocket*, QByteArray> buffers;
    static QHash<QTcpSocket*, qint64> expectedSizes;

    while (clientSocket->bytesAvailable() > 0) {
        if (!expectedSizes.contains(clientSocket)) {
            // 等待长度头
            if (clientSocket->bytesAvailable() < 8) return;

            QByteArray sizeData = clientSocket->read(8);
            bool ok;
            qint64 size = sizeData.toLongLong(&ok);

            if (!ok || size <= 0) {
                addMessage("❌ 无效数据长度头");
                clientSocket->disconnectFromHost();
                return;
            }

            expectedSizes[clientSocket] = size;
            buffers[clientSocket] = QByteArray();
        }

        // 读取剩余数据
        qint64 bytesToRead = qMin(
                    clientSocket->bytesAvailable(),
                    expectedSizes[clientSocket] - buffers[clientSocket].size()
                    );

        buffers[clientSocket] += clientSocket->read(bytesToRead);

        // 检查是否完成
        if (buffers[clientSocket].size() == expectedSizes[clientSocket]) {
            // 处理完整消息
            QString message = QString::fromUtf8(buffers[clientSocket]);
            processClientMessage(clientSocket, message); // 将原处理逻辑移至此函数

            // 重置状态
            expectedSizes.remove(clientSocket);
            buffers.remove(clientSocket);
        }
    }
}

// 修改 sendOfflineMessages 函数
void MainWindow::sendOfflineMessages(QTcpSocket* socket, const QString& username)
{
    QSqlQuery query;
    query.prepare("SELECT id, sender, message FROM offline_messages "
                      "WHERE receiver = :receiver ORDER BY created_at DESC"); // 改为 DESC
    query.bindValue(":receiver", username);

    if (query.exec()) {
        int messageCount = 0;
        while (query.next()) {
            int messageId = query.value(0).toInt();
            QString sender = query.value(1).toString();
            QString message = query.value(2).toString();

            // 添加离线消息标识
            QString offlineMsg = QString("OFFLINE_MSG:%1:%2").arg(sender).arg(message);

            // 添加日志：准备发送离线消息
            addMessage(QString("📩 准备发送离线消息给 %1 (来自 %2)").arg(username).arg(sender));

            // 使用定时器实现延迟发送 (1秒延迟)
            QTimer::singleShot(1000, this, [=]() {
                if (socket && socket->state() == QTcpSocket::ConnectedState) {
                    // 添加发送日志
                    addMessage(QString("✅ 发送离线消息给 %1: %2 -> %3")
                               .arg(username).arg(sender).arg(message));

                    sendTextToClient(socket, offlineMsg);

                    // 标记消息为已发送
                    QSqlQuery deleteQuery;
                    deleteQuery.prepare("DELETE FROM offline_messages WHERE id = :id");
                    deleteQuery.bindValue(":id", messageId);
                    if (!deleteQuery.exec()) {
                        addMessage("❌ 删除已发送的离线消息失败: " + deleteQuery.lastError().text());
                    }
                }
            });

            messageCount++;
        }

        if (messageCount > 0) {
            addMessage(QString("📬 %1 有 %2 条待处理的离线消息").arg(username).arg(messageCount));
        }
    } else {
        addMessage("❌ 查询离线消息失败: " + query.lastError().text());
    }
}
// 新增函数，处理完整消息
void MainWindow::processClientMessage(QTcpSocket* clientSocket, const QString& message)
{
    QString response;
    QString clientInfo = QString("%1:%2")
            .arg(clientSocket->peerAddress().toString())
            .arg(clientSocket->peerPort());

    addMessage("📩 [" + clientInfo + "]: " + message);

    if (message.startsWith("REGISTER:")) {
        QStringList parts = message.mid(9).split(",");
        if (parts.size() >= 2) {
            QString username = parts[0].trimmed();
            QString password = parts[1].trimmed();
            QString nickname = parts.size() > 2 ? parts[2].trimmed() : username;

            if (registerUser(username, password, nickname)) {
                clientUsers[clientSocket] = username;
                response = "REGISTER_SUCCESS:用户注册成功";
                addMessage("🎉 新用户注册: " + username);
            } else {
                response = "REGISTER_FAILED:用户注册失败，可能用户名已存在";
            }
        } else {
            response = "ERROR:无效的注册格式，请使用 REGISTER:username,password";
        }
    }

    else if (message.startsWith("DELETE_FRIEND:")) {
        QString friendToDelete = message.mid(14).trimmed();
        QString currentUser = clientUsers.value(clientSocket, "");

        if (currentUser.isEmpty()) {
            response = "FRIEND_DELETE_ERROR:请先登录";
        } else if (currentUser == friendToDelete) {
            response = "FRIEND_DELETE_ERROR:不能删除自己";
        } else {
            // 检查是否为好友
            if (!areFriends(currentUser, friendToDelete)) {
                response = "FRIEND_DELETE_ERROR:对方不是您的好友";
            } else {
                // 执行删除操作
                if (removeFriend(currentUser, friendToDelete)) {
                    response = "FRIEND_DELETED_SUCCESS:" + friendToDelete;
                    addMessage("🗑️ 删除好友: " + currentUser + " -> " + friendToDelete);

                    // 更新双方好友列表
                    updateFriendListForUser(currentUser);
                    updateFriendListForUser(friendToDelete);

                    // 通知对方（如果在线）
                    if (onlineUsers.contains(friendToDelete)) {
                        QTcpSocket* friendSocket = onlineUsers[friendToDelete];
                        sendTextToClient(friendSocket, "FRIEND_REMOVED:" + currentUser);
                        sendFriendList(friendSocket, friendToDelete);
                    }
                } else {
                    response = "FRIEND_DELETE_ERROR:删除失败";
                }
            }
        }
    }
    else if (message.startsWith("VIDEO_CALL:")) {
        QStringList parts = message.mid(11).split(':');
        if (parts.size() >= 4) {  // 确保有足够的部分
            QString sender = clientUsers.value(clientSocket, "");
            QString receiver = parts[0];
            QString action = parts[1];
            quint16 udpPort = parts[2].toUShort();  // 获取UDP端口

            if (sender.isEmpty()) {
                response = "VIDEO_ERROR:请先登录";
            } else if (action == "REQUEST") {
                handleVideoCallRequest(sender, receiver, clientSocket);
            } else if (action == "ACCEPT") {
                if (activeVideoCalls.contains(receiver)) {
                    VideoCall &call = activeVideoCalls[receiver];
                    call.receiverAddr = clientSocket->peerAddress();
                    call.receiverUdpPort = udpPort;  // 存储接收方UDP端口

                    // 更新接收方信息
                    activeVideoCalls[call.receiver] = call;

                    // 通知双方
                    sendTextToClient(clientSocket,
                                     "VIDEO_PEER:" + call.initiator + ":" +
                                     call.initiatorAddr.toString() + ":" +
                                     QString::number(call.initiatorUdpPort));

                    if (onlineUsers.contains(call.initiator)) {
                        sendTextToClient(onlineUsers[call.initiator],
                                "VIDEO_PEER:" + call.receiver + ":" +
                                call.receiverAddr.toString() + ":" +
                                QString::number(call.receiverUdpPort));
                    }

                    addMessage("📹 视频通话建立: " + call.initiator + " ↔ " + call.receiver);
                }
            }
            else if (action == "REJECT") {
                if (activeVideoCalls.contains(receiver) && activeVideoCalls[receiver].receiver == sender) {
                    endVideoCall(receiver);
                    if (onlineUsers.contains(activeVideoCalls[receiver].initiator)) {
                        sendTextToClient(onlineUsers[activeVideoCalls[receiver].initiator],
                                "VIDEO_REJECTED:" + sender);
                    }
                }
            } else if (action == "END") {
                endVideoCall(sender);
                if (onlineUsers.contains(receiver)) {
                    sendTextToClient(onlineUsers[receiver], "VIDEO_ENDED:" + sender);
                }
            }
        }
    }
    else if (message.startsWith("LOGIN:")) {

        // 正确定义 parts 变量
        QStringList parts = message.mid(6).split(',');
        if (parts.size() == 2) {
            QString username = parts[0].trimmed();
            QString password = parts[1].trimmed();

            if (authenticateUser(username, password)) {

                if (onlineUsers.contains(username)) {
                    QTcpSocket* oldSocket = onlineUsers.value(username);
                    if (oldSocket != clientSocket) {
                        oldSocket->disconnectFromHost();
                    }
                }
                clientUsers[clientSocket] = username;
                onlineUsers[username] = clientSocket;
                sendOfflineMessages(clientSocket, username);
                resendPendingFriendRequests(username);
                QSqlQuery requestQuery;
                requestQuery.prepare("SELECT requester FROM friend_requests WHERE receiver = :receiver");
                requestQuery.bindValue(":receiver", username);
                if (requestQuery.exec()) {
                    while (requestQuery.next()) {
                        QString requester = requestQuery.value(0).toString();

                        // 发送好友请求通知
                        sendTextToClient(clientSocket, "FRIEND_REQUEST:" + requester);

                        // 发送请求方的昵称
                        QString nickname = getNickname(requester);
                        sendTextToClient(clientSocket, "REQUESTER_NICKNAME:" + requester + ":" + nickname);
                    }
                }

                QString nickname = getNickname(username);
                clientUsers[clientSocket] = username;
                onlineUsers[username] = clientSocket;
                sendOnlineNotification(username, true);
                response = "LOGIN_SUCCESS:" + nickname; // 返回昵称

                // 检查并发送待处理的好友更新
                QSqlQuery pendingQuery;
                pendingQuery.prepare("SELECT username FROM pending_friend_updates "
                                     "WHERE username = :username");
                pendingQuery.bindValue(":username", username);

                if (pendingQuery.exec() && pendingQuery.next()) {
                    // 删除待更新标记
                    QSqlQuery deleteQuery;
                    deleteQuery.prepare("DELETE FROM pending_friend_updates "
                                        "WHERE username = :username");
                    deleteQuery.bindValue(":username", username);
                    deleteQuery.exec();

                    // 发送更新后的好友列表
                    sendFriendList(clientSocket, username);
                }
                // 延迟发送好友列表，确保客户端准备好
                QTimer::singleShot(100, this, [this, clientSocket, username]() {
                    sendFriendList(clientSocket, username); // 延迟发送好友列表
                });

                // 发送头像（单一消息）
                QByteArray avatarData = downloadAvatar(username);
                if (!avatarData.isEmpty()) {
                    // 将二进制数据转为Base64编码
                    QByteArray base64Data = avatarData.toBase64();

                    // 构建包含Base64数据的协议头
                    QString header = QString("AVATAR_DATA_BASE64:%1:%2:").arg(username).arg(base64Data.size());

                    // 拼接协议头和Base64数据
                    QByteArray avatarMsg = header.toUtf8() + base64Data;

                    // 发送消息
                    sendDataToClient(clientSocket, avatarMsg);
                } else {
                    sendTextToClient(clientSocket, "AVATAR_NOT_FOUND:" + username);
                }

                addMessage("👤 用户登录: " + username);
                QTimer::singleShot(1000, this, [this, clientSocket, username]() {
                    sendOfflineMessages(clientSocket, username);
                });
            } else {
                response = "LOGIN_FAILED:用户名或密码错误";
            }
        } else {
            response = "ERROR:无效的登录格式，请使用 LOGIN:username,password";
        }
    }
    else if (message.startsWith("UPLOAD_AVATAR:")) {
        QString username = clientUsers.value(clientSocket, "");
        if (username.isEmpty()) {
            response = "AVATAR_UPLOAD_FAILED:请先登录";
        } else {
            QString base64Data = message.mid(13);
            QByteArray avatarData = QByteArray::fromBase64(base64Data.toUtf8());

            if (avatarData.size() > 1024 * 1024) {
                response = "AVATAR_UPLOAD_FAILED:头像大小超过1MB限制";
            } else if (uploadAvatar(username, avatarData)) {
                response = "AVATAR_UPLOAD_SUCCESS:头像上传成功";
                addMessage("🖼️ 用户头像已更新: " + username);
            } else {
                response = "AVATAR_UPLOAD_FAILED:头像上传失败";
            }
        }
    }
    else if (message.startsWith("REQUEST_AVATAR:")) {
        QString requestedUser = message.mid(15).trimmed();
        QByteArray avatarData = downloadAvatar(requestedUser);

        if (!avatarData.isEmpty()) {
            // 将二进制数据转为Base64编码
            QByteArray base64Data = avatarData.toBase64();

            // 构建包含Base64数据的协议头
            QString header = QString("AVATAR_DATA_BASE64:%1:%2:").arg(requestedUser).arg(base64Data.size());
            // 拼接协议头和Base64数据
            QByteArray avatarMsg = header.toUtf8() + base64Data;

            // 发送消息
            sendDataToClient(clientSocket, avatarMsg);
        } else {
            sendTextToClient(clientSocket, "AVATAR_NOT_FOUND:" + requestedUser);
        }

    }
    else if (message.startsWith("SEARCH_USER:")) {
        QString searchTerm = message.mid(12).trimmed();
        QSqlQuery query;
        query.prepare("SELECT username FROM users WHERE username = :term");
        query.bindValue(":term", searchTerm);

        if (query.exec()) {
            if (query.next()) {
                sendTextToClient(clientSocket, "SEARCH_FOUND:" + query.value(0).toString());
            } else {
                sendTextToClient(clientSocket, "SEARCH_NOT_FOUND:" + searchTerm);
            }
        } else {
            sendTextToClient(clientSocket, "SEARCH_ERROR:" + query.lastError().text());
        }
    }
    // ... 在 ADD_FRIEND: 处理逻辑中添加更多日志 ...
    else if (message.startsWith("ADD_FRIEND:")) {
        QString currentUser = clientUsers.value(clientSocket, "");
        QString friendToAdd = message.mid(11).trimmed();

        if (currentUser.isEmpty()) {
            response = "FRIEND_ERROR:请先登录";
        } else if (currentUser == friendToAdd) {
            response = "FRIEND_ERROR:不能添加自己为好友";
        } else {
            // 检查用户是否存在
            QSqlQuery existQuery;
            existQuery.prepare("SELECT COUNT(*) FROM users WHERE username = :username");
            existQuery.bindValue(":username", friendToAdd);

            if (existQuery.exec() && existQuery.next()) {
                int count = existQuery.value(0).toInt();
                if (count > 0) {
                    // 检查是否已是好友
                    QSqlQuery friendQuery;
                    friendQuery.prepare("SELECT COUNT(*) FROM friends "
                                        "WHERE (user1 = :user1 AND user2 = :user2) "
                                        "OR (user1 = :user2 AND user2 = :user1)");
                    friendQuery.bindValue(":user1", currentUser);
                    friendQuery.bindValue(":user2", friendToAdd);

                    bool alreadyFriends = false;
                    if (friendQuery.exec() && friendQuery.next()) {
                        alreadyFriends = (friendQuery.value(0).toInt() > 0);
                    }

                    if (alreadyFriends) {
                        response = "FRIEND_ERROR:已经是好友";
                    } else {
                        // 存储好友请求
                        QSqlQuery insertQuery;
                        insertQuery.prepare("INSERT INTO friend_requests (requester, receiver) "
                                            "VALUES (:requester, :receiver)");
                        insertQuery.bindValue(":requester", currentUser);
                        insertQuery.bindValue(":receiver", friendToAdd);

                        if (insertQuery.exec()) {
                            response = "FRIEND_REQUEST_SENT:" + friendToAdd;

                            // 如果对方在线，实时发送通知
                            if (onlineUsers.contains(friendToAdd)) {
                                QTcpSocket* receiverSocket = onlineUsers[friendToAdd];
                                addMessage("DEBUG: 发送好友请求从" + currentUser + "到" + friendToAdd);
                                sendTextToClient(receiverSocket, "FRIEND_REQUEST:" + currentUser);

                                // 同时发送请求方的昵称
                                QString nickname = getNickname(currentUser);
                                sendTextToClient(receiverSocket, "REQUESTER_NICKNAME:" + currentUser + ":" + nickname);
                            } else {
                                addMessage("DEBUG: 接收方" + friendToAdd + "不在线，请求已存储");
                            }
                        } else {
                            response = "FRIEND_ERROR:请求发送失败";
                        }
                    }
                } else {
                    response = "FRIEND_ERROR:用户不存在";
                }
            } else {
                response = "FRIEND_ERROR:用户验证失败";
            }
        }
    }

    // 添加处理好友请求确认
    else if (message.startsWith("CONFIRM_FRIEND:")) {
        QStringList parts = message.mid(15).split(':');
        if (parts.size() >= 2) {
            QString requester = parts[0];
            QString action = parts[1].toLower();

            QString currentUser = clientUsers.value(clientSocket, "");
            if (currentUser.isEmpty()) {
                response = "FRIEND_ERROR:请先登录";
            } else {
                // 删除好友请求记录（无论同意还是拒绝）
                QSqlQuery deleteQuery;
                deleteQuery.prepare("DELETE FROM friend_requests "
                                    "WHERE requester = :requester AND receiver = :receiver");
                deleteQuery.bindValue(":requester", requester);
                deleteQuery.bindValue(":receiver", currentUser);
                deleteQuery.exec();

                if (action == "accept") {
                    // 添加双向好友关系
                    if (addFriend(requester, currentUser)) {
                        response = "FRIEND_ADDED_SUCCESS:" + requester;

                        // 通知请求方
                        if (onlineUsers.contains(requester)) {
                            sendTextToClient(onlineUsers[requester],
                                             "FRIEND_REQUEST_ACCEPTED:" + currentUser);
                        }

                        // 更新双方好友列表
                        updateFriendListForUser(currentUser);
                        updateFriendListForUser(requester);
                    } else {
                        response = "FRIEND_ERROR:添加好友失败";
                    }
                } else if (action == "reject") {
                    response = "FRIEND_REQUEST_REJECTED:" + requester;

                    // 通知请求方
                    if (onlineUsers.contains(requester)) {
                        sendTextToClient(onlineUsers[requester],
                                         "FRIEND_REQUEST_REJECTED:" + currentUser);
                    }
                } else {
                    response = "FRIEND_ERROR:无效的操作类型";
                }
            }
        } else {
            response = "FRIEND_ERROR:无效的确认格式";
        }
    }
    else if (message.startsWith("PRIVATE_MSG:")) {
        QStringList parts = message.mid(12).split(":");
        if (parts.size() >= 2) {
            QString receiver = parts[0].trimmed();
            QString privateMsg = parts.mid(1).join(":");

            QString sender = clientUsers.value(clientSocket, "Unknown");
            if (sender != "Unknown") {
                // 检查双方是否为好友
                if (!areFriends(sender, receiver)) {
                    response = "PRIVATE_ERROR:对方不是您的好友";
                    addMessage("❌ 私聊失败: " + sender + " 和 " + receiver + " 不是好友");
                }
                // 检查接收者在线状态
                else if (onlineUsers.contains(receiver)) {
                    sendPrivateMessage(sender, receiver, privateMsg);
                    response = "PRIVATE_SENT:" + receiver;
                    addMessage("📨 " + sender + " -> " + receiver + ": " + privateMsg);
                } else {
                    storeOfflineMessage(sender, receiver, privateMsg);
                    response = "PRIVATE_OFFLINE:" + receiver;
                    addMessage("📭 " + sender + " -> " + receiver + " (离线): " + privateMsg);
                }
            } else {
                response = "PRIVATE_ERROR:未登录";
            }
        } else {
            response = "PRIVATE_ERROR:无效的私聊格式";
        }
    }
    // 新增：处理昵称更新请求
    else if (message.startsWith("UPDATE_NICKNAME:")) {
        QString newNickname = message.mid(16); // 跳过"UPDATE_NICKNAME:"的长度
        QString username = clientUsers.value(clientSocket, "");

        if (username.isEmpty()) {
            response = "ERROR:请先登录";
        } else {
            if (updateNickname(username, newNickname)) {
                response = "NICKNAME_UPDATE_SUCCESS:" + newNickname;
                addMessage("👤 用户 " + username + " 更新昵称为: " + newNickname);
            } else {
                response = "NICKNAME_UPDATE_FAILED:昵称更新失败";
            }
        }
    }

    else {
        // 普通聊天消息：服务器只记录，不转发
        QString username = clientUsers.value(clientSocket, "Unknown");
        if (username != "Unknown") {
            addMessage("💬 收到来自 " + username + " 的消息: " + message);
        } else {
            addMessage("💬 收到未认证客户端的消息: " + message);
        }
    }

    // 发送响应给客户端
    if (!response.isEmpty()) {
        sendTextToClient(clientSocket, response);
    }
}


void MainWindow::storeOfflineMessage(const QString& sender, const QString& receiver, const QString& message)
{
    QSqlQuery query;
    query.prepare("INSERT INTO offline_messages (receiver, sender, message) "
                  "VALUES (:receiver, :sender, :message)");
    query.bindValue(":receiver", receiver);
    query.bindValue(":sender", sender);
    query.bindValue(":message", message);

    if (!query.exec()) {
        addMessage("❌ 存储离线消息失败: " + query.lastError().text());
    } else {
        // 添加日志：成功存储离线消息
        addMessage(QString("📭 存储离线消息: %1 -> %2 (内容: %3)")
                   .arg(sender).arg(receiver).arg(message));
    }
}

void MainWindow::addPendingFriendUpdate(const QString &username, const QString &newFriend)
{
    QSqlQuery query;
    query.prepare("INSERT OR IGNORE INTO pending_friend_updates (username, new_friend) "
                  "VALUES (:username, :new_friend)");
    query.bindValue(":username", username);
    query.bindValue(":new_friend", newFriend);

    if (!query.exec()) {
        addMessage("❌ 添加待处理更新失败: " + query.lastError().text());
    }
}


// 新增函数：发送好友请求通知
void MainWindow::sendFriendRequestNotification(const QString &sender, const QString &receiver)
{
    // 检查是否存在双向请求
    QSqlQuery checkQuery;
    checkQuery.prepare("SELECT COUNT(*) FROM friend_requests WHERE requester = :sender AND receiver = :receiver");
    checkQuery.bindValue(":sender", sender);
    checkQuery.bindValue(":receiver", receiver);

    if (checkQuery.exec() && checkQuery.next() && checkQuery.value(0).toInt() > 0) {
        return; // 请求已存在，不再发送
    }


    checkQuery.prepare("SELECT COUNT(*) FROM friend_requests "
                       "WHERE requester = :other AND receiver = :current");
    checkQuery.bindValue(":other", receiver);   // 反向请求的发送方
    checkQuery.bindValue(":current", sender);   // 反向请求的接收方

    bool hasReverseRequest = false;
    if (checkQuery.exec() && checkQuery.next()) {
        hasReverseRequest = (checkQuery.value(0).toInt() > 0);
        addMessage("🔄 反向请求检查: " +
                   QString(hasReverseRequest ? "存在" : "不存在"));
    }

    // 存在双向请求 - 自动成为好友
    if (hasReverseRequest) {
        // 修复2：添加好友前检查是否已是好友
        QSqlQuery friendQuery;
        friendQuery.prepare("SELECT COUNT(*) FROM friends "
                            "WHERE (user1 = :user1 AND user2 = :user2) "
                            "OR (user1 = :user2 AND user2 = :user1)");
        friendQuery.bindValue(":user1", sender);
        friendQuery.bindValue(":user2", receiver);

        bool alreadyFriends = false;
        if (friendQuery.exec() && friendQuery.next()) {
            alreadyFriends = (friendQuery.value(0).toInt() > 0);
        }

        if (!alreadyFriends && addFriend(sender, receiver)) {
            // 删除双方的请求记录
            QSqlQuery deleteQuery;
            deleteQuery.prepare("DELETE FROM friend_requests "
                                "WHERE (requester = :user1 AND receiver = :user2) "
                                "OR (requester = :user2 AND receiver = :user1)");
            deleteQuery.bindValue(":user1", sender);
            deleteQuery.bindValue(":user2", receiver);
            deleteQuery.exec();

            // 更新双方好友列表
            updateFriendListForUser(sender);
            updateFriendListForUser(receiver);

            addMessage("👥 自动添加好友: " + sender + " ↔ " + receiver);
            return; // 已处理，无需发送请求
        }
    }

    if (onlineUsers.contains(receiver)) {
        // 用户在线，直接发送通知
        QTcpSocket *receiverSocket = onlineUsers.value(receiver);
        sendTextToClient(receiverSocket, "FRIEND_REQUEST:" + sender);

        // 同时发送请求方的昵称
        QString nickname = getNickname(sender);
        sendTextToClient(receiverSocket, "REQUESTER_NICKNAME:" + sender + ":" + nickname);
    } else {
        // 用户不在线，保存到数据库
        QSqlQuery query;
        query.prepare("INSERT OR IGNORE INTO friend_requests (requester, receiver) "
                      "VALUES (:requester, :receiver)");
        query.bindValue(":requester", sender);
        query.bindValue(":receiver", receiver);

        if (query.exec()) {
            addMessage("⚠️ 用户 " + receiver + " 不在线，好友请求已保存");
        } else {
            addMessage("❌ 保存好友请求失败: " + query.lastError().text());
        }
    }
}


// 新增：更新昵称的辅助函数
bool MainWindow::updateNickname(const QString &username, const QString &nickname)
{
    if (username.isEmpty() || nickname.isEmpty()) {
        return false;
    }

    QSqlQuery query;
    query.prepare("UPDATE users SET nickname = :nickname WHERE username = :username");
    query.bindValue(":nickname", nickname);
    query.bindValue(":username", username);

    if (!query.exec()) {
        addMessage("❌ 更新昵称失败: " + query.lastError().text());
        return false;
    }

    return true;
}
// 新增获取昵称函数
QString MainWindow::getNickname(const QString &username)
{
    QSqlQuery query;
    query.prepare("SELECT nickname FROM users WHERE username = :username");
    query.bindValue(":username", username);

    if (query.exec() && query.next()) {
        return query.value(0).toString();
    }
    return username; // 如果没有昵称，返回用户名
}

// 添加视频通话处理函数
void MainWindow::handleVideoCallRequest(const QString &sender, const QString &receiver, QTcpSocket *socket)
{
    if (!onlineUsers.contains(receiver)) {
        sendTextToClient(socket, "VIDEO_ERROR:用户不在线");
        return;
    }

    // 检查是否已有通话
    if (activeVideoCalls.contains(sender)) {
        sendTextToClient(socket, "VIDEO_ERROR:您已有进行中的通话");
        return;
    }
    if (activeVideoCalls.contains(receiver)) {
        sendTextToClient(socket, "VIDEO_ERROR:对方正忙");
        return;
    }

    // 解析UDP端口
    QStringList parts = QString::fromUtf8(socket->readAll()).split(':');
    if (parts.size() < 4) {
        sendTextToClient(socket, "VIDEO_ERROR:无效请求格式");
        return;
    }

    bool ok;
    quint16 udpPort = parts[3].toUShort(&ok);
    if (!ok) {
        sendTextToClient(socket, "VIDEO_ERROR:无效UDP端口");
        return;
    }

    // 记录发起者信息
    VideoCall newCall;
    newCall.initiator = sender;
    newCall.receiver = receiver;
    newCall.initiatorAddr = socket->peerAddress();
    newCall.initiatorUdpPort = udpPort;  // 存储UDP端口
    activeVideoCalls.insert(sender, newCall);
    activeVideoCalls.insert(receiver, newCall);  // 双向记录

    // 通知接收者
    QTcpSocket *receiverSocket = onlineUsers[receiver];
    sendTextToClient(receiverSocket, "VIDEO_REQUEST:" + sender + ":" +
                     QString::number(udpPort));

    addMessage("📞 " + sender + " 请求与 " + receiver + " 视频通话 (UDP端口:" +
               QString::number(udpPort) + ")");
}

// 结束视频通话
void MainWindow::endVideoCall(const QString &username)
{
    if (!activeVideoCalls.contains(username)) return;

    VideoCall call = activeVideoCalls[username];
    activeVideoCalls.remove(call.initiator);
    if (call.initiator != call.receiver) {
        activeVideoCalls.remove(call.receiver);
    }
    addMessage("📹 视频通话结束: " + call.initiator + " ↔ " + call.receiver);
}

void MainWindow::clientDisconnected()
{
    QTcpSocket *clientSocket = qobject_cast<QTcpSocket*>(sender());
    if (!clientSocket) return;

    QString username = clientUsers.value(clientSocket, "");
    QString clientInfo = QString("%1:%2")
            .arg(clientSocket->peerAddress().toString())
            .arg(clientSocket->peerPort());

    if (!username.isEmpty()) {
        // 结束相关视频通话
        endVideoCall(username);

        onlineUsers.remove(username);
        sendOnlineNotification(username, false);
    }

    addMessage("❌ 客户端断开连接: " + clientInfo);

    clientSockets.removeOne(clientSocket);
    clientUsers.remove(clientSocket);
    clientSocket->deleteLater();
}

void MainWindow::addMessage(const QString &message)
{
    QString timestamp = QDateTime::currentDateTime().toString("[hh:mm:ss] ");
    QListWidgetItem *item = new QListWidgetItem(timestamp + message);
    ui->listWidget->addItem(item);
    ui->listWidget->scrollToBottom();
}

void MainWindow::sendTextToClient(QTcpSocket* clientSocket, const QString& message)
{
    if (clientSocket && clientSocket->state() == QTcpSocket::ConnectedState) {
        QByteArray data = message.toUtf8();
        // 确保长度头是8字节数字字符串，用前导零填充
        char sizeHeader[9];
        snprintf(sizeHeader, 9, "%08llu", static_cast<unsigned long long>(data.size()));
        clientSocket->write(sizeHeader, 8);
        clientSocket->write(data);
    }
}

void MainWindow::sendDataToClient(QTcpSocket* clientSocket, const QByteArray& data)
{
    if (clientSocket && clientSocket->state() == QTcpSocket::ConnectedState) {
        // 确保长度头是8字节数字字符串，用前导零填充
        char sizeHeader[9];
        snprintf(sizeHeader, 9, "%08llu", static_cast<unsigned long long>(data.size()));
        clientSocket->write(sizeHeader, 8);
        clientSocket->write(data);
    }
}

void MainWindow::on_sendButton_clicked()
{
    QString message = ui->messageEdit->text().trimmed();
    QString portText = ui->targetPortEdit->text().trimmed();

    if (message.isEmpty()) {
        QMessageBox::warning(this, "发送错误", "消息内容不能为空");
        return;
    }

    bool ok;
    int targetPort = portText.toInt(&ok);

    if (!ok) {
        QMessageBox::warning(this, "发送错误", "无效的端口号");
        return;
    }

    bool found = false;
    foreach (QTcpSocket* socket, clientSockets) {
        if (socket->peerPort() == targetPort) {
            sendTextToClient(socket, "SERVER_MSG:" + message);
            addMessage("💬 服务器消息发送到端口 " + portText + ": " + message);
            found = true;
            break;
        }
    }

    if (!found) {
        QMessageBox::warning(this, "发送错误",
                             QString("未找到端口为 %1 的客户端").arg(targetPort));
    }

    ui->messageEdit->clear();
}

void MainWindow::on_clearDbButton_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "确认清空", "确定要清空所有用户数据吗？此操作不可恢复！",
                                  QMessageBox::Yes|QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        QSqlQuery query;
        bool success = true;

        // 清空所有相关表
        success &= query.exec("DELETE FROM users");
        success &= query.exec("DELETE FROM friends");
        success &= query.exec("DELETE FROM friend_requests");
        success &= query.exec("DELETE FROM offline_messages"); // 新增

        if (success) {
            addMessage("✅ 数据库已清空");
            QMessageBox::information(this, "成功", "用户数据库已清空");
        } else {
            addMessage("❌ 清空数据库失败: " + query.lastError().text());
        }
    }
}

void MainWindow::on_searchButton_clicked()
{
    QString searchTerm = ui->searchEdit->text().trimmed();
    if (searchTerm.isEmpty()) {
        QMessageBox::information(this, "搜索", "请输入搜索关键词");
        return;
    }

    friendsModel->clear();
    friendsModel->setHorizontalHeaderLabels(QStringList() << "好友关系");

    QSqlQuery query;
    query.prepare("SELECT user1, user2 FROM friends WHERE user1 LIKE :term OR user2 LIKE :term");
    query.bindValue(":term", "%" + searchTerm + "%");

    if (query.exec()) {
        int count = 0;
        while (query.next()) {
            QString user1 = query.value(0).toString();
            QString user2 = query.value(1).toString();
            QString nickname1 = getNickname(user1);
            QString nickname2 = getNickname(user2);

            QStandardItem *item = new QStandardItem(
                        user1 + " (" + nickname1 + ") 👬 " +
                        user2 + " (" + nickname2 + ")"
                        );
            friendsModel->appendRow(item);
        }
        ui->statusLabel->setText("找到 " + QString::number(count) + " 条好友关系");
    } else {
        ui->statusLabel->setText("搜索失败: " + query.lastError().text());
    }
}

void MainWindow::on_showFriendsButton_clicked()
{
    QString username = QInputDialog::getText(this, "查看好友", "请输入用户名:");
    if (username.isEmpty()) return;

    QList<QString> friends = getFriends(username);
    if (friends.isEmpty()) {
        QMessageBox::information(this, "好友列表",
                                 "<font color='black'>" + username + " 没有好友</font>");
        return;
    }

    QStringList friendList;
    foreach (const QString &friendName, friends) {
        QString nickname = getNickname(friendName);
        friendList << friendName + " (" + nickname + ")";
    }

    // 使用HTML格式确保文本为黑色
    QString html = QString("<font color='black'>%1 的好友:</font>"
                           "<br><br>"
                           "<font color='black'>%2</font>")
            .arg(username)
            .arg(friendList.join("<br>"));

    QMessageBox msgBox;
    msgBox.setWindowTitle("好友列表");
    msgBox.setTextFormat(Qt::RichText); // 启用富文本格式
    msgBox.setText(html);
    msgBox.exec();
}
