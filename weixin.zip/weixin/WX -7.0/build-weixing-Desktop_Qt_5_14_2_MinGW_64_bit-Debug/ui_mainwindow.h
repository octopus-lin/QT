/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *exit;
    QPushButton *shezhi;
    QPushButton *going;
    QPushButton *qiehuan;
    QPushButton *chuanshu;
    QLabel *touxiang;
    QLabel *name;
    QPushButton *chuanshu_2;
    QLineEdit *useradd;
    QLineEdit *passadd;
    QPushButton *pying;
    QMenuBar *menubar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(348, 473);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        exit = new QPushButton(centralwidget);
        exit->setObjectName(QString::fromUtf8("exit"));
        exit->setGeometry(QRect(292, 0, 57, 49));
        exit->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 57px;\n"
"    min-height: 49px;\n"
"    max-width: 57px;\n"
"    max-height: 49px;\n"
"    border-top-right-radius: 10px; /* \345\217\263\344\270\212\350\247\222\345\234\206\350\247\22210px */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/red-x.png\"); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\266\346\230\276\347\244\272\346\214\207\345\256\232\345\233\276\347\211\207 */\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-top-right-radius: 10px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\234\206\350\247\222 */\n"
"}"));
        shezhi = new QPushButton(centralwidget);
        shezhi->setObjectName(QString::fromUtf8("shezhi"));
        shezhi->setGeometry(QRect(234, 0, 58, 49));
        shezhi->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 58px;\n"
"    min-height: 49px;\n"
"    max-width: 58px;\n"
"    max-height: 49px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\26610%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"}"));
        going = new QPushButton(centralwidget);
        going->setObjectName(QString::fromUtf8("going"));
        going->setGeometry(QRect(62, 335, 224, 45));
        going->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent;\n"
"    border: none;\n"
"    min-width: 224px;\n"
"    min-height: 45px;\n"
"    max-width: 224px;\n"
"    max-height: 45px;\n"
"    border-radius: 10px; /* \345\233\233\344\270\252\350\247\222\351\203\275\350\256\276\347\275\256\344\270\27210px\345\234\206\350\247\222 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-image: url(\":/img/img/go-wx.png\");\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"    border-radius: 5px; /* \346\202\254\345\201\234\347\212\266\346\200\201\344\277\235\346\214\201\345\233\233\344\270\252\350\247\222\345\234\206\350\247\222 */\n"
"}"));
        qiehuan = new QPushButton(centralwidget);
        qiehuan->setObjectName(QString::fromUtf8("qiehuan"));
        qiehuan->setGeometry(QRect(80, 410, 75, 25));
        qiehuan->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 75px;\n"
"    min-height: 25px;\n"
"    max-width: 75px;\n"
"    max-height: 25px;\n"
"}\n"
""));
        chuanshu = new QPushButton(centralwidget);
        chuanshu->setObjectName(QString::fromUtf8("chuanshu"));
        chuanshu->setGeometry(QRect(180, 410, 85, 25));
        chuanshu->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 85px;\n"
"    min-height: 25px;\n"
"    max-width: 85px;\n"
"    max-height: 25px;\n"
"}\n"
"\n"
""));
        touxiang = new QLabel(centralwidget);
        touxiang->setObjectName(QString::fromUtf8("touxiang"));
        touxiang->setGeometry(QRect(124, 79, 100, 100));
        touxiang->setStyleSheet(QString::fromUtf8("color: black;\n"
"background-color: rgb(85, 255, 255);\n"
"border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"min-width: 100px;\n"
"min-height: 100px;\n"
"\n"
"border-radius: 6px;"));
        name = new QLabel(centralwidget);
        name->setObjectName(QString::fromUtf8("name"));
        name->setGeometry(QRect(20, 210, 311, 31));
        name->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255); \n"
"border: none;\n"
"font-size: 20px; /* \345\201\207\350\256\276\344\271\213\345\211\215\350\256\276\347\275\256\347\232\204\345\255\227\345\217\267\357\274\214\345\217\257\344\277\235\347\225\231\346\210\226\350\260\203\346\225\264 */\n"
"font-family: \"Microsoft YaHei\"; /* Windows \347\263\273\347\273\237\345\270\270\347\224\250\344\270\255\346\226\207\345\255\227\344\275\223 */"));
        name->setAlignment(Qt::AlignCenter);
        chuanshu_2 = new QPushButton(centralwidget);
        chuanshu_2->setObjectName(QString::fromUtf8("chuanshu_2"));
        chuanshu_2->setGeometry(QRect(125, 410, 95, 25));
        chuanshu_2->setLayoutDirection(Qt::LeftToRight);
        chuanshu_2->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 95px;\n"
"    min-height: 25px;\n"
"    max-width: 95px;\n"
"    max-height: 25px;\n"
"}\n"
"\n"
""));
        useradd = new QLineEdit(centralwidget);
        useradd->setObjectName(QString::fromUtf8("useradd"));
        useradd->setGeometry(QRect(70, 100, 200, 35));
        useradd->setCursor(QCursor(Qt::IBeamCursor));
        useradd->setStyleSheet(QString::fromUtf8("/* \346\255\243\345\270\270\347\212\266\346\200\201\344\270\213\347\232\204\346\240\267\345\274\217 - \346\234\211\345\206\205\345\256\271\346\227\266\346\230\276\347\244\272\350\203\214\346\231\257\345\222\214\350\276\271\346\241\206 */\n"
"QLineEdit#useradd {\n"
"    background-color: rgb(243, 243, 243);  /* \351\273\230\350\256\244\346\230\276\347\244\272\350\203\214\346\231\257 */\n"
"    border-radius: 5px;\n"
"    font-size: 18px;\n"
"    font-family: \"Microsoft YaHei\";\n"
"}\n"
"\n"
"\n"
"\n"
"/* \350\216\267\345\276\227\347\204\246\347\202\271\357\274\210\351\274\240\346\240\207\347\202\271\345\207\273\346\277\200\346\264\273\357\274\211\346\227\266\347\232\204\346\240\267\345\274\217 */\n"
"QLineEdit#useradd:focus {\n"
"    background-color: rgb(243, 243, 243);  /* \346\230\276\347\244\272\350\203\214\346\231\257 */\n"
"    border: 1px solid rgb(6, 181, 90);     /* \346\230\276\347\244\272\347\273\277\350\211\262\350\276\271\346\241\206 */\n"
"    border-radius: 5px;\n"
"}"));
        useradd->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        passadd = new QLineEdit(centralwidget);
        passadd->setObjectName(QString::fromUtf8("passadd"));
        passadd->setGeometry(QRect(70, 170, 200, 35));
        passadd->setStyleSheet(QString::fromUtf8("/* \346\255\243\345\270\270\347\212\266\346\200\201\344\270\213\347\232\204\346\240\267\345\274\217 - \346\234\211\345\206\205\345\256\271\346\227\266\346\230\276\347\244\272\350\203\214\346\231\257\345\222\214\350\276\271\346\241\206 */\n"
"QLineEdit#passadd {\n"
"    background-color: rgb(243, 243, 243);  /* \351\273\230\350\256\244\346\230\276\347\244\272\350\203\214\346\231\257 */\n"
"    border-radius: 5px;\n"
"    font-size: 18px;\n"
"    font-family: \"Microsoft YaHei\";\n"
"    text-align: center;\n"
"}\n"
"\n"
"\n"
"\n"
"/* \350\216\267\345\276\227\347\204\246\347\202\271\357\274\210\351\274\240\346\240\207\347\202\271\345\207\273\346\277\200\346\264\273\357\274\211\346\227\266\347\232\204\346\240\267\345\274\217 */\n"
"QLineEdit#passadd:focus {\n"
"    background-color: rgb(243, 243, 243);  /* \346\230\276\347\244\272\350\203\214\346\231\257 */\n"
"    border: 1px solid rgb(6, 181, 90);     /* \346\230\276\347\244\272\347\273\277\350\211\262\350\276\271\346\241\206 */\n"
"    border-radius: 5px;\n"
""
                        "}"));
        passadd->setEchoMode(QLineEdit::Password);
        passadd->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        pying = new QPushButton(centralwidget);
        pying->setObjectName(QString::fromUtf8("pying"));
        pying->setGeometry(QRect(95, 260, 150, 40));
        pying->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: rgb(7, 193, 96); /* \350\256\276\347\275\256\350\203\214\346\231\257\351\242\234\350\211\262\344\270\272\346\214\207\345\256\232RGB\345\200\274 */\n"
"    color: white;                      /* \346\226\207\345\255\227\351\242\234\350\211\262\350\256\276\344\270\272\347\231\275\350\211\262\344\273\245\344\276\277\346\270\205\346\231\260\346\230\276\347\244\272 */\n"
"    border: none;\n"
"    min-width: 150px;\n"
"    min-height: 40px;\n"
"    max-width: 150px;\n"
"    max-height: 40px;\n"
"    border-radius: 10px;\n"
"    font-size: 14px;                   /* \350\256\276\347\275\256\345\255\227\344\275\223\345\244\247\345\260\217 */\n"
"    font-weight: bold;                 /* \346\226\207\345\255\227\345\212\240\347\262\227 */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(5, 160, 80); /* \346\202\254\345\201\234\347\212\266\346\200\201\344\270\213\347\232\204\351\242\234\350\211\262 */\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: r"
                        "gb(3, 120, 60); /* \346\214\211\344\270\213\347\212\266\346\200\201\344\270\213\347\232\204\351\242\234\350\211\262 */\n"
"}"));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 348, 26));
        MainWindow->setMenuBar(menubar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        exit->setText(QString());
        shezhi->setText(QString());
        going->setText(QString());
        qiehuan->setText(QString());
        chuanshu->setText(QString());
        touxiang->setText(QString());
        name->setText(QCoreApplication::translate("MainWindow", "\346\207\222\346\264\213\346\264\213", nullptr));
        chuanshu_2->setText(QString());
        useradd->setPlaceholderText(QCoreApplication::translate("MainWindow", "\350\257\267\350\276\223\345\205\245\345\276\256\344\277\241\345\217\267", nullptr));
        passadd->setText(QString());
        passadd->setPlaceholderText(QCoreApplication::translate("MainWindow", "\350\257\267\350\276\223\345\205\245\345\257\206\347\240\201", nullptr));
        pying->setText(QCoreApplication::translate("MainWindow", "\347\231\273\345\275\225/\346\263\250\345\206\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
