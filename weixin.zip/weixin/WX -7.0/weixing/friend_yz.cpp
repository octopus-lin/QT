#include "friend_yz.h"
#include "networkmanager.h"
#include "ui_friend_yz.h"
#include <QMessageBox>
#include <QMouseEvent>
#include <QPainter>

friend_yz::friend_yz(QWidget *parent, const QString& targetUsername) :
    QMainWindow(parent),
    ui(new Ui::friend_yz),
    m_targetUsername(targetUsername)
{
    ui->setupUi(this);
    // 1. 删除标题栏
    setWindowFlags(Qt::FramelessWindowHint);
    // 2. 设置窗口背景透明
    setAttribute(Qt::WA_TranslucentBackground);
    // 3. 添加背景图片样式表
    ui->centralwidget->setStyleSheet(
                "  QWidget#centralwidget {"
                "  background-image: url(:/img/img/friend_yz.png);"
                "  background-position: center;"
                "  background-repeat: no-repeat;"
                "  border-radius: 10px;"          // 圆角
                "  border: 1px solid rgba(0,0,0,75);" // 边框效果
                "}"
                );
}

friend_yz::~friend_yz()
{
    delete ui;
}

void friend_yz::setTargetUsername(const QString& username) {
    m_targetUsername = username;
}




// 鼠标按下事件处理
void friend_yz::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        // 记录鼠标按下时的全局位置和窗口位置
        m_dragPosition = event->globalPos() - frameGeometry().topLeft();
        event->accept();
    }
}

// 鼠标移动事件处理
void friend_yz::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton) {
        // 计算窗口新位置
        move(event->globalPos() - m_dragPosition);
        event->accept();
    }
}

void friend_yz::on_quxiao_clicked()
{
    close();
}

void friend_yz::on_queding_clicked()
{
    ui->queding->setEnabled(false);
    if (!m_targetUsername.isEmpty()) {
        // 发送好友请求
        NetworkManager* netManager = NetworkManager::instance();
        QString command = "ADD_FRIEND:" + m_targetUsername;
        netManager->sendTcpMessage(command);;
        QMessageBox::information(this, "发送成功", "好友验证发送成功，请等待对方验证");
        ui->queding->setEnabled(true); // 重新启用按钮
        // 关闭窗口
        close();
    } else {
        QMessageBox::warning(this, "错误", "未指定好友用户名");
        ui->queding->setEnabled(true); // 重新启用按钮
    }

}
