/********************************************************************************
** Form generated from reading UI file 'myhome.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MYHOME_H
#define UI_MYHOME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_myhome
{
public:
    QWidget *centralwidget;
    QPushButton *send_s;
    QLabel *ID;
    QLabel *ID_2;
    QLabel *names;
    QPushButton *touxiang;
    QPushButton *names_but;
    QMenuBar *menubar;

    void setupUi(QMainWindow *myhome)
    {
        if (myhome->objectName().isEmpty())
            myhome->setObjectName(QString::fromUtf8("myhome"));
        myhome->resize(350, 335);
        centralwidget = new QWidget(myhome);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        send_s = new QPushButton(centralwidget);
        send_s->setObjectName(QString::fromUtf8("send_s"));
        send_s->setGeometry(QRect(130, 233, 90, 70));
        send_s->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: transparent; /* \346\255\243\345\270\270\347\212\266\346\200\201\345\256\214\345\205\250\351\200\217\346\230\216 */\n"
"    color: black;\n"
"    border: none; /* \345\246\202\346\236\234\351\234\200\350\246\201\346\227\240\350\276\271\346\241\206\346\225\210\346\236\234 */\n"
"    min-width: 90px;\n"
"    min-height: 70px;\n"
"    max-width: 90px;\n"
"    max-height: 70px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(0, 0, 0, 0.05); /* \351\274\240\346\240\207\346\202\254\345\201\234\346\227\2665%\351\200\217\346\230\216\345\272\246\347\232\204\351\273\221\350\211\262\351\201\256\347\275\251 */\n"
"    border-radius: 5px;\n"
"}    "));
        ID = new QLabel(centralwidget);
        ID->setObjectName(QString::fromUtf8("ID"));
        ID->setGeometry(QRect(180, 59, 151, 20));
        ID->setStyleSheet(QString::fromUtf8("background-color: white;      /* \350\203\214\346\231\257\344\270\272\347\231\275\350\211\262 */\n"
"font-family: \"Microsoft YaHei\";\n"
"color: rgb(158, 158, 158);    /* \345\255\227\344\275\223\344\270\272\346\265\205\347\201\260\350\211\262 */\n"
"border: none;                 /* \346\227\240\350\276\271\346\241\206 */\n"
""));
        ID_2 = new QLabel(centralwidget);
        ID_2->setObjectName(QString::fromUtf8("ID_2"));
        ID_2->setGeometry(QRect(170, 79, 151, 20));
        ID_2->setStyleSheet(QString::fromUtf8("background-color: white;      /* \350\203\214\346\231\257\344\270\272\347\231\275\350\211\262 */\n"
"font-family: \"Microsoft YaHei\";\n"
"color: rgb(158, 158, 158);    /* \345\255\227\344\275\223\344\270\272\346\265\205\347\201\260\350\211\262 */\n"
"border: none;                 /* \346\227\240\350\276\271\346\241\206 */\n"
""));
        names = new QLabel(centralwidget);
        names->setObjectName(QString::fromUtf8("names"));
        names->setGeometry(QRect(124, 30, 180, 30));
        names->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255); \n"
"border: none;\n"
"font-size: 18px; /* \345\201\207\350\256\276\344\271\213\345\211\215\350\256\276\347\275\256\347\232\204\345\255\227\345\217\267\357\274\214\345\217\257\344\277\235\347\225\231\346\210\226\350\260\203\346\225\264 */\n"
"font-family: \"Microsoft YaHei\"; /* Windows \347\263\273\347\273\237\345\270\270\347\224\250\344\270\255\346\226\207\345\255\227\344\275\223 */"));
        names->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        touxiang = new QPushButton(centralwidget);
        touxiang->setObjectName(QString::fromUtf8("touxiang"));
        touxiang->setGeometry(QRect(30, 29, 75, 75));
        touxiang->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"     background-color: transparent;\n"
"         min-width: 75px;\n"
"         min-height: 75px;\n"
"         max-width: 75px;\n"
"         max-height: 75px;\n"
"         border-radius: 8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-radius: 8px;\n"
"    background-color: rgba(0, 0, 0, 0.03);\n"
"\n"
"}"));
        names_but = new QPushButton(centralwidget);
        names_but->setObjectName(QString::fromUtf8("names_but"));
        names_but->setGeometry(QRect(124, 30, 180, 30));
        names_but->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"     background-color: transparent;\n"
"         min-width: 180px;\n"
"         min-height: 30px;\n"
"         max-width: 180px;\n"
"         max-height: 30px;\n"
"         border-radius: 8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-radius: 5px;\n"
"    background-color: rgba(0, 0, 0, 0.03);\n"
"\n"
"}"));
        myhome->setCentralWidget(centralwidget);
        touxiang->raise();
        send_s->raise();
        ID->raise();
        ID_2->raise();
        names->raise();
        names_but->raise();
        menubar = new QMenuBar(myhome);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 350, 26));
        myhome->setMenuBar(menubar);

        retranslateUi(myhome);

        QMetaObject::connectSlotsByName(myhome);
    } // setupUi

    void retranslateUi(QMainWindow *myhome)
    {
        myhome->setWindowTitle(QCoreApplication::translate("myhome", "MainWindow", nullptr));
        send_s->setText(QString());
        ID->setText(QCoreApplication::translate("myhome", "12345600000", nullptr));
        ID_2->setText(QCoreApplication::translate("myhome", "\345\271\277\344\270\234 \345\271\277\345\267\236", nullptr));
        names->setText(QCoreApplication::translate("myhome", "\346\207\222\346\264\213\346\264\213", nullptr));
        touxiang->setText(QString());
        names_but->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class myhome: public Ui_myhome {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYHOME_H
